// DONNÉES SPÉCIFIQUES AU MAROC

export const MOROCCAN_CITIES = [
  "Casablanca",
  "Rabat",
  "Fès",
  "Marrakech",
  "Agadir",
  "Tanger",
  "Meknès",
  "Oujda",
  "Kenitra",
  "Tétouan",
  "Safi",
  "Mohammedia",
  "Khouribga",
  "El Jadida",
  "Béni Mellal",
  "Nador",
  "Taza",
  "Settat",
  "Berrechid",
  "Khemisset",
  "Inezgane",
  "Ksar El Kebir",
  "Larache",
  "Guelmim",
  "Berkane",
  "Taourirt",
  "Bouskoura",
  "Fquih Ben Salah",
  "Dcheira El Jihadia",
  "Oued Zem",
]

export const MOROCCAN_HOLIDAYS_2024 = [
  { date: "2024-01-01", name: "Nouvel An" },
  { date: "2024-01-11", name: "Manifeste de l'Indépendance" },
  { date: "2024-03-10", name: "Ramadan (début)" },
  { date: "2024-04-10", name: "Aïd al-Fitr" },
  { date: "2024-05-01", name: "Fête du Travail" },
  { date: "2024-06-17", name: "Aïd al-Adha" },
  { date: "2024-07-07", name: "Nouvel An Hégirien" },
  { date: "2024-07-30", name: "Fête du Trône" },
  { date: "2024-08-14", name: "Journée de Oued Ed-Dahab" },
  { date: "2024-08-20", name: "Révolution du Roi et du Peuple" },
  { date: "2024-08-21", name: "Fête de la Jeunesse" },
  { date: "2024-09-16", name: "Mawlid (Anniversaire du Prophète)" },
  { date: "2024-11-06", name: "Marche Verte" },
  { date: "2024-11-18", name: "Fête de l'Indépendance" },
]

export const RAMADAN_HOURS = {
  start: "20:00",
  end: "06:00",
  isRamadanPeriod: () => {
    const now = new Date()
    const ramadanStart = new Date("2024-03-10")
    const ramadanEnd = new Date("2024-04-10")
    return now >= ramadanStart && now <= ramadanEnd
  },
}

export const MOROCCAN_PHONE_REGEX = /^(\+212|0)[5-7][0-9]{8}$/

export const formatMoroccanPhone = (phone: string) => {
  if (!phone) return ""
  const cleaned = phone.replace(/\D/g, "")
  if (cleaned.startsWith("212")) {
    return `+212 ${cleaned.slice(3, 4)} ${cleaned.slice(4, 6)} ${cleaned.slice(6, 8)} ${cleaned.slice(8, 10)} ${cleaned.slice(10, 12)}`
  }
  if (cleaned.startsWith("0")) {
    return `${cleaned.slice(0, 2)} ${cleaned.slice(2, 4)} ${cleaned.slice(4, 6)} ${cleaned.slice(6, 8)} ${cleaned.slice(8, 10)}`
  }
  return phone
}

export const DELIVERY_SERVICES = [
  { id: "amana", name: "Amana", logo: "/logos/amana.png" },
  { id: "jibli", name: "Jibli", logo: "/logos/jibli.png" },
  { id: "chrono", name: "Chrono", logo: "/logos/chrono.png" },
  { id: "colis", name: "Colis du Maroc", logo: "/logos/colis.png" },
]

export const PAYMENT_METHODS = [
  { id: "cash", name: "Paiement à la livraison", icon: "💰" },
  { id: "inwi", name: "Inwi Money", icon: "📱", color: "#FF6B35" },
  { id: "orange", name: "Orange Money", icon: "📱", color: "#FF7900" },
  { id: "bank", name: "Virement bancaire", icon: "🏦" },
]
