import { supabase } from "./supabase-client"

// FONCTIONS AMÉLIORÉES POUR LES COMMANDES

// Répéter une commande - VERSION CORRIGÉE
export const repeatOrder = async (originalOrderId: string) => {
  try {
    console.log("🔄 Début répétition commande:", originalOrderId)

    // 1. Récupérer la commande originale
    const { data: originalOrder, error: orderError } = await supabase
      .from("orders")
      .select("*")
      .eq("id", originalOrderId)
      .single()

    if (orderError) {
      console.error("Erreur récupération commande:", orderError)
      throw orderError
    }

    console.log("📦 Commande originale récupérée:", originalOrder)

    // 2. Récupérer les items de la commande séparément
    const { data: orderItems, error: itemsError } = await supabase
      .from("order_items")
      .select("*")
      .eq("order_id", originalOrderId)

    if (itemsError) {
      console.error("Erreur récupération items:", itemsError)
      throw itemsError
    }

    console.log("📋 Items récupérés:", orderItems)

    if (!orderItems || orderItems.length === 0) {
      throw new Error("Aucun produit trouvé dans la commande originale")
    }

    // 3. Vérifier le stock des produits
    for (const item of orderItems) {
      const { data: product, error: productError } = await supabase
        .from("products")
        .select("quantity, name")
        .eq("id", item.product_id)
        .single()

      if (productError) {
        console.error("Erreur vérification produit:", productError)
        continue // Continuer même si un produit n'existe plus
      }

      if (!product || product.quantity < item.quantity) {
        throw new Error(`Stock insuffisant pour le produit ${product?.name || "inconnu"}`)
      }
    }

    // 4. Créer la nouvelle commande
    const newOrderData = {
      user_id: originalOrder.user_id,
      order_number: `REP-${Date.now().toString().slice(-6)}`,
      client_name: originalOrder.client_name,
      client_phone: originalOrder.client_phone,
      client_address: originalOrder.client_address,
      total_amount: originalOrder.total_amount,
      status: "pending",
      notes: `Répétition de la commande ${originalOrder.order_number || originalOrder.id.slice(0, 8)}`,
    }

    console.log("🆕 Création nouvelle commande:", newOrderData)

    const { data: newOrder, error: createError } = await supabase
      .from("orders")
      .insert([newOrderData])
      .select()
      .single()

    if (createError) {
      console.error("Erreur création commande:", createError)
      throw createError
    }

    console.log("✅ Nouvelle commande créée:", newOrder)

    // 5. Créer les items de la nouvelle commande
    const newOrderItems = orderItems.map((item: any) => ({
      order_id: newOrder.id,
      product_id: item.product_id,
      quantity: item.quantity,
      price: item.price,
    }))

    console.log("📋 Création nouveaux items:", newOrderItems)

    const { error: itemsInsertError } = await supabase.from("order_items").insert(newOrderItems)

    if (itemsInsertError) {
      console.error("Erreur création items:", itemsInsertError)
      throw itemsInsertError
    }

    // 6. Décrémenter le stock pour chaque produit
    for (const item of orderItems) {
      // Récupérer la quantité actuelle
      const { data: currentProduct, error: getStockError } = await supabase
        .from("products")
        .select("quantity")
        .eq("id", item.product_id)
        .single()

      if (getStockError) {
        console.error("Erreur récupération stock:", getStockError)
        continue // Continuer même en cas d'erreur
      }

      // Calculer la nouvelle quantité
      const newQuantity = Math.max(0, (currentProduct?.quantity || 0) - item.quantity)

      // Mettre à jour le stock
      const { error: stockError } = await supabase
        .from("products")
        .update({ quantity: newQuantity })
        .eq("id", item.product_id)

      if (stockError) {
        console.error("Erreur mise à jour stock:", stockError)
        // Ne pas faire échouer toute l'opération pour une erreur de stock
      } else {
        console.log(`📦 Stock mis à jour pour produit ${item.product_id}: ${currentProduct?.quantity} → ${newQuantity}`)
      }
    }

    console.log("🎉 Commande répétée avec succès!")
    return newOrder
  } catch (error) {
    console.error("❌ Erreur répétition commande:", error)
    throw error
  }
}

// Ajouter un commentaire interne à une commande
export const addOrderComment = async (orderId: string, comment: string, userId: string) => {
  try {
    const { data, error } = await supabase
      .from("order_comments")
      .insert([
        {
          order_id: orderId,
          user_id: userId,
          comment,
          is_internal: true,
        },
      ])
      .select()
      .single()

    if (error) throw error
    return data
  } catch (error) {
    console.error("Erreur ajout commentaire:", error)
    throw error
  }
}

// Récupérer les commentaires d'une commande
export const getOrderComments = async (orderId: string) => {
  try {
    const { data, error } = await supabase
      .from("order_comments")
      .select(`
        *,
        users (full_name)
      `)
      .eq("order_id", orderId)
      .order("created_at", { ascending: true })

    if (error) throw error
    return data || []
  } catch (error) {
    console.error("Erreur récupération commentaires:", error)
    return []
  }
}

// Ajouter des tags à une commande
export const addOrderTags = async (orderId: string, tags: string[]) => {
  try {
    const { data, error } = await supabase.from("orders").update({ tags }).eq("id", orderId).select().single()

    if (error) throw error
    return data
  } catch (error) {
    console.error("Erreur ajout tags commande:", error)
    throw error
  }
}

// Récupérer l'historique des statuts d'une commande
export const getOrderStatusHistory = async (orderId: string) => {
  try {
    const { data, error } = await supabase
      .from("order_status_history")
      .select("*")
      .eq("order_id", orderId)
      .order("changed_at", { ascending: true })

    if (error) throw error
    return data || []
  } catch (error) {
    console.error("Erreur historique statuts:", error)
    return []
  }
}

// Regrouper les commandes par client
export const getOrdersByClient = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from("orders")
      .select("*")
      .eq("user_id", userId)
      .order("client_name", { ascending: true })

    if (error) throw error

    // Regrouper par client
    const groupedOrders = (data || []).reduce((acc: any, order: any) => {
      const clientKey = order.client_name.toLowerCase()
      if (!acc[clientKey]) {
        acc[clientKey] = {
          client_name: order.client_name,
          client_phone: order.client_phone,
          orders: [],
          total_orders: 0,
          total_amount: 0,
        }
      }
      acc[clientKey].orders.push(order)
      acc[clientKey].total_orders += 1
      acc[clientKey].total_amount += Number(order.total_amount)
      return acc
    }, {})

    return Object.values(groupedOrders)
  } catch (error) {
    console.error("Erreur regroupement clients:", error)
    return []
  }
}

// FONCTIONS AMÉLIORÉES POUR LES PRODUITS

// Ajouter des tags à un produit
export const addProductTags = async (productId: string, tags: string[]) => {
  try {
    const { data, error } = await supabase.from("products").update({ tags }).eq("id", productId).select().single()

    if (error) throw error
    return data
  } catch (error) {
    console.error("Erreur ajout tags produit:", error)
    throw error
  }
}

// Dupliquer un produit
export const duplicateProduct = async (productId: string, userId: string) => {
  try {
    const { data: originalProduct, error } = await supabase.from("products").select("*").eq("id", productId).single()

    if (error) throw error

    const duplicatedProduct = {
      ...originalProduct,
      id: undefined,
      name: `${originalProduct.name} (Copie)`,
      created_at: undefined,
      updated_at: undefined,
    }

    const { data: newProduct, error: createError } = await supabase
      .from("products")
      .insert([duplicatedProduct])
      .select()
      .single()

    if (createError) throw createError
    return newProduct
  } catch (error) {
    console.error("Erreur duplication produit:", error)
    throw error
  }
}

// Planifier la publication d'un produit
export const scheduleProductPublication = async (productId: string, publishDate: string) => {
  try {
    const { data, error } = await supabase
      .from("products")
      .update({
        scheduled_publish_date: publishDate,
        is_active: false, // Désactiver jusqu'à la date de publication
      })
      .eq("id", productId)
      .select()
      .single()

    if (error) throw error
    return data
  } catch (error) {
    console.error("Erreur planification produit:", error)
    throw error
  }
}

// Incrémenter les vues d'un produit
export const incrementProductViews = async (productId: string) => {
  try {
    // Récupérer le nombre de vues actuel
    const { data: currentProduct, error: getError } = await supabase
      .from("products")
      .select("view_count")
      .eq("id", productId)
      .single()

    if (getError) throw getError

    // Incrémenter et mettre à jour
    const newViewCount = (currentProduct?.view_count || 0) + 1

    const { error: updateError } = await supabase
      .from("products")
      .update({ view_count: newViewCount })
      .eq("id", productId)

    if (updateError) throw updateError

    console.log(`👁️ Vues incrémentées pour produit ${productId}: ${newViewCount}`)
  } catch (error) {
    console.error("Erreur incrémentation vues:", error)
  }
}

// Obtenir les statistiques des produits
export const getProductStats = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from("products")
      .select("id, name, view_count, quantity, price")
      .eq("user_id", userId)
      .order("view_count", { ascending: false })

    if (error) throw error
    return data || []
  } catch (error) {
    console.error("Erreur stats produits:", error)
    return []
  }
}

// ANALYTICS AVANCÉS

// Obtenir les heures de vente les plus actives
export const getSalesHeatmap = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from("orders")
      .select("created_at, total_amount")
      .eq("user_id", userId)
      .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())

    if (error) throw error

    // Analyser par heure et jour de la semaine
    const heatmapData = (data || []).reduce((acc: any, order: any) => {
      const date = new Date(order.created_at)
      const hour = date.getHours()
      const dayOfWeek = date.getDay()

      const key = `${dayOfWeek}-${hour}`
      if (!acc[key]) {
        acc[key] = { count: 0, total: 0, hour, dayOfWeek }
      }
      acc[key].count += 1
      acc[key].total += Number(order.total_amount)

      return acc
    }, {})

    return Object.values(heatmapData)
  } catch (error) {
    console.error("Erreur heatmap ventes:", error)
    return []
  }
}

// Obtenir la répartition géographique des clients
export const getClientGeography = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from("orders")
      .select("client_address")
      .eq("user_id", userId)
      .not("client_address", "is", null)

    if (error) throw error

    // Analyser les villes mentionnées dans les adresses
    const cityCount = (data || []).reduce((acc: any, order: any) => {
      const address = order.client_address.toLowerCase()
      // Logique simple pour détecter les villes (à améliorer)
      const cities = ["casablanca", "rabat", "marrakech", "fès", "agadir", "tanger"]

      cities.forEach((city) => {
        if (address.includes(city)) {
          acc[city] = (acc[city] || 0) + 1
        }
      })

      return acc
    }, {})

    return Object.entries(cityCount).map(([city, count]) => ({
      city: city.charAt(0).toUpperCase() + city.slice(1),
      count,
    }))
  } catch (error) {
    console.error("Erreur géographie clients:", error)
    return []
  }
}

// Calculer le temps moyen de traitement des commandes
export const getAverageProcessingTime = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from("orders")
      .select("processing_time_minutes")
      .eq("user_id", userId)
      .not("processing_time_minutes", "is", null)

    if (error) throw error

    if (!data || data.length === 0) return 0

    const total = data.reduce((sum, order) => sum + (order.processing_time_minutes || 0), 0)
    return Math.round(total / data.length)
  } catch (error) {
    console.error("Erreur temps traitement:", error)
    return 0
  }
}
