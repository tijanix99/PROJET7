"use client"

import { createClient } from "@supabase/supabase-js"

// Configuration Supabase avec vos informations
const supabaseUrl = "https://jwxtcnjcnxwtuwqizhkq.supabase.co"
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3eHRjbmpjbnh3dHV3cWl6aGtxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk5MTE0NDcsImV4cCI6MjA2NTQ4NzQ0N30.srb73bSz_U6j2ahMp3WnO1_VJp0sqsWt24L0KuzvhDY"

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Hook pour obtenir l'utilisateur actuel
export const getCurrentUser = async () => {
  const {
    data: { user },
  } = await supabase.auth.getUser()
  return user
}

// Hook pour l'authentification
export const signUp = async (email: string, password: string, userData: any) => {
  try {
    // 1. Créer l'utilisateur avec Supabase Auth
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: userData.fullName,
        },
      },
    })

    if (error) throw error

    // 2. Si l'utilisateur est créé avec succès
    if (data.user) {
      // Attendre que l'utilisateur soit complètement créé dans auth.users
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // 3. Créer le profil utilisateur dans notre table personnalisée
      try {
        const { error: profileError } = await supabase.from("users").insert([
          {
            id: data.user.id, // Utiliser l'ID de Supabase Auth
            full_name: userData.fullName,
            email: userData.email,
            whatsapp_number: userData.whatsappNumber || null,
            city: userData.city || null,
            shop_name: userData.shopName || null,
          },
        ])

        if (profileError) {
          console.error("Erreur création profil:", profileError)
          // Si c'est une erreur de contrainte, on peut continuer
          if (!profileError.message.includes("violates")) {
            throw profileError
          }
        }
      } catch (profileError: any) {
        console.error("Erreur profil:", profileError)
        // Ne pas faire échouer l'inscription
      }

      // 4. Créer les paramètres par défaut
      try {
        const { error: settingsError } = await supabase.from("user_settings").insert([
          {
            user_id: data.user.id,
          },
        ])

        if (settingsError) {
          console.error("Erreur création paramètres:", settingsError)
        }
      } catch (settingsError) {
        console.error("Erreur paramètres:", settingsError)
      }
    }

    return data
  } catch (error: any) {
    console.error("Erreur signUp:", error)
    throw error
  }
}

export const signIn = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  })

  if (error) throw error
  return data
}

export const signOut = async () => {
  const { error } = await supabase.auth.signOut()
  if (error) throw error
}

// Vérifier si l'utilisateur est connecté
export const checkAuthStatus = () => {
  return supabase.auth.onAuthStateChange((event, session) => {
    if (event === "SIGNED_IN") {
      console.log("Utilisateur connecté:", session?.user)
    } else if (event === "SIGNED_OUT") {
      console.log("Utilisateur déconnecté")
    }
  })
}
