import { supabase } from "./supabase-client"

// Upload d'image produit (version robuste)
export const uploadProductImage = async (file: File, userId: string, productId?: string) => {
  try {
    // Vérifier que le fichier est valide
    if (!file || file.size === 0) {
      throw new Error("Fichier invalide")
    }

    // Vérifier la taille (5MB max)
    if (file.size > 5 * 1024 * 1024) {
      throw new Error("L'image ne doit pas dépasser 5MB")
    }

    // Vérifier le type
    if (!file.type.startsWith("image/")) {
      throw new Error("Le fichier doit être une image")
    }

    // Générer un nom de fichier unique
    const fileExt = file.name.split(".").pop()?.toLowerCase()
    const timestamp = Date.now()
    const randomId = Math.random().toString(36).substring(2, 15)
    const fileName = `${userId}/${productId || timestamp}-${randomId}.${fileExt}`

    console.log("🖼️ Upload de l'image:", fileName, `(${(file.size / 1024 / 1024).toFixed(2)}MB)`)

    // Upload vers Supabase Storage
    const { data, error } = await supabase.storage.from("product-images").upload(fileName, file, {
      cacheControl: "3600",
      upsert: true,
    })

    if (error) {
      console.error("❌ Erreur upload:", error)

      // Messages d'erreur spécifiques
      if (error.message.includes("Bucket not found")) {
        throw new Error(
          "Le stockage d'images n'est pas configuré. Veuillez suivre le guide GUIDE-STORAGE.md pour configurer le bucket 'product-images'.",
        )
      }
      if (error.message.includes("policy") || error.message.includes("RLS")) {
        throw new Error(
          "Permissions insuffisantes. Vérifiez les politiques RLS du bucket 'product-images' dans Supabase Dashboard.",
        )
      }
      if (error.message.includes("size") || error.message.includes("limit")) {
        throw new Error("L'image est trop volumineuse (max 5MB).")
      }
      if (error.message.includes("mime") || error.message.includes("type")) {
        throw new Error("Type de fichier non autorisé. Utilisez JPG, PNG, WEBP ou GIF.")
      }

      throw new Error(`Erreur upload: ${error.message}`)
    }

    // Obtenir l'URL publique
    const {
      data: { publicUrl },
    } = supabase.storage.from("product-images").getPublicUrl(fileName)

    console.log("✅ Image uploadée avec succès:", publicUrl)
    return publicUrl
  } catch (error: any) {
    console.error("❌ Erreur uploadProductImage:", error)
    throw error
  }
}

// Supprimer une image produit
export const deleteProductImage = async (imageUrl: string) => {
  try {
    if (!imageUrl) return

    // Extraire le chemin du fichier de l'URL
    const urlParts = imageUrl.split("/product-images/")
    if (urlParts.length < 2) {
      console.log("⚠️ URL d'image invalide:", imageUrl)
      return
    }

    const filePath = urlParts[1].split("?")[0] // Supprimer les paramètres de requête
    console.log("🗑️ Suppression de l'image:", filePath)

    const { error } = await supabase.storage.from("product-images").remove([filePath])

    if (error) {
      console.error("❌ Erreur suppression image:", error)
    } else {
      console.log("✅ Image supprimée avec succès")
    }
  } catch (error) {
    console.error("❌ Erreur deleteProductImage:", error)
  }
}

// Redimensionner l'image avant upload
export const resizeImage = (file: File, maxWidth = 800, maxHeight = 600): Promise<File> => {
  return new Promise((resolve) => {
    const canvas = document.createElement("canvas")
    const ctx = canvas.getContext("2d")
    const img = new Image()

    img.onload = () => {
      // Calculer les nouvelles dimensions
      let { width, height } = img

      if (width > height) {
        if (width > maxWidth) {
          height = (height * maxWidth) / width
          width = maxWidth
        }
      } else {
        if (height > maxHeight) {
          width = (width * maxHeight) / height
          height = maxHeight
        }
      }

      canvas.width = width
      canvas.height = height

      // Dessiner l'image redimensionnée
      ctx?.drawImage(img, 0, 0, width, height)

      canvas.toBlob(
        (blob) => {
          if (blob) {
            const resizedFile = new File([blob], file.name, {
              type: file.type,
              lastModified: Date.now(),
            })
            resolve(resizedFile)
          } else {
            resolve(file)
          }
        },
        file.type,
        0.8, // Qualité de compression
      )
    }

    img.onerror = () => {
      console.error("❌ Erreur lors du chargement de l'image")
      resolve(file)
    }

    img.src = URL.createObjectURL(file)
  })
}

// Vérifier si le bucket existe
export const checkBucketExists = async () => {
  try {
    const { data: buckets, error } = await supabase.storage.listBuckets()

    if (error) {
      console.error("❌ Erreur vérification buckets:", error)
      return false
    }

    const bucketExists = buckets?.some((bucket) => bucket.id === "product-images")
    console.log("🪣 Bucket product-images existe:", bucketExists)

    if (!bucketExists) {
      console.log("💡 Pour créer le bucket, suivez le guide GUIDE-STORAGE.md")
    }

    return bucketExists
  } catch (error) {
    console.error("❌ Erreur checkBucketExists:", error)
    return false
  }
}
