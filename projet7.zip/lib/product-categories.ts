export interface ProductAttribute {
  name: string
  type: "text" | "number" | "select" | "multiselect" | "color" | "boolean"
  required: boolean
  options?: string[]
  placeholder?: string
}

export interface ProductCategory {
  value: string
  label: string
  icon: string
  attributes: ProductAttribute[]
}

// Définition complète de toutes les catégories du monde
export const PRODUCT_CATEGORIES: ProductCategory[] = [
  // 👕 MODE & VÊTEMENTS
  {
    value: "vetements-homme",
    label: "Vêtements Homme",
    icon: "👔",
    attributes: [
      { name: "taille", type: "select", required: true, options: ["XS", "S", "M", "L", "XL", "XXL", "XXXL"] },
      { name: "couleur", type: "color", required: true },
      {
        name: "matiere",
        type: "select",
        required: false,
        options: ["Coton", "Polyester", "Laine", "Lin", "Soie", "Cuir", "Denim"],
      },
      { name: "marque", type: "text", required: false, placeholder: "Ex: Nike, Adidas..." },
      { name: "coupe", type: "select", required: false, options: ["Slim", "Regular", "Loose", "Oversize"] },
    ],
  },
  {
    value: "vetements-femme",
    label: "Vêtements Femme",
    icon: "👗",
    attributes: [
      {
        name: "taille",
        type: "select",
        required: true,
        options: ["XS", "S", "M", "L", "XL", "XXL", "34", "36", "38", "40", "42", "44", "46"],
      },
      { name: "couleur", type: "color", required: true },
      {
        name: "matiere",
        type: "select",
        required: false,
        options: ["Coton", "Polyester", "Laine", "Lin", "Soie", "Cuir", "Denim", "Dentelle"],
      },
      { name: "marque", type: "text", required: false, placeholder: "Ex: Zara, H&M..." },
      { name: "style", type: "select", required: false, options: ["Casual", "Chic", "Sport", "Soirée", "Bureau"] },
    ],
  },
  {
    value: "vetements-enfant",
    label: "Vêtements Enfant",
    icon: "👶",
    attributes: [
      {
        name: "age",
        type: "select",
        required: true,
        options: [
          "0-3 mois",
          "3-6 mois",
          "6-12 mois",
          "1-2 ans",
          "2-3 ans",
          "3-4 ans",
          "4-5 ans",
          "5-6 ans",
          "6-8 ans",
          "8-10 ans",
          "10-12 ans",
          "12-14 ans",
        ],
      },
      { name: "couleur", type: "color", required: true },
      { name: "matiere", type: "select", required: false, options: ["Coton", "Polyester", "Laine", "Bio"] },
      { name: "genre", type: "select", required: true, options: ["Garçon", "Fille", "Mixte"] },
    ],
  },

  // 👟 CHAUSSURES
  {
    value: "chaussures-homme",
    label: "Chaussures Homme",
    icon: "👞",
    attributes: [
      {
        name: "pointure",
        type: "select",
        required: true,
        options: ["39", "40", "41", "42", "43", "44", "45", "46", "47", "48"],
      },
      { name: "couleur", type: "color", required: true },
      {
        name: "type",
        type: "select",
        required: true,
        options: ["Sneakers", "Chaussures de ville", "Bottes", "Sandales", "Chaussures de sport"],
      },
      { name: "matiere", type: "select", required: false, options: ["Cuir", "Synthétique", "Toile", "Daim"] },
      { name: "marque", type: "text", required: false, placeholder: "Ex: Nike, Adidas..." },
    ],
  },
  {
    value: "chaussures-femme",
    label: "Chaussures Femme",
    icon: "👠",
    attributes: [
      { name: "pointure", type: "select", required: true, options: ["35", "36", "37", "38", "39", "40", "41", "42"] },
      { name: "couleur", type: "color", required: true },
      {
        name: "type",
        type: "select",
        required: true,
        options: ["Escarpins", "Sneakers", "Bottes", "Sandales", "Ballerines", "Bottines"],
      },
      {
        name: "hauteur_talon",
        type: "select",
        required: false,
        options: ["Plat", "Petit talon (1-3cm)", "Talon moyen (3-7cm)", "Haut talon (7cm+)"],
      },
      { name: "matiere", type: "select", required: false, options: ["Cuir", "Synthétique", "Toile", "Daim"] },
    ],
  },

  // 💍 BIJOUX & ACCESSOIRES
  {
    value: "bijoux",
    label: "Bijoux",
    icon: "💍",
    attributes: [
      {
        name: "type",
        type: "select",
        required: true,
        options: ["Bague", "Collier", "Bracelet", "Boucles d'oreilles", "Montre", "Broche"],
      },
      {
        name: "matiere",
        type: "select",
        required: true,
        options: ["Or", "Argent", "Acier inoxydable", "Plaqué or", "Fantaisie", "Perles", "Diamant"],
      },
      { name: "couleur", type: "color", required: false },
      { name: "taille", type: "text", required: false, placeholder: "Ex: 54 (pour bague), 45cm (pour collier)" },
      { name: "genre", type: "select", required: true, options: ["Homme", "Femme", "Mixte", "Enfant"] },
    ],
  },
  {
    value: "sacs-maroquinerie",
    label: "Sacs & Maroquinerie",
    icon: "👜",
    attributes: [
      {
        name: "type",
        type: "select",
        required: true,
        options: ["Sac à main", "Sac à dos", "Portefeuille", "Ceinture", "Valise", "Pochette", "Sac de voyage"],
      },
      { name: "couleur", type: "color", required: true },
      { name: "matiere", type: "select", required: true, options: ["Cuir", "Synthétique", "Toile", "Nylon", "Daim"] },
      { name: "taille", type: "select", required: false, options: ["Petit", "Moyen", "Grand", "XL"] },
      { name: "marque", type: "text", required: false, placeholder: "Ex: Louis Vuitton, Hermès..." },
    ],
  },

  // 📱 HIGH-TECH
  {
    value: "smartphones",
    label: "Smartphones",
    icon: "📱",
    attributes: [
      {
        name: "marque",
        type: "select",
        required: true,
        options: ["Apple", "Samsung", "Huawei", "Xiaomi", "OnePlus", "Google", "Sony", "Oppo", "Vivo"],
      },
      { name: "modele", type: "text", required: true, placeholder: "Ex: iPhone 15 Pro, Galaxy S24..." },
      { name: "couleur", type: "color", required: true },
      { name: "stockage", type: "select", required: true, options: ["64GB", "128GB", "256GB", "512GB", "1TB"] },
      {
        name: "etat",
        type: "select",
        required: true,
        options: ["Neuf", "Comme neuf", "Très bon état", "Bon état", "État correct"],
      },
      {
        name: "garantie",
        type: "select",
        required: false,
        options: ["Sous garantie", "Garantie expirée", "Garantie magasin"],
      },
    ],
  },
  {
    value: "ordinateurs",
    label: "Ordinateurs",
    icon: "💻",
    attributes: [
      {
        name: "type",
        type: "select",
        required: true,
        options: ["PC Portable", "PC Fixe", "Mac", "Tablette", "Chromebook"],
      },
      {
        name: "marque",
        type: "select",
        required: true,
        options: ["Apple", "Dell", "HP", "Lenovo", "Asus", "Acer", "MSI", "Microsoft"],
      },
      { name: "processeur", type: "text", required: false, placeholder: "Ex: Intel i7, AMD Ryzen 5..." },
      { name: "ram", type: "select", required: false, options: ["4GB", "8GB", "16GB", "32GB", "64GB"] },
      {
        name: "stockage",
        type: "select",
        required: false,
        options: ["256GB SSD", "512GB SSD", "1TB SSD", "1TB HDD", "2TB HDD"],
      },
      {
        name: "etat",
        type: "select",
        required: true,
        options: ["Neuf", "Comme neuf", "Très bon état", "Bon état", "État correct"],
      },
    ],
  },
  {
    value: "electromenager",
    label: "Électroménager",
    icon: "🏠",
    attributes: [
      {
        name: "type",
        type: "select",
        required: true,
        options: ["Réfrigérateur", "Lave-linge", "Lave-vaisselle", "Four", "Micro-ondes", "Aspirateur", "Cafetière"],
      },
      {
        name: "marque",
        type: "select",
        required: false,
        options: ["Bosch", "Samsung", "LG", "Whirlpool", "Electrolux", "Siemens", "Miele"],
      },
      { name: "couleur", type: "color", required: false },
      { name: "capacite", type: "text", required: false, placeholder: "Ex: 300L, 8kg, 12 couverts..." },
      {
        name: "classe_energetique",
        type: "select",
        required: false,
        options: ["A+++", "A++", "A+", "A", "B", "C", "D"],
      },
    ],
  },

  // 🏠 MAISON & JARDIN
  {
    value: "meubles",
    label: "Meubles",
    icon: "🪑",
    attributes: [
      {
        name: "type",
        type: "select",
        required: true,
        options: ["Canapé", "Fauteuil", "Table", "Chaise", "Lit", "Armoire", "Commode", "Étagère", "Bureau"],
      },
      {
        name: "matiere",
        type: "select",
        required: false,
        options: ["Bois", "Métal", "Plastique", "Verre", "Cuir", "Tissu", "Rotin"],
      },
      { name: "couleur", type: "color", required: false },
      { name: "dimensions", type: "text", required: false, placeholder: "Ex: L200 x P80 x H75 cm" },
      {
        name: "style",
        type: "select",
        required: false,
        options: ["Moderne", "Classique", "Industriel", "Scandinave", "Vintage", "Rustique"],
      },
      {
        name: "etat",
        type: "select",
        required: true,
        options: ["Neuf", "Comme neuf", "Très bon état", "Bon état", "À rénover"],
      },
    ],
  },
  {
    value: "decoration",
    label: "Décoration",
    icon: "🖼️",
    attributes: [
      {
        name: "type",
        type: "select",
        required: true,
        options: ["Tableau", "Miroir", "Vase", "Coussin", "Rideau", "Tapis", "Lampe", "Bougie", "Plante"],
      },
      { name: "couleur", type: "color", required: false },
      {
        name: "matiere",
        type: "select",
        required: false,
        options: ["Bois", "Métal", "Verre", "Céramique", "Tissu", "Plastique", "Pierre"],
      },
      { name: "dimensions", type: "text", required: false, placeholder: "Ex: 50x70 cm" },
      {
        name: "style",
        type: "select",
        required: false,
        options: ["Moderne", "Classique", "Industriel", "Scandinave", "Bohème", "Minimaliste"],
      },
    ],
  },

  // 🚗 AUTOMOBILE
  {
    value: "voitures",
    label: "Voitures",
    icon: "🚗",
    attributes: [
      {
        name: "marque",
        type: "select",
        required: true,
        options: ["Renault", "Peugeot", "Citroën", "BMW", "Mercedes", "Audi", "Volkswagen", "Toyota", "Honda", "Ford"],
      },
      { name: "modele", type: "text", required: true, placeholder: "Ex: Clio, 308, A3..." },
      { name: "annee", type: "number", required: true, placeholder: "Ex: 2020" },
      { name: "kilometrage", type: "number", required: true, placeholder: "Ex: 50000" },
      {
        name: "carburant",
        type: "select",
        required: true,
        options: ["Essence", "Diesel", "Hybride", "Électrique", "GPL"],
      },
      { name: "boite", type: "select", required: true, options: ["Manuelle", "Automatique"] },
    ],
  },
  {
    value: "motos",
    label: "Motos",
    icon: "🏍️",
    attributes: [
      {
        name: "marque",
        type: "select",
        required: true,
        options: ["Yamaha", "Honda", "Kawasaki", "Suzuki", "BMW", "Ducati", "Harley-Davidson", "KTM"],
      },
      { name: "modele", type: "text", required: true, placeholder: "Ex: MT-07, CBR600..." },
      {
        name: "cylindree",
        type: "select",
        required: true,
        options: ["50cc", "125cc", "250cc", "400cc", "600cc", "750cc", "1000cc", "1200cc+"],
      },
      { name: "annee", type: "number", required: true, placeholder: "Ex: 2020" },
      { name: "kilometrage", type: "number", required: true, placeholder: "Ex: 15000" },
    ],
  },

  // 🎮 LOISIRS
  {
    value: "jeux-video",
    label: "Jeux Vidéo",
    icon: "🎮",
    attributes: [
      {
        name: "plateforme",
        type: "select",
        required: true,
        options: ["PlayStation 5", "PlayStation 4", "Xbox Series", "Xbox One", "Nintendo Switch", "PC", "Mobile"],
      },
      {
        name: "genre",
        type: "select",
        required: false,
        options: ["Action", "Aventure", "RPG", "Sport", "Course", "Stratégie", "Simulation", "Puzzle"],
      },
      {
        name: "classification",
        type: "select",
        required: false,
        options: ["PEGI 3", "PEGI 7", "PEGI 12", "PEGI 16", "PEGI 18"],
      },
      {
        name: "etat",
        type: "select",
        required: true,
        options: ["Neuf", "Comme neuf", "Très bon état", "Bon état", "État correct"],
      },
      {
        name: "langue",
        type: "select",
        required: false,
        options: ["Français", "Anglais", "Espagnol", "Allemand", "Italien", "Japonais"],
      },
    ],
  },
  {
    value: "livres",
    label: "Livres",
    icon: "📚",
    attributes: [
      {
        name: "genre",
        type: "select",
        required: false,
        options: [
          "Roman",
          "Science-fiction",
          "Fantasy",
          "Policier",
          "Biographie",
          "Histoire",
          "Sciences",
          "Cuisine",
          "Art",
        ],
      },
      { name: "auteur", type: "text", required: false, placeholder: "Ex: Victor Hugo, J.K. Rowling..." },
      {
        name: "langue",
        type: "select",
        required: true,
        options: ["Français", "Anglais", "Espagnol", "Allemand", "Italien", "Arabe"],
      },
      { name: "format", type: "select", required: true, options: ["Broché", "Relié", "Poche", "Numérique", "Audio"] },
      {
        name: "etat",
        type: "select",
        required: true,
        options: ["Neuf", "Comme neuf", "Très bon état", "Bon état", "État correct"],
      },
      { name: "annee", type: "number", required: false, placeholder: "Année de publication" },
    ],
  },

  // 💄 BEAUTÉ & SANTÉ
  {
    value: "cosmetiques",
    label: "Cosmétiques",
    icon: "💄",
    attributes: [
      {
        name: "type",
        type: "select",
        required: true,
        options: ["Maquillage", "Soin visage", "Soin corps", "Parfum", "Soin cheveux", "Vernis", "Accessoires"],
      },
      { name: "marque", type: "text", required: false, placeholder: "Ex: L'Oréal, Chanel..." },
      { name: "genre", type: "select", required: true, options: ["Femme", "Homme", "Mixte"] },
      {
        name: "type_peau",
        type: "select",
        required: false,
        options: ["Tous types", "Peau sèche", "Peau grasse", "Peau mixte", "Peau sensible"],
      },
      { name: "contenance", type: "text", required: false, placeholder: "Ex: 50ml, 100g..." },
      { name: "bio", type: "select", required: false, options: ["Oui", "Non"] },
    ],
  },

  // 📺 SERVICES DIGITAUX (SANS taille/couleur !)
  {
    value: "abonnement-iptv",
    label: "Abonnements IPTV",
    icon: "📺",
    attributes: [
      { name: "duree", type: "select", required: true, options: ["1 mois", "3 mois", "6 mois", "12 mois", "24 mois"] },
      { name: "qualite", type: "select", required: true, options: ["HD", "Full HD", "4K", "8K"] },
      {
        name: "nb_connexions",
        type: "select",
        required: true,
        options: ["1 connexion", "2 connexions", "3 connexions", "5 connexions", "Illimité"],
      },
      {
        name: "contenu",
        type: "multiselect",
        required: true,
        options: ["Chaînes françaises", "Chaînes arabes", "Chaînes anglaises", "Sport", "Cinéma", "Séries", "Enfants"],
      },
      {
        name: "support",
        type: "multiselect",
        required: false,
        options: ["Android", "iOS", "Smart TV", "PC/Mac", "Mag Box", "Enigma2"],
      },
    ],
  },
  {
    value: "logiciels",
    label: "Logiciels",
    icon: "💿",
    attributes: [
      {
        name: "type",
        type: "select",
        required: true,
        options: ["Antivirus", "Office", "Design", "Développement", "Jeux", "Multimédia", "Utilitaires"],
      },
      {
        name: "licence",
        type: "select",
        required: true,
        options: ["Licence à vie", "Abonnement 1 an", "Abonnement mensuel", "Version d'essai"],
      },
      {
        name: "plateforme",
        type: "multiselect",
        required: true,
        options: ["Windows", "Mac", "Linux", "Android", "iOS"],
      },
      {
        name: "nb_appareils",
        type: "select",
        required: false,
        options: ["1 appareil", "3 appareils", "5 appareils", "Illimité"],
      },
      { name: "langue", type: "select", required: false, options: ["Français", "Anglais", "Multilingue"] },
    ],
  },
  {
    value: "cours-en-ligne",
    label: "Cours en ligne",
    icon: "🎓",
    attributes: [
      {
        name: "domaine",
        type: "select",
        required: true,
        options: ["Informatique", "Marketing", "Design", "Langues", "Musique", "Cuisine", "Sport", "Business"],
      },
      { name: "niveau", type: "select", required: true, options: ["Débutant", "Intermédiaire", "Avancé", "Expert"] },
      { name: "duree", type: "text", required: false, placeholder: "Ex: 10 heures, 5 semaines..." },
      { name: "langue", type: "select", required: true, options: ["Français", "Anglais", "Espagnol", "Allemand"] },
      { name: "certificat", type: "select", required: false, options: ["Avec certificat", "Sans certificat"] },
    ],
  },

  // 🏠 IMMOBILIER
  {
    value: "immobilier-vente",
    label: "Immobilier - Vente",
    icon: "🏡",
    attributes: [
      {
        name: "type",
        type: "select",
        required: true,
        options: ["Appartement", "Maison", "Studio", "Loft", "Villa", "Terrain", "Local commercial"],
      },
      { name: "surface", type: "number", required: true, placeholder: "Surface en m²" },
      {
        name: "nb_pieces",
        type: "select",
        required: false,
        options: ["1 pièce", "2 pièces", "3 pièces", "4 pièces", "5 pièces", "6+ pièces"],
      },
      { name: "ville", type: "text", required: true, placeholder: "Ex: Casablanca, Rabat..." },
      { name: "quartier", type: "text", required: false, placeholder: "Ex: Maarif, Agdal..." },
      {
        name: "etage",
        type: "select",
        required: false,
        options: ["RDC", "1er étage", "2ème étage", "3ème étage", "4ème étage", "5ème étage+"],
      },
    ],
  },
  {
    value: "immobilier-location",
    label: "Immobilier - Location",
    icon: "🏠",
    attributes: [
      {
        name: "type",
        type: "select",
        required: true,
        options: ["Appartement", "Maison", "Studio", "Chambre", "Villa", "Local commercial"],
      },
      { name: "surface", type: "number", required: true, placeholder: "Surface en m²" },
      {
        name: "nb_pieces",
        type: "select",
        required: false,
        options: ["1 pièce", "2 pièces", "3 pièces", "4 pièces", "5 pièces", "6+ pièces"],
      },
      { name: "ville", type: "text", required: true, placeholder: "Ex: Casablanca, Rabat..." },
      { name: "meuble", type: "select", required: true, options: ["Meublé", "Non meublé", "Semi-meublé"] },
      { name: "charges", type: "select", required: false, options: ["Charges incluses", "Charges en plus"] },
    ],
  },

  // 🎨 ART & COLLECTION
  {
    value: "art-collection",
    label: "Art & Collection",
    icon: "🎨",
    attributes: [
      {
        name: "type",
        type: "select",
        required: true,
        options: ["Peinture", "Sculpture", "Photographie", "Estampe", "Céramique", "Antiquité", "Monnaie", "Timbre"],
      },
      { name: "epoque", type: "text", required: false, placeholder: "Ex: XIXe siècle, Contemporain..." },
      { name: "artiste", type: "text", required: false, placeholder: "Nom de l'artiste" },
      { name: "dimensions", type: "text", required: false, placeholder: "Ex: 50x70 cm" },
      { name: "technique", type: "text", required: false, placeholder: "Ex: Huile sur toile, Bronze..." },
      {
        name: "authenticite",
        type: "select",
        required: false,
        options: ["Authentifié", "Attribution", "École de", "D'après"],
      },
    ],
  },

  // 🏃 SPORT & LOISIRS
  {
    value: "equipement-sport",
    label: "Équipement Sport",
    icon: "⚽",
    attributes: [
      {
        name: "sport",
        type: "select",
        required: true,
        options: ["Football", "Basketball", "Tennis", "Running", "Fitness", "Cyclisme", "Natation", "Ski", "Golf"],
      },
      { name: "type", type: "select", required: true, options: ["Vêtement", "Chaussures", "Équipement", "Accessoire"] },
      { name: "taille", type: "select", required: false, options: ["XS", "S", "M", "L", "XL", "XXL"] },
      { name: "couleur", type: "color", required: false },
      { name: "marque", type: "text", required: false, placeholder: "Ex: Nike, Adidas, Decathlon..." },
      { name: "etat", type: "select", required: true, options: ["Neuf", "Comme neuf", "Très bon état", "Bon état"] },
    ],
  },

  // 🎵 MUSIQUE & INSTRUMENTS
  {
    value: "instruments-musique",
    label: "Instruments de Musique",
    icon: "🎸",
    attributes: [
      {
        name: "type",
        type: "select",
        required: true,
        options: ["Guitare", "Piano", "Batterie", "Violon", "Saxophone", "Flûte", "Trompette", "Synthétiseur"],
      },
      { name: "marque", type: "text", required: false, placeholder: "Ex: Yamaha, Fender..." },
      { name: "modele", type: "text", required: false, placeholder: "Modèle spécifique" },
      {
        name: "etat",
        type: "select",
        required: true,
        options: ["Neuf", "Comme neuf", "Très bon état", "Bon état", "À réviser"],
      },
      {
        name: "accessoires",
        type: "multiselect",
        required: false,
        options: ["Étui", "Archet", "Médiators", "Partitions", "Support", "Amplificateur"],
      },
    ],
  },

  // 🐕 ANIMAUX
  {
    value: "animaux",
    label: "Animaux",
    icon: "🐕",
    attributes: [
      {
        name: "type",
        type: "select",
        required: true,
        options: ["Chien", "Chat", "Oiseau", "Poisson", "Rongeur", "Reptile", "Cheval"],
      },
      { name: "race", type: "text", required: false, placeholder: "Ex: Labrador, Persan..." },
      { name: "age", type: "text", required: false, placeholder: "Ex: 2 ans, 6 mois..." },
      { name: "sexe", type: "select", required: false, options: ["Mâle", "Femelle"] },
      {
        name: "vaccine",
        type: "select",
        required: false,
        options: ["Vacciné", "Non vacciné", "Partiellement vacciné"],
      },
      { name: "pedigree", type: "select", required: false, options: ["Avec pedigree", "Sans pedigree"] },
    ],
  },
]

// Fonctions utilitaires
export const getMainCategories = () => {
  return PRODUCT_CATEGORIES.map((cat) => ({
    value: cat.value,
    label: cat.label,
    icon: cat.icon,
  }))
}

export const getCategoryAttributes = (categoryValue: string): ProductAttribute[] => {
  const category = PRODUCT_CATEGORIES.find((cat) => cat.value === categoryValue)
  return category?.attributes || []
}

export const getCategoryByValue = (value: string) => {
  return PRODUCT_CATEGORIES.find((cat) => cat.value === value)
}
