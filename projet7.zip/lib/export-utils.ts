import jsPDF from "jspdf"
import * as XLSX from "xlsx"
import { formatMAD } from "./utils"

// EXPORT PDF DES COMMANDES
export const exportOrdersToPDF = (orders: any[], title = "Liste des Commandes") => {
  const doc = new jsPDF()

  // En-tête
  doc.setFontSize(20)
  doc.text(title, 20, 20)
  doc.setFontSize(12)
  doc.text(`Généré le ${new Date().toLocaleDateString("fr-FR")}`, 20, 30)

  let yPosition = 50

  orders.forEach((order, index) => {
    if (yPosition > 250) {
      doc.addPage()
      yPosition = 20
    }

    doc.setFontSize(14)
    doc.text(`Commande #${order.order_number || order.id.slice(0, 8)}`, 20, yPosition)
    yPosition += 10

    doc.setFontSize(10)
    doc.text(`Client: ${order.client_name}`, 20, yPosition)
    doc.text(`Total: ${formatMAD(order.total_amount)}`, 120, yPosition)
    yPosition += 7

    doc.text(`Date: ${new Date(order.created_at).toLocaleDateString("fr-FR")}`, 20, yPosition)
    doc.text(`Statut: ${getStatusLabel(order.status)}`, 120, yPosition)
    yPosition += 15
  })

  doc.save(`commandes_${new Date().toISOString().split("T")[0]}.pdf`)
}

// EXPORT CSV DES COMMANDES - VERSION NAVIGATEUR
export const exportOrdersToCSV = (orders: any[]) => {
  try {
    console.log("🔄 Export CSV démarré avec", orders.length, "commandes")

    const csvData = orders.map((order) => ({
      "Numéro Commande": order.order_number || order.id.slice(0, 8),
      Client: order.client_name,
      Téléphone: order.client_phone || "",
      Adresse: order.client_address || "",
      "Total (MAD)": order.total_amount,
      Statut: getStatusLabel(order.status),
      Date: new Date(order.created_at).toLocaleDateString("fr-FR"),
      Notes: order.notes || "",
    }))

    // Créer le worksheet
    const ws = XLSX.utils.json_to_sheet(csvData)

    // Créer le workbook
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, "Commandes")

    // Générer les données CSV en tant que string
    const csvString = XLSX.utils.sheet_to_csv(ws)

    // Créer un Blob avec les données CSV
    const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" })

    // Créer un lien de téléchargement
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", `commandes_${new Date().toISOString().split("T")[0]}.csv`)
    link.style.visibility = "hidden"

    // Ajouter au DOM, cliquer et supprimer
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    console.log("✅ Export CSV terminé")
  } catch (error) {
    console.error("❌ Erreur export CSV:", error)
    throw new Error("Impossible d'exporter en CSV: " + error.message)
  }
}

// EXPORT EXCEL DES COMMANDES - VERSION NAVIGATEUR
export const exportOrdersToExcel = (orders: any[]) => {
  try {
    console.log("🔄 Export Excel démarré avec", orders.length, "commandes")

    const excelData = orders.map((order) => ({
      "Numéro Commande": order.order_number || order.id.slice(0, 8),
      Client: order.client_name,
      Téléphone: order.client_phone || "",
      Adresse: order.client_address || "",
      "Total (د.م)": order.total_amount,
      Statut: getStatusLabel(order.status),
      Date: new Date(order.created_at).toLocaleDateString("fr-FR"),
      Notes: order.notes || "",
    }))

    // Créer le worksheet
    const ws = XLSX.utils.json_to_sheet(excelData)

    // Créer le workbook
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, "Commandes")

    // Générer les données Excel en tant que buffer
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" })

    // Créer un Blob avec les données Excel
    const blob = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
    })

    // Créer un lien de téléchargement
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", `commandes_${new Date().toISOString().split("T")[0]}.xlsx`)
    link.style.visibility = "hidden"

    // Ajouter au DOM, cliquer et supprimer
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    console.log("✅ Export Excel terminé")
  } catch (error) {
    console.error("❌ Erreur export Excel:", error)
    throw new Error("Impossible d'exporter en Excel: " + error.message)
  }
}

// GÉNÉRATION DE FACTURE PDF CORRIGÉE
export const generateInvoicePDF = async (order: any, userProfile: any) => {
  console.log("🧾 Génération facture pour commande:", order.id)
  console.log("📦 Items de la commande:", order.items)

  const doc = new jsPDF()

  // En-tête facture
  doc.setFontSize(24)
  doc.setTextColor(59, 130, 246) // Bleu
  doc.text("FACTURE", 20, 30)

  // Informations boutique (récupérées du profil)
  doc.setFontSize(12)
  doc.setTextColor(0, 0, 0) // Noir
  doc.text(userProfile?.shop_name || userProfile?.full_name || "Ma Boutique", 20, 50)
  if (userProfile?.city) {
    doc.text(`${userProfile.city}, Maroc`, 20, 60)
  }
  if (userProfile?.phone) {
    doc.text(`Tél: ${userProfile.phone}`, 20, 70)
  }
  if (userProfile?.email) {
    doc.text(`Email: ${userProfile.email}`, 20, 80)
  }

  // Numéro facture et date
  doc.text(`Facture N°: ${order.order_number || order.id.slice(0, 8)}`, 120, 50)
  doc.text(`Date: ${new Date(order.created_at).toLocaleDateString("fr-FR")}`, 120, 60)
  doc.text(`Statut: ${getStatusLabel(order.status)}`, 120, 70)

  // Informations client
  doc.setFontSize(14)
  doc.setTextColor(59, 130, 246)
  doc.text("FACTURER À:", 20, 100)
  doc.setFontSize(12)
  doc.setTextColor(0, 0, 0)
  doc.text(order.client_name, 20, 110)
  if (order.client_phone) {
    doc.text(`Tél: ${order.client_phone}`, 20, 120)
  }
  if (order.client_address) {
    // Diviser l'adresse si elle est trop longue
    const addressLines = doc.splitTextToSize(order.client_address, 80)
    let yPos = 130
    addressLines.forEach((line: string) => {
      doc.text(line, 20, yPos)
      yPos += 7
    })
  }

  // Tableau des produits
  let yPos = 160
  doc.setFontSize(12)
  doc.setTextColor(59, 130, 246)
  doc.text("PRODUIT", 20, yPos)
  doc.text("QTÉ", 100, yPos)
  doc.text("PRIX UNIT.", 130, yPos)
  doc.text("TOTAL", 170, yPos)

  yPos += 5
  doc.setLineWidth(0.5)
  doc.setDrawColor(59, 130, 246)
  doc.line(20, yPos, 190, yPos) // Ligne de séparation
  yPos += 10

  doc.setTextColor(0, 0, 0)
  doc.setFontSize(10)

  // Items avec vraies données - CORRECTION ICI
  if (order.items && Array.isArray(order.items) && order.items.length > 0) {
    console.log("✅ Items trouvés:", order.items.length)
    order.items.forEach((item: any, index: number) => {
      console.log(`📦 Item ${index + 1}:`, item)

      const productName = item.product?.name || item.name || "Produit"
      const quantity = item.quantity || 1
      const unitPrice = Number(item.price) || 0
      const totalPrice = unitPrice * quantity

      // Nom du produit (tronqué si trop long)
      const truncatedName = productName.length > 25 ? productName.substring(0, 25) + "..." : productName
      doc.text(truncatedName, 20, yPos)
      doc.text(quantity.toString(), 105, yPos)
      doc.text(formatMAD(unitPrice), 130, yPos)
      doc.text(formatMAD(totalPrice), 170, yPos)
      yPos += 8
    })
  } else {
    console.log("❌ Aucun item trouvé, génération d'items factices basés sur le total")
    // Si pas d'items, créer une ligne générique basée sur le total
    doc.text("Commande complète", 20, yPos)
    doc.text("1", 105, yPos)
    doc.text(formatMAD(Number(order.total_amount)), 130, yPos)
    doc.text(formatMAD(Number(order.total_amount)), 170, yPos)
    yPos += 8
  }

  // Ligne de séparation avant total
  yPos += 5
  doc.setLineWidth(0.5)
  doc.setDrawColor(200, 200, 200)
  doc.line(20, yPos, 190, yPos)
  yPos += 15

  // Total
  doc.setFontSize(16)
  doc.setTextColor(59, 130, 246)
  doc.text(`TOTAL: ${formatMAD(Number(order.total_amount))}`, 130, yPos)

  // Notes si présentes
  if (order.notes) {
    yPos += 20
    doc.setFontSize(10)
    doc.setTextColor(0, 0, 0)
    doc.text("Notes:", 20, yPos)
    yPos += 7
    const noteLines = doc.splitTextToSize(order.notes, 170)
    noteLines.forEach((line: string) => {
      doc.text(line, 20, yPos)
      yPos += 5
    })
  }

  // Pied de page
  doc.setFontSize(10)
  doc.setTextColor(100, 100, 100)
  doc.text("Merci pour votre confiance !", 20, 280)
  doc.text(`Généré le ${new Date().toLocaleDateString("fr-FR")} à ${new Date().toLocaleTimeString("fr-FR")}`, 120, 280)

  doc.save(`facture_${order.order_number || order.id.slice(0, 8)}.pdf`)
}

// GÉNÉRATION D'ÉTIQUETTE COLIS
export const generateShippingLabel = (order: any) => {
  const doc = new jsPDF()

  doc.setFontSize(16)
  doc.text("ÉTIQUETTE COLIS", 20, 20)

  // Informations expéditeur (à personnaliser)
  doc.setFontSize(12)
  doc.text("EXPÉDITEUR:", 20, 40)
  doc.text("Votre Boutique", 20, 50)
  doc.text("Votre Adresse", 20, 60)

  // Informations destinataire
  doc.text("DESTINATAIRE:", 20, 80)
  doc.setFontSize(14)
  doc.text(order.client_name, 20, 90)
  doc.text(order.client_phone || "", 20, 100)
  doc.text(order.client_address || "", 20, 110)

  // Numéro de commande
  doc.setFontSize(16)
  doc.text(`Commande: ${order.order_number || order.id.slice(0, 8)}`, 20, 140)

  doc.save(`etiquette_${order.order_number || order.id.slice(0, 8)}.pdf`)
}

// GÉNÉRATION CATALOGUE PDF AMÉLIORÉ
export const generateCatalogPDF = async (products: any[], userProfile: any) => {
  const doc = new jsPDF()

  // En-tête du catalogue
  doc.setFontSize(24)
  doc.setTextColor(59, 130, 246)
  doc.text(userProfile?.shop_name || "Mon Catalogue", 20, 20)

  doc.setFontSize(12)
  doc.setTextColor(0, 0, 0)
  doc.text(`Catalogue Produits - ${new Date().toLocaleDateString("fr-FR")}`, 20, 30)

  if (userProfile?.city) {
    doc.text(`${userProfile.city}, Maroc`, 20, 40)
  }
  if (userProfile?.phone) {
    doc.text(`Contact: ${userProfile.phone}`, 120, 40)
  }

  let yPosition = 60
  let productCount = 0

  const activeProducts = products.filter((p) => p.is_active)

  activeProducts.forEach((product, index) => {
    if (yPosition > 250) {
      doc.addPage()
      yPosition = 20
    }

    productCount++

    // Numéro et nom du produit
    doc.setFontSize(14)
    doc.setTextColor(59, 130, 246)
    doc.text(`${productCount}. ${product.name}`, 20, yPosition)
    yPosition += 10

    // Prix et stock
    doc.setFontSize(12)
    doc.setTextColor(0, 0, 0)
    doc.text(`Prix: ${formatMAD(product.price)}`, 20, yPosition)
    doc.text(`Stock: ${product.quantity} unités`, 100, yPosition)
    doc.text(`Catégorie: ${product.category}`, 150, yPosition)
    yPosition += 10

    // Description
    if (product.description) {
      doc.setFontSize(10)
      doc.setTextColor(80, 80, 80)
      const descLines = doc.splitTextToSize(product.description, 170)
      descLines.slice(0, 2).forEach((line: string) => {
        // Max 2 lignes
        doc.text(line, 20, yPosition)
        yPosition += 5
      })
    }

    // Attributs si présents
    if (product.attributes && Object.keys(product.attributes).length > 0) {
      doc.setFontSize(9)
      doc.setTextColor(100, 100, 100)
      const attrs = Object.entries(product.attributes)
        .map(([key, value]) => `${key}: ${value}`)
        .join(" • ")
      doc.text(attrs.substring(0, 80), 20, yPosition)
      yPosition += 5
    }

    // Ligne de séparation
    doc.setLineWidth(0.2)
    doc.setDrawColor(200, 200, 200)
    doc.line(20, yPosition + 2, 190, yPosition + 2)
    yPosition += 15
  })

  // Résumé en fin de catalogue
  if (yPosition > 240) {
    doc.addPage()
    yPosition = 20
  }

  doc.setFontSize(14)
  doc.setTextColor(59, 130, 246)
  doc.text("RÉSUMÉ DU CATALOGUE", 20, yPosition)
  yPosition += 15

  doc.setFontSize(12)
  doc.setTextColor(0, 0, 0)
  doc.text(`Total produits actifs: ${activeProducts.length}`, 20, yPosition)
  yPosition += 8

  const totalValue = activeProducts.reduce((sum, p) => sum + p.price * p.quantity, 0)
  doc.text(`Valeur totale du stock: ${formatMAD(totalValue)}`, 20, yPosition)
  yPosition += 8

  const categories = [...new Set(activeProducts.map((p) => p.category))]
  doc.text(`Catégories: ${categories.join(", ")}`, 20, yPosition)

  // Pied de page
  doc.setFontSize(10)
  doc.setTextColor(100, 100, 100)
  doc.text(`Catalogue généré le ${new Date().toLocaleDateString("fr-FR")}`, 20, 280)
  doc.text(`${userProfile?.shop_name || "Ma Boutique"} - ${userProfile?.city || "Maroc"}`, 120, 280)

  doc.save(
    `catalogue_${userProfile?.shop_name?.replace(/\s+/g, "_") || "boutique"}_${new Date().toISOString().split("T")[0]}.pdf`,
  )
}

const getStatusLabel = (status: string) => {
  switch (status) {
    case "pending":
      return "En attente"
    case "confirmed":
      return "Confirmée"
    case "shipped":
      return "Expédiée"
    case "delivered":
      return "Livrée"
    default:
      return status
  }
}
