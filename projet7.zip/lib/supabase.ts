import { createClient } from "@supabase/supabase-js"

// Configuration Supabase avec les variables d'environnement
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error("Variables d'environnement Supabase manquantes")
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Client admin pour les opérations côté serveur
export const supabaseAdmin = createClient(supabaseUrl, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
})

// Types pour la base de données
export interface User {
  id: string
  full_name: string
  email: string
  whatsapp_number?: string
  city?: string
  shop_name?: string
  profile_image?: string
  created_at: string
  updated_at: string
}

export interface Product {
  id: string
  user_id: string
  name: string
  image?: string
  quantity: number
  price: number
  category: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface Order {
  id: string
  user_id: string
  client_name: string
  client_phone?: string
  client_address?: string
  total_amount: number
  status: "pending" | "shipped" | "delivered" | "cancelled"
  created_at: string
  updated_at: string
}

export interface OrderItem {
  id: string
  order_id: string
  product_id: string
  quantity: number
  price: number
}

export interface Message {
  id: string
  user_id: string
  whatsapp_number: string
  sender: "client" | "me"
  content: string
  timestamp: string
  status: "sent" | "delivered" | "read"
}

export interface AITrainingData {
  id: string
  user_id: string
  question: string
  answer: string
  category?: string
  created_at: string
}

export interface DailySummary {
  id: string
  user_id: string
  date: string
  total_sales: number
  total_orders: number
  total_messages: number
  created_at: string
}

export interface Settings {
  id: string
  user_id: string
  email_notifications_enabled: boolean
  ia_style: string
  theme: "light" | "dark" | "system"
  language: string
  created_at: string
  updated_at: string
}
