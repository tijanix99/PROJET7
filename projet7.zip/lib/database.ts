import { supabase } from "./supabase-client"

// PROFIL UTILISATEUR
export const getUserProfile = async (userId: string) => {
  try {
    const { data, error } = await supabase.from("users").select("*").eq("id", userId).single()

    if (error && error.code === "PGRST116") {
      // Si le profil n'existe pas, le créer avec les données de base
      const user = await supabase.auth.getUser()
      if (user.data.user) {
        const { data: newProfile, error: createError } = await supabase
          .from("users")
          .insert([
            {
              id: userId,
              full_name: user.data.user.user_metadata?.full_name || "Utilisateur",
              email: user.data.user.email || "",
            },
          ])
          .select()
          .single()

        if (createError) {
          console.error("Erreur création profil automatique:", createError)
          // Retourner un profil par défaut si la création échoue
          return {
            id: userId,
            full_name: user.data.user.user_metadata?.full_name || "Utilisateur",
            email: user.data.user.email || "",
            whatsapp_number: null,
            city: null,
            shop_name: null,
            profile_image: null,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }
        }
        return newProfile
      }
      throw error
    }
    return data
  } catch (error) {
    console.error("Erreur getUserProfile:", error)
    throw error
  }
}

export const createUserProfile = async (userId: string, profileData: any) => {
  try {
    const { data, error } = await supabase
      .from("users")
      .upsert(
        {
          id: userId,
          ...profileData,
          updated_at: new Date().toISOString(),
        },
        {
          onConflict: "id",
        },
      )
      .select()

    if (error) {
      console.error("Erreur createUserProfile:", error)
      throw error
    }
    return data[0]
  } catch (error) {
    console.error("Erreur createUserProfile:", error)
    throw error
  }
}

export const updateUserProfile = async (userId: string, updates: any) => {
  try {
    const { data, error } = await supabase
      .from("users")
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq("id", userId)
      .select()

    if (error) {
      console.error("Erreur updateUserProfile:", error)
      throw error
    }
    return data[0]
  } catch (error) {
    console.error("Erreur updateUserProfile:", error)
    throw error
  }
}

// PRODUITS - AVEC ATTRIBUTS COMPLETS
export const getProducts = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Erreur getProducts:", error)
      throw error
    }

    // Parser les attributs JSON pour chaque produit (si la colonne existe)
    const productsWithParsedAttributes = (data || []).map((product) => ({
      ...product,
      attributes: product.attributes
        ? typeof product.attributes === "string"
          ? (() => {
              try {
                return JSON.parse(product.attributes)
              } catch (e) {
                console.error("Erreur parsing attributs pour produit", product.id, e)
                return {}
              }
            })()
          : product.attributes
        : {}, // Valeur par défaut si pas d'attributs
    }))

    console.log("Produits avec attributs parsés:", productsWithParsedAttributes)
    return productsWithParsedAttributes
  } catch (error) {
    console.error("Erreur getProducts:", error)
    return []
  }
}

export const createProduct = async (productData: any) => {
  try {
    console.log("🚀 Création produit avec données complètes:", productData)

    // Préparer les données de base
    const baseData = {
      user_id: productData.user_id,
      name: productData.name,
      category: productData.category,
      price: productData.price,
      quantity: productData.quantity,
      description: productData.description,
      image: productData.image,
      is_active: productData.is_active || true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }

    // Préparer les données finales avec attributs si fournis
    const dataToInsert = { ...baseData }

    if (productData.attributes && Object.keys(productData.attributes).length > 0) {
      // S'assurer que les attributs sont au format JSON
      const attributesJson =
        typeof productData.attributes === "string" ? productData.attributes : JSON.stringify(productData.attributes)

      dataToInsert.attributes = attributesJson
      console.log("📝 Attributs à insérer:", attributesJson)
    }

    console.log("📦 Données finales à insérer:", dataToInsert)

    // Première tentative avec attributs
    const { data, error } = await supabase.from("products").insert([dataToInsert]).select()

    if (error) {
      console.error("❌ Erreur createProduct:", error)

      // Si l'erreur concerne la colonne attributes, réessayer sans
      if (error.message.includes("attributes") || error.message.includes("column") || error.code === "42703") {
        console.log("⚠️ Colonne attributes non trouvée, insertion sans attributs...")

        const { attributes, ...dataWithoutAttributes } = dataToInsert

        const { data: retryData, error: retryError } = await supabase
          .from("products")
          .insert([dataWithoutAttributes])
          .select()

        if (retryError) {
          console.error("❌ Erreur createProduct (retry):", retryError)
          throw retryError
        }

        console.log("⚠️ Produit créé sans attributs:", retryData)
        console.log("🔧 Conseil: Exécutez le script add-attributes-column.sql pour ajouter le support des attributs")
        return retryData[0]
      }

      throw error
    }

    console.log("✅ Produit créé avec succès:", data)
    return data[0]
  } catch (error) {
    console.error("❌ Erreur createProduct:", error)
    throw error
  }
}

export const updateProduct = async (id: string, updates: any) => {
  try {
    console.log("🔄 Mise à jour produit:", id, updates)

    // Préparer les mises à jour de base
    const baseUpdates = {
      name: updates.name,
      category: updates.category,
      price: updates.price,
      quantity: updates.quantity,
      description: updates.description,
      image: updates.image,
      is_active: updates.is_active,
      updated_at: new Date().toISOString(),
    }

    // Nettoyer les valeurs undefined
    Object.keys(baseUpdates).forEach((key) => {
      if (baseUpdates[key] === undefined) {
        delete baseUpdates[key]
      }
    })

    let updatesToApply = baseUpdates

    // Ajouter les attributs seulement s'ils existent et sont fournis
    if (updates.attributes !== undefined) {
      updatesToApply = {
        ...baseUpdates,
        attributes: typeof updates.attributes === "string" ? updates.attributes : JSON.stringify(updates.attributes),
      }
    }

    console.log("📝 Mises à jour finales:", updatesToApply)

    const { data, error } = await supabase.from("products").update(updatesToApply).eq("id", id).select()

    if (error) {
      // Si l'erreur concerne la colonne attributes, réessayer sans
      if (error.message.includes("attributes") || error.message.includes("column")) {
        console.log("⚠️ Colonne attributes non trouvée, mise à jour sans attributs...")
        const { data: retryData, error: retryError } = await supabase
          .from("products")
          .update(baseUpdates)
          .eq("id", id)
          .select()

        if (retryError) {
          console.error("❌ Erreur updateProduct (retry):", retryError)
          throw retryError
        }

        console.log("✅ Produit mis à jour sans attributs:", retryData)
        return retryData[0]
      }

      console.error("❌ Erreur updateProduct:", error)
      throw error
    }

    console.log("✅ Produit mis à jour:", data)
    return data[0]
  } catch (error) {
    console.error("❌ Erreur updateProduct:", error)
    throw error
  }
}

export const deleteProduct = async (id: string) => {
  try {
    const { error } = await supabase.from("products").delete().eq("id", id)

    if (error) {
      console.error("Erreur deleteProduct:", error)
      throw error
    }
  } catch (error) {
    console.error("Erreur deleteProduct:", error)
    throw error
  }
}

// COMMANDES - AVEC GESTION DU STOCK ET SUPPRESSION
export const getOrders = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from("orders")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Erreur getOrders:", error)
      throw error
    }
    return data || []
  } catch (error) {
    console.error("Erreur getOrders:", error)
    return []
  }
}

export const getOrderWithItems = async (orderId: string) => {
  try {
    // Récupérer la commande
    const { data: order, error: orderError } = await supabase.from("orders").select("*").eq("id", orderId).single()

    if (orderError) {
      console.error("Erreur récupération commande:", orderError)
      throw orderError
    }

    // Récupérer les items de la commande SÉPARÉMENT
    const { data: orderItems, error: itemsError } = await supabase
      .from("order_items")
      .select("*")
      .eq("order_id", orderId)

    if (itemsError) {
      console.error("Erreur récupération items:", itemsError)
      // Continuer sans les items si erreur
      return {
        ...order,
        items: [],
      }
    }

    // Récupérer les détails des produits pour chaque item
    const itemsWithProducts = await Promise.all(
      (orderItems || []).map(async (item) => {
        const { data: product, error: productError } = await supabase
          .from("products")
          .select("id, name, price, image")
          .eq("id", item.product_id)
          .single()

        if (productError) {
          console.error("Erreur récupération produit:", productError)
          return {
            ...item,
            product: null,
          }
        }

        return {
          ...item,
          product,
        }
      }),
    )

    return {
      ...order,
      items: itemsWithProducts,
    }
  } catch (error) {
    console.error("Erreur getOrderWithItems:", error)
    throw error
  }
}

export const createOrder = async (orderData: any, orderItems: any[]) => {
  try {
    console.log("🚀 Création commande avec données:", orderData)
    console.log("📦 Items de commande:", orderItems)

    // Valider le statut avant création
    const validStatuses = ["pending", "confirmed", "shipped", "delivered"]
    if (!validStatuses.includes(orderData.status)) {
      console.warn(`⚠️ Statut invalide: ${orderData.status}, utilisation de 'pending'`)
      orderData.status = "pending"
    }

    // Créer la commande
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert([
        {
          ...orderData,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ])
      .select()
      .single()

    if (orderError) {
      console.error("❌ Erreur création commande:", orderError)
      throw orderError
    }

    console.log("✅ Commande créée:", order)

    // Créer les items de la commande ET décrémenter le stock
    if (orderItems && orderItems.length > 0) {
      const itemsToInsert = orderItems.map((item) => ({
        order_id: order.id,
        product_id: item.product_id,
        quantity: item.quantity,
        price: item.price,
        created_at: new Date().toISOString(),
      }))

      console.log("📝 Insertion des items:", itemsToInsert)

      const { error: itemsError } = await supabase.from("order_items").insert(itemsToInsert)

      if (itemsError) {
        console.error("❌ Erreur création items:", itemsError)
        // Ne pas faire échouer la commande si les items échouent
      } else {
        console.log("✅ Items créés avec succès")

        // DÉCRÉMENTER LE STOCK DES PRODUITS
        console.log("📉 Décrémentation du stock...")
        for (const item of orderItems) {
          try {
            // Récupérer le stock actuel
            const { data: currentProduct, error: getError } = await supabase
              .from("products")
              .select("quantity")
              .eq("id", item.product_id)
              .single()

            if (getError) {
              console.error(`❌ Erreur récupération stock produit ${item.product_id}:`, getError)
              continue
            }

            const newQuantity = Math.max(0, currentProduct.quantity - item.quantity)

            // Mettre à jour le stock
            const { error: updateError } = await supabase
              .from("products")
              .update({
                quantity: newQuantity,
                updated_at: new Date().toISOString(),
              })
              .eq("id", item.product_id)

            if (updateError) {
              console.error(`❌ Erreur mise à jour stock produit ${item.product_id}:`, updateError)
            } else {
              console.log(
                `✅ Stock mis à jour pour produit ${item.product_id}: ${currentProduct.quantity} → ${newQuantity}`,
              )
            }
          } catch (stockError) {
            console.error(`❌ Erreur gestion stock produit ${item.product_id}:`, stockError)
          }
        }
      }
    }

    return order
  } catch (error) {
    console.error("❌ Erreur createOrder:", error)
    throw error
  }
}

export const updateOrderStatus = async (id: string, status: string) => {
  try {
    console.log(`🔄 Mise à jour statut commande ${id} vers ${status}`)

    // Valider le statut avant mise à jour
    const validStatuses = ["pending", "confirmed", "shipped", "delivered"]
    if (!validStatuses.includes(status)) {
      throw new Error(`Statut invalide: ${status}. Statuts valides: ${validStatuses.join(", ")}`)
    }

    // Première tentative de mise à jour
    const { data, error } = await supabase
      .from("orders")
      .update({
        status,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()

    if (error) {
      console.error("❌ Erreur updateOrderStatus:", error)

      // Si c'est une erreur de contrainte, essayer de corriger automatiquement
      if (error.message.includes("check constraint") || error.message.includes("orders_status_check")) {
        console.log("🔧 Tentative de correction automatique de la contrainte...")

        // Essayer de supprimer et recréer la contrainte via une requête SQL
        try {
          await supabase.rpc("exec_sql", {
            sql: `
              ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_status_check;
              ALTER TABLE orders ADD CONSTRAINT orders_status_check 
              CHECK (status IN ('pending', 'confirmed', 'shipped', 'delivered'));
            `,
          })

          // Réessayer la mise à jour
          const { data: retryData, error: retryError } = await supabase
            .from("orders")
            .update({
              status,
              updated_at: new Date().toISOString(),
            })
            .eq("id", id)
            .select()

          if (retryError) {
            throw retryError
          }

          console.log("✅ Statut mis à jour après correction automatique")
          return retryData[0]
        } catch (fixError) {
          console.error("❌ Impossible de corriger automatiquement:", fixError)
          throw new Error(
            `Contrainte de base de données invalide. Veuillez exécuter le script fix-order-status-constraint-v2.sql`,
          )
        }
      }

      throw error
    }

    console.log("✅ Statut mis à jour avec succès:", data)
    return data[0]
  } catch (error) {
    console.error("❌ Erreur updateOrderStatus:", error)
    throw error
  }
}

// NOUVELLE FONCTION : SUPPRIMER UNE COMMANDE AVEC RESTAURATION DU STOCK
export const deleteOrder = async (orderId: string) => {
  try {
    console.log(`🗑️ Suppression commande ${orderId}`)

    // 1. Récupérer les items de la commande pour restaurer le stock
    const { data: orderItems, error: itemsError } = await supabase
      .from("order_items")
      .select("product_id, quantity")
      .eq("order_id", orderId)

    if (itemsError) {
      console.error("❌ Erreur récupération items pour suppression:", itemsError)
      // Continuer quand même la suppression
    }

    // 2. RESTAURER LE STOCK DES PRODUITS
    if (orderItems && orderItems.length > 0) {
      console.log("📈 Restauration du stock...")
      for (const item of orderItems) {
        try {
          // Récupérer le stock actuel
          const { data: currentProduct, error: getError } = await supabase
            .from("products")
            .select("quantity")
            .eq("id", item.product_id)
            .single()

          if (getError) {
            console.error(`❌ Erreur récupération stock produit ${item.product_id}:`, getError)
            continue
          }

          const newQuantity = currentProduct.quantity + item.quantity

          // Mettre à jour le stock (restaurer)
          const { error: updateError } = await supabase
            .from("products")
            .update({
              quantity: newQuantity,
              updated_at: new Date().toISOString(),
            })
            .eq("id", item.product_id)

          if (updateError) {
            console.error(`❌ Erreur restauration stock produit ${item.product_id}:`, updateError)
          } else {
            console.log(
              `✅ Stock restauré pour produit ${item.product_id}: ${currentProduct.quantity} → ${newQuantity} (+${item.quantity})`,
            )
          }
        } catch (stockError) {
          console.error(`❌ Erreur restauration stock produit ${item.product_id}:`, stockError)
        }
      }
    }

    // 3. Supprimer les items de la commande
    const { error: deleteItemsError } = await supabase.from("order_items").delete().eq("order_id", orderId)

    if (deleteItemsError) {
      console.error("❌ Erreur suppression items:", deleteItemsError)
      // Continuer quand même
    } else {
      console.log("✅ Items de commande supprimés")
    }

    // 4. Supprimer la commande
    const { error: deleteOrderError } = await supabase.from("orders").delete().eq("id", orderId)

    if (deleteOrderError) {
      console.error("❌ Erreur suppression commande:", deleteOrderError)
      throw deleteOrderError
    }

    console.log("✅ Commande supprimée avec succès et stock restauré")
    return true
  } catch (error) {
    console.error("❌ Erreur deleteOrder:", error)
    throw error
  }
}

// AUTRES FONCTIONS...
export const getOnboardingStatus = async (userId: string) => {
  try {
    // Vérifier le profil
    const { data: profile } = await supabase.from("users").select("*").eq("id", userId).single()

    // Compter les produits
    const { count: productsCount } = await supabase
      .from("products")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId)

    // Compter les réponses IA
    const { count: aiCount } = await supabase
      .from("ia_training_data")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId)

    // Vérifier première commande
    const { count: ordersCount } = await supabase
      .from("orders")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId)

    return {
      profile_completed: !!(profile?.full_name && profile?.email && profile?.city),
      products_added: productsCount || 0,
      whatsapp_connected: false,
      ai_responses: aiCount || 0,
      first_order_created: (ordersCount || 0) > 0,
      onboarding_completed: false,
    }
  } catch (error) {
    console.error("Erreur onboarding status:", error)
    return {
      profile_completed: false,
      products_added: 0,
      whatsapp_connected: false,
      ai_responses: 0,
      first_order_created: false,
      onboarding_completed: false,
    }
  }
}

export const updateOnboardingStep = async (userId: string, updates: any) => {
  try {
    const { data, error } = await supabase
      .from("user_settings")
      .upsert({ user_id: userId, ...updates, updated_at: new Date().toISOString() })
      .select()

    if (error) throw error
    return data[0]
  } catch (error) {
    console.error("Erreur updateOnboardingStep:", error)
    throw error
  }
}

// OBJECTIF QUOTIDIEN
export const getDailyGoal = async (userId: string) => {
  try {
    const { data, error } = await supabase.from("user_settings").select("daily_goal").eq("user_id", userId).single()

    if (error && error.code !== "PGRST116") throw error
    return data
  } catch (error) {
    console.error("Erreur getDailyGoal:", error)
    return null
  }
}

export const updateDailyGoal = async (userId: string, goal: number) => {
  try {
    const { data, error } = await supabase
      .from("user_settings")
      .upsert({ user_id: userId, daily_goal: goal, updated_at: new Date().toISOString() })
      .select()

    if (error) throw error
    return data[0]
  } catch (error) {
    console.error("Erreur updateDailyGoal:", error)
    throw error
  }
}

export const getTodaySales = async (userId: string) => {
  try {
    const today = new Date().toISOString().split("T")[0]
    const { data, error } = await supabase
      .from("orders")
      .select("total_amount")
      .eq("user_id", userId)
      .gte("created_at", today)

    if (error) throw error
    return data?.reduce((sum, order) => sum + Number(order.total_amount || 0), 0) || 0
  } catch (error) {
    console.error("Erreur getTodaySales:", error)
    return 0
  }
}

// ALERTES PERFORMANCE
export const getPerformanceAlerts = async (userId: string) => {
  try {
    const alerts = []

    // Vérifier les ventes d'aujourd'hui vs hier
    const today = new Date()
    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)

    const todayStr = today.toISOString().split("T")[0]
    const yesterdayStr = yesterday.toISOString().split("T")[0]

    const [todaySales, yesterdaySales] = await Promise.all([
      supabase
        .from("orders")
        .select("total_amount")
        .eq("user_id", userId)
        .gte("created_at", todayStr)
        .then(({ data }) => data?.reduce((sum, order) => sum + Number(order.total_amount || 0), 0) || 0),
      supabase
        .from("orders")
        .select("total_amount")
        .eq("user_id", userId)
        .gte("created_at", yesterdayStr)
        .lt("created_at", todayStr)
        .then(({ data }) => data?.reduce((sum, order) => sum + Number(order.total_amount || 0), 0) || 0),
    ])

    // Alerte de performance des ventes
    if (yesterdaySales > 0) {
      const percentageChange = ((todaySales - yesterdaySales) / yesterdaySales) * 100
      if (percentageChange > 20) {
        alerts.push({
          id: `sales-up-${Date.now()}`,
          type: "success",
          category: "sales",
          title: "🚀 Excellente performance !",
          message: `Vos ventes sont en hausse de ${percentageChange.toFixed(0)}% par rapport à hier (+${(
            todaySales - yesterdaySales
          ).toFixed(2)}€)`,
          timestamp: new Date().toISOString(),
          dismissed: false,
          actionable: false,
        })
      } else if (percentageChange < -20) {
        alerts.push({
          id: `sales-down-${Date.now()}`,
          type: "warning",
          category: "sales",
          title: "📉 Baisse des ventes",
          message: `Vos ventes ont baissé de ${Math.abs(percentageChange).toFixed(
            0,
          )}% par rapport à hier. Peut-être promouvoir vos produits ?`,
          timestamp: new Date().toISOString(),
          dismissed: false,
          actionable: true,
        })
      }
    }

    // Vérifier les produits en rupture
    const { data: outOfStockProducts } = await supabase
      .from("products")
      .select("name")
      .eq("user_id", userId)
      .eq("quantity", 0)
      .eq("is_active", true)

    if (outOfStockProducts && outOfStockProducts.length > 0) {
      alerts.push({
        id: `stock-alert-${Date.now()}`,
        type: "warning",
        category: "stock",
        title: "⚠️ Produits en rupture",
        message: `${outOfStockProducts.length} produit(s) en rupture de stock : ${outOfStockProducts
          .slice(0, 2)
          .map((p) => p.name)
          .join(", ")}${outOfStockProducts.length > 2 ? "..." : ""}`,
        timestamp: new Date().toISOString(),
        dismissed: false,
        actionable: true,
      })
    }

    return alerts
  } catch (error) {
    console.error("Erreur alertes performance:", error)
    return []
  }
}

export const dismissAlert = async (alertId: string) => {
  return Promise.resolve()
}

// CONVERSATIONS ET MESSAGES
export const getConversations = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from("conversations")
      .select("*")
      .eq("user_id", userId)
      .order("last_message_time", { ascending: false })

    if (error) throw error
    return data || []
  } catch (error) {
    console.error("Erreur getConversations:", error)
    return []
  }
}

export const getMessages = async (userId: string, whatsappNumber: string) => {
  try {
    const { data, error } = await supabase
      .from("messages")
      .select("*")
      .eq("user_id", userId)
      .eq("whatsapp_number", whatsappNumber)
      .order("timestamp", { ascending: true })

    if (error) throw error
    return data || []
  } catch (error) {
    console.error("Erreur getMessages:", error)
    return []
  }
}

export const sendMessage = async (messageData: any) => {
  try {
    const { data, error } = await supabase.from("messages").insert([messageData]).select()

    if (error) throw error

    // Mettre à jour la conversation
    await supabase.from("conversations").upsert({
      user_id: messageData.user_id,
      whatsapp_number: messageData.whatsapp_number,
      last_message: messageData.content,
      last_message_time: messageData.timestamp,
    })

    return data[0]
  } catch (error) {
    console.error("Erreur sendMessage:", error)
    throw error
  }
}

// DONNÉES D'ENTRAÎNEMENT IA
export const getAITrainingData = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from("ia_training_data")
      .select("*")
      .eq("user_id", userId)
      .eq("is_active", true)
      .order("created_at", { ascending: false })

    if (error) throw error
    return data || []
  } catch (error) {
    console.error("Erreur getAITrainingData:", error)
    return []
  }
}

export const createAIResponse = async (responseData: any) => {
  try {
    const { data, error } = await supabase.from("ia_training_data").insert([responseData]).select()

    if (error) throw error
    return data[0]
  } catch (error) {
    console.error("Erreur createAIResponse:", error)
    throw error
  }
}

export const deleteAIResponse = async (responseId: string) => {
  try {
    const { error } = await supabase.from("ia_training_data").delete().eq("id", responseId)

    if (error) throw error
  } catch (error) {
    console.error("Erreur deleteAIResponse:", error)
    throw error
  }
}

// PARAMÈTRES UTILISATEUR
export const getUserSettings = async (userId: string) => {
  try {
    const { data, error } = await supabase.from("user_settings").select("*").eq("user_id", userId).single()

    if (error && error.code !== "PGRST116") throw error
    return data
  } catch (error) {
    console.error("Erreur getUserSettings:", error)
    return null
  }
}

export const updateUserSettings = async (userId: string, settings: any) => {
  try {
    const { data, error } = await supabase
      .from("user_settings")
      .upsert({ user_id: userId, ...settings, updated_at: new Date().toISOString() })
      .select()

    if (error) throw error
    return data[0]
  } catch (error) {
    console.error("Erreur updateUserSettings:", error)
    throw error
  }
}

// STATISTIQUES DASHBOARD
export const getDashboardStats = async (userId: string) => {
  try {
    // Ventes totales aujourd'hui
    const today = new Date().toISOString().split("T")[0]
    const { data: todayOrders, error: todayError } = await supabase
      .from("orders")
      .select("total_amount")
      .eq("user_id", userId)
      .gte("created_at", today)

    if (todayError) console.error("Erreur todayOrders:", todayError)

    // Nombre total de commandes
    const { count: totalOrders, error: ordersError } = await supabase
      .from("orders")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId)

    if (ordersError) console.error("Erreur totalOrders:", ordersError)

    // Nombre total de produits
    const { count: totalProducts, error: productsError } = await supabase
      .from("products")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId)

    if (productsError) console.error("Erreur totalProducts:", productsError)

    // Messages non lus
    const { data: conversations, error: conversationsError } = await supabase
      .from("conversations")
      .select("unread_count")
      .eq("user_id", userId)

    if (conversationsError) console.error("Erreur conversations:", conversationsError)

    const unreadMessages = conversations?.reduce((sum, conv) => sum + (conv.unread_count || 0), 0) || 0

    // Ventes de la semaine pour le graphique
    const sevenDaysAgo = new Date()
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)

    const { data: weeklyOrders, error: weeklyError } = await supabase
      .from("orders")
      .select("total_amount, created_at")
      .eq("user_id", userId)
      .gte("created_at", sevenDaysAgo.toISOString())

    if (weeklyError) console.error("Erreur weeklyOrders:", weeklyError)

    return {
      todaySales: todayOrders?.reduce((sum, order) => sum + Number(order.total_amount || 0), 0) || 0,
      totalOrders: totalOrders || 0,
      totalProducts: totalProducts || 0,
      unreadMessages,
      weeklyOrders: weeklyOrders || [],
    }
  } catch (error) {
    console.error("Erreur getDashboardStats:", error)
    return {
      todaySales: 0,
      totalOrders: 0,
      totalProducts: 0,
      unreadMessages: 0,
      weeklyOrders: [],
    }
  }
}
