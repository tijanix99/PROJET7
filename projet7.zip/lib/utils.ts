import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Fonction pour formater les prix en Dirham marocain avec symbole arabe
export function formatPrice(price: number): string {
  return `${price.toFixed(2)} د.م`
}

// Fonction alternative plus simple avec MAD
export function formatMAD(price: number): string {
  return `${price.toFixed(2)} د.م`
}

// Fonction pour formatage simple sans décimales
export function formatMADSimple(price: number): string {
  return `${Math.round(price)} د.م`
}

// VALIDATION NUMÉRO MAROCAIN
export function isValidMoroccanPhone(phone: string): boolean {
  const moroccanPhoneRegex = /^(\+212|0)[5-7][0-9]{8}$/
  return moroccanPhoneRegex.test(phone.replace(/\s/g, ""))
}

// GÉNÉRATION NUMÉRO COMMANDE MAROCAIN
export function generateOrderNumber(): string {
  const prefix = "MA"
  const timestamp = Date.now().toString().slice(-6)
  const random = Math.floor(Math.random() * 100)
    .toString()
    .padStart(2, "0")
  return `${prefix}${timestamp}${random}`
}

// CALCUL TEMPS TRAITEMENT COMMANDE
export function calculateProcessingTime(createdAt: string, updatedAt: string): string {
  const created = new Date(createdAt)
  const updated = new Date(updatedAt)
  const diffMs = updated.getTime() - created.getTime()
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
  const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60))

  if (diffHours > 0) {
    return `${diffHours}h ${diffMinutes}min`
  }
  return `${diffMinutes}min`
}

// DÉTECTION PÉRIODE RAMADAN
export function isRamadanPeriod(): boolean {
  const now = new Date()
  const year = now.getFullYear()
  // Dates approximatives du Ramadan (à ajuster chaque année)
  const ramadanStart = new Date(`${year}-03-10`)
  const ramadanEnd = new Date(`${year}-04-10`)
  return now >= ramadanStart && now <= ramadanEnd
}

// HORAIRES RAMADAN
export function getRamadanHours() {
  return {
    workStart: "09:00",
    workEnd: "17:00",
    breakStart: "19:30",
    breakEnd: "06:00",
  }
}
