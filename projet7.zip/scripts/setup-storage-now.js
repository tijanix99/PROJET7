import { supabase } from "../lib/supabase-client.js"

console.log("🚀 Configuration du stockage d'images...")

async function setupStorage() {
  try {
    // 1. Vérifier la connexion
    console.log("📡 Test de connexion...")
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError) {
      console.error("❌ Erreur d'authentification:", authError.message)
      return
    }

    console.log("✅ Connexion OK")

    // 2. Créer le bucket via l'API
    console.log("🪣 Création du bucket 'product-images'...")

    const { data: buckets, error: listError } = await supabase.storage.listBuckets()

    if (listError) {
      console.error("❌ Erreur listage buckets:", listError.message)
      return
    }

    const bucketExists = buckets?.some((bucket) => bucket.id === "product-images")

    if (bucketExists) {
      console.log("✅ Le bucket 'product-images' existe déjà!")
    } else {
      // Créer le bucket
      const { data: createData, error: createError } = await supabase.storage.createBucket("product-images", {
        public: true,
        fileSizeLimit: 5242880, // 5MB
        allowedMimeTypes: ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif"],
      })

      if (createError) {
        console.error("❌ Erreur création bucket:", createError.message)
        console.log("💡 Vous devez peut-être exécuter le script SQL manuellement dans Supabase Dashboard")
        return
      }

      console.log("✅ Bucket créé avec succès!")
    }

    // 3. Test d'upload
    console.log("🧪 Test d'upload...")

    // Créer un fichier de test
    const testContent = `Test upload - ${new Date().toISOString()}`
    const testFile = new File([testContent], "test.txt", { type: "text/plain" })

    const { data: uploadData, error: uploadError } = await supabase.storage
      .from("product-images")
      .upload(`test/test-${Date.now()}.txt`, testFile)

    if (uploadError) {
      console.error("❌ Test d'upload échoué:", uploadError.message)

      if (uploadError.message.includes("policy") || uploadError.message.includes("RLS")) {
        console.log("💡 Problème de permissions RLS. Exécution du script SQL...")

        // Essayer de créer les politiques via SQL
        const { error: sqlError } = await supabase.rpc("exec_sql", {
          sql: `
            -- Supprimer les anciennes politiques
            DROP POLICY IF EXISTS "Authenticated users can upload images" ON storage.objects;
            DROP POLICY IF EXISTS "Public access to product images" ON storage.objects;
            DROP POLICY IF EXISTS "Users can delete their images" ON storage.objects;
            DROP POLICY IF EXISTS "Users can update their images" ON storage.objects;

            -- Créer des politiques permissives
            CREATE POLICY "Authenticated users can upload images" ON storage.objects
            FOR INSERT WITH CHECK (
              bucket_id = 'product-images' 
              AND auth.role() = 'authenticated'
            );

            CREATE POLICY "Public access to product images" ON storage.objects
            FOR SELECT USING (bucket_id = 'product-images');

            CREATE POLICY "Users can delete their images" ON storage.objects
            FOR DELETE USING (
              bucket_id = 'product-images' 
              AND auth.role() = 'authenticated'
            );

            CREATE POLICY "Users can update their images" ON storage.objects
            FOR UPDATE USING (
              bucket_id = 'product-images' 
              AND auth.role() = 'authenticated'
            );
          `,
        })

        if (sqlError) {
          console.error("❌ Erreur SQL:", sqlError.message)
          console.log(
            "💡 Vous devez exécuter le script 'create-storage-bucket-admin.sql' manuellement dans Supabase SQL Editor",
          )
        } else {
          console.log("✅ Politiques RLS créées!")
        }
      }
    } else {
      console.log("✅ Test d'upload réussi!")

      // Nettoyer le fichier de test
      await supabase.storage.from("product-images").remove([uploadData.path])
      console.log("🧹 Fichier de test supprimé")
    }

    console.log("\n🎉 Configuration terminée!")
    console.log("💡 Rechargez votre page pour voir si l'alerte a disparu")
  } catch (error) {
    console.error("💥 Erreur:", error.message)
  }
}

setupStorage()
