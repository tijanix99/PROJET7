// TEST COMPLET DES OPÉRATIONS CRUD
import { createClient } from "@supabase/supabase-js"

const supabaseUrl = "https://jwxtcnjcnxwtuwqizhkq.supabase.co"
const supabaseServiceKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3eHRjbmpjbnh3dHV3cWl6aGtxIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc0OTkxMTQ0NywiZXhwIjoyMDY1NDg3NDQ3fQ.LHlrYB8Ed4aV6B9x0shMvPersHjCAgHzvUyeJduNA6E"

const supabase = createClient(supabaseUrl, supabaseServiceKey)

async function testCRUDOperations() {
  console.log("🧪 TEST COMPLET DES OPÉRATIONS CRUD")
  console.log("=".repeat(50))

  const testUserId = "12345678-1234-1234-1234-123456789012" // UUID de test

  try {
    // 1. TEST UTILISATEUR
    console.log("\n1. Test création utilisateur...")
    const { data: user, error: userError } = await supabase
      .from("users")
      .upsert({
        id: testUserId,
        full_name: "Test User",
        email: "test@example.com",
        city: "Test City",
      })
      .select()

    if (userError) {
      console.log("❌ Erreur utilisateur:", userError.message)
    } else {
      console.log("✅ Utilisateur créé/mis à jour")
    }

    // 2. TEST PRODUIT
    console.log("\n2. Test création produit...")
    const { data: product, error: productError } = await supabase
      .from("products")
      .insert({
        user_id: testUserId,
        name: "Produit Test",
        category: "Test",
        price: 29.99,
        quantity: 10,
        description: "Description test",
        is_active: true,
      })
      .select()

    if (productError) {
      console.log("❌ Erreur produit:", productError.message)
    } else {
      console.log("✅ Produit créé:", product[0]?.name)
    }

    // 3. TEST COMMANDE
    console.log("\n3. Test création commande...")
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert({
        user_id: testUserId,
        order_number: "TEST-" + Date.now(),
        client_name: "Client Test",
        client_phone: "+33123456789",
        client_address: "123 Rue Test",
        total_amount: 29.99,
        status: "pending",
        notes: "Commande de test",
      })
      .select()

    if (orderError) {
      console.log("❌ Erreur commande:", orderError.message)
    } else {
      console.log("✅ Commande créée:", order[0]?.order_number)

      // 4. TEST ORDER ITEMS
      if (product && product[0] && order && order[0]) {
        console.log("\n4. Test création order items...")
        const { data: orderItem, error: orderItemError } = await supabase
          .from("order_items")
          .insert({
            order_id: order[0].id,
            product_id: product[0].id,
            quantity: 2,
            price: 29.99,
          })
          .select()

        if (orderItemError) {
          console.log("❌ Erreur order item:", orderItemError.message)
        } else {
          console.log("✅ Order item créé")
        }
      }
    }

    // 5. TEST LECTURE
    console.log("\n5. Test lecture des données...")

    const { data: userProducts, error: readError } = await supabase
      .from("products")
      .select("*")
      .eq("user_id", testUserId)

    if (readError) {
      console.log("❌ Erreur lecture:", readError.message)
    } else {
      console.log("✅ Lecture réussie:", userProducts.length, "produits trouvés")
    }

    // 6. NETTOYAGE
    console.log("\n6. Nettoyage des données de test...")

    // Supprimer dans l'ordre inverse des dépendances
    await supabase.from("order_items").delete().eq("order_id", order?.[0]?.id)
    await supabase.from("orders").delete().eq("user_id", testUserId)
    await supabase.from("products").delete().eq("user_id", testUserId)
    await supabase.from("users").delete().eq("id", testUserId)

    console.log("✅ Nettoyage terminé")

    console.log("\n🎉 TOUS LES TESTS CRUD TERMINÉS")
  } catch (error) {
    console.error("❌ Erreur générale:", error)
  }
}

// Exécuter les tests
testCRUDOperations()
