import { createClient } from "@supabase/supabase-js"

console.log("🔍 DIAGNOSTIC COMPLET - Photos profil vs produits...")

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !supabaseServiceKey) {
  console.error("❌ Variables d'environnement manquantes!")
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: { autoRefreshToken: false, persistSession: false },
})

async function analyseEtRepare() {
  try {
    console.log("📋 1. ANALYSE DES BUCKETS EXISTANTS...")

    const { data: buckets, error: bucketsError } = await supabase.storage.listBuckets()
    if (bucketsError) throw bucketsError

    console.log("📦 Buckets trouvés:")
    buckets.forEach((bucket) => {
      console.log(`   - ${bucket.id} (public: ${bucket.public}, taille max: ${bucket.file_size_limit})`)
    })

    // Trouver le bucket qui fonctionne pour les profils
    const profileBucket = buckets.find(
      (b) => b.id.includes("profile") || b.id.includes("avatar") || b.id.includes("user") || b.public === true,
    )

    const productBucket = buckets.find((b) => b.id === "product-images")

    console.log("\n🔍 2. COMPARAISON:")
    console.log("✅ Bucket profils:", profileBucket?.id || "Aucun trouvé spécifiquement")
    console.log("❓ Bucket produits:", productBucket?.id || "MANQUANT!")

    if (!productBucket) {
      console.log("\n🛠️ 3. CRÉATION DU BUCKET PRODUITS...")

      // Utiliser la même config que le bucket qui fonctionne
      const config = profileBucket
        ? {
            public: profileBucket.public,
            fileSizeLimit: profileBucket.file_size_limit || 5242880,
            allowedMimeTypes: profileBucket.allowed_mime_types || [
              "image/jpeg",
              "image/jpg",
              "image/png",
              "image/webp",
              "image/gif",
            ],
          }
        : {
            public: true,
            fileSizeLimit: 5242880,
            allowedMimeTypes: ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif"],
          }

      const { data: newBucket, error: createError } = await supabase.storage.createBucket("product-images", config)

      if (createError) {
        console.error("❌ Erreur création bucket:", createError)
        throw createError
      }

      console.log("✅ Bucket product-images créé!")
    }

    console.log("\n🔐 4. VÉRIFICATION DES POLITIQUES...")

    // Lister les politiques existantes pour storage.objects
    const { data: policies, error: policiesError } = await supabase
      .from("pg_policies")
      .select("*")
      .eq("schemaname", "storage")
      .eq("tablename", "objects")

    if (policiesError) {
      console.warn("⚠️ Impossible de lire les politiques:", policiesError.message)
    } else {
      console.log("📜 Politiques storage existantes:")
      policies.forEach((policy) => {
        console.log(`   - ${policy.policyname} (${policy.cmd})`)
      })
    }

    console.log("\n🧪 5. TEST D'UPLOAD PRODUIT...")

    // Test d'upload simple
    const testContent = `Test upload produit - ${new Date().toISOString()}`
    const testFile = new File([testContent], "test-product.txt", { type: "text/plain" })

    const { data: uploadResult, error: uploadError } = await supabase.storage
      .from("product-images")
      .upload(`test/test-${Date.now()}.txt`, testFile)

    if (uploadError) {
      console.error("❌ Test upload échoué:", uploadError)

      // Créer les politiques manquantes
      console.log("\n🔧 6. CRÉATION DES POLITIQUES...")

      const policies = [
        {
          name: "Authenticated users can upload product images",
          sql: `CREATE POLICY "Authenticated users can upload product images" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'product-images' AND auth.role() = 'authenticated');`,
        },
        {
          name: "Public can view product images",
          sql: `CREATE POLICY "Public can view product images" ON storage.objects FOR SELECT USING (bucket_id = 'product-images');`,
        },
        {
          name: "Users can delete their product images",
          sql: `CREATE POLICY "Users can delete their product images" ON storage.objects FOR DELETE USING (bucket_id = 'product-images' AND auth.role() = 'authenticated');`,
        },
      ]

      for (const policy of policies) {
        try {
          const { error: policyError } = await supabase.rpc("exec_sql", { sql: policy.sql })
          if (policyError) {
            console.warn(`⚠️ Politique ${policy.name}:`, policyError.message)
          } else {
            console.log(`✅ Politique créée: ${policy.name}`)
          }
        } catch (e) {
          console.warn(`⚠️ Erreur politique ${policy.name}:`, e.message)
        }
      }

      // Réessayer l'upload
      console.log("\n🧪 7. NOUVEAU TEST D'UPLOAD...")
      const { data: retryUpload, error: retryError } = await supabase.storage
        .from("product-images")
        .upload(`test/retry-${Date.now()}.txt`, testFile)

      if (retryError) {
        console.error("❌ Upload encore échoué:", retryError)
      } else {
        console.log("✅ Upload réussi:", retryUpload.path)

        // URL publique
        const {
          data: { publicUrl },
        } = supabase.storage.from("product-images").getPublicUrl(retryUpload.path)

        console.log("🔗 URL publique:", publicUrl)

        // Nettoyer
        await supabase.storage.from("product-images").remove([retryUpload.path])
        console.log("🧹 Fichier test supprimé")
      }
    } else {
      console.log("✅ Test upload réussi!", uploadResult.path)

      // URL publique
      const {
        data: { publicUrl },
      } = supabase.storage.from("product-images").getPublicUrl(uploadResult.path)

      console.log("🔗 URL publique:", publicUrl)

      // Nettoyer
      await supabase.storage.from("product-images").remove([uploadResult.path])
      console.log("🧹 Fichier test supprimé")
    }

    console.log("\n🎉 CONFIGURATION TERMINÉE!")
    console.log("Vous pouvez maintenant uploader des photos de produits!")
  } catch (error) {
    console.error("💥 ERREUR FATALE:", error)

    console.log("\n🆘 SOLUTION MANUELLE:")
    console.log("1. Allez dans Supabase Dashboard > Storage")
    console.log('2. Créez un bucket "product-images" PUBLIC')
    console.log("3. Copiez exactement les paramètres de votre bucket profils")

    throw error
  }
}

analyseEtRepare()
