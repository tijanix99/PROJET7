// DIAGNOSTIC COMPLET DE LA BASE DE DONNÉES
import { createClient } from "@supabase/supabase-js"

const supabaseUrl = "https://jwxtcnjcnxwtuwqizhkq.supabase.co"
const supabaseServiceKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3eHRjbmpjbnh3dHV3cWl6aGtxIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc0OTkxMTQ0NywiZXhwIjoyMDY1NDg3NDQ3fQ.LHlrYB8Ed4aV6B9x0shMvPersHjCAgHzvUyeJduNA6E"

const supabase = createClient(supabaseUrl, supabaseServiceKey)

async function completeDiagnostic() {
  console.log("🔍 DIAGNOSTIC COMPLET DE LA BASE DE DONNÉES")
  console.log("=".repeat(50))

  try {
    // 1. Vérifier la connexion
    console.log("1. Test de connexion...")
    const { data: connectionTest, error: connectionError } = await supabase.from("users").select("count").limit(1)

    if (connectionError) {
      console.error("❌ Erreur de connexion:", connectionError)
      return
    }
    console.log("✅ Connexion réussie")

    // 2. Vérifier les tables existantes
    console.log("\n2. Vérification des tables...")
    const { data: tables, error: tablesError } = await supabase.rpc("get_table_info").catch(async () => {
      // Si la fonction n'existe pas, utiliser une requête directe
      return await supabase.from("information_schema.tables").select("table_name").eq("table_schema", "public")
    })

    console.log("Tables trouvées:", tables || "Impossible de récupérer la liste")

    // 3. Vérifier les politiques RLS
    console.log("\n3. Vérification des politiques RLS...")

    const tablesToCheck = ["users", "products", "orders", "order_items"]

    for (const table of tablesToCheck) {
      try {
        // Test d'insertion avec un utilisateur fictif
        const testUserId = "00000000-0000-0000-0000-000000000000"

        if (table === "products") {
          const { data, error } = await supabase
            .from("products")
            .insert({
              user_id: testUserId,
              name: "Test Product",
              category: "Test",
              price: 10.0,
              quantity: 1,
              is_active: true,
            })
            .select()

          if (error) {
            console.log(`❌ ${table}: ${error.message}`)
          } else {
            console.log(`✅ ${table}: Insertion possible`)
            // Nettoyer le test
            await supabase.from("products").delete().eq("user_id", testUserId)
          }
        }

        if (table === "orders") {
          const { data, error } = await supabase
            .from("orders")
            .insert({
              user_id: testUserId,
              order_number: "TEST-001",
              client_name: "Test Client",
              total_amount: 10.0,
              status: "pending",
            })
            .select()

          if (error) {
            console.log(`❌ ${table}: ${error.message}`)
          } else {
            console.log(`✅ ${table}: Insertion possible`)
            // Nettoyer le test
            await supabase.from("orders").delete().eq("user_id", testUserId)
          }
        }
      } catch (err) {
        console.log(`❌ ${table}: ${err.message}`)
      }
    }

    // 4. Vérifier les données existantes
    console.log("\n4. Vérification des données existantes...")

    const { data: usersCount } = await supabase.from("users").select("id", { count: "exact", head: true })
    console.log(`👥 Utilisateurs: ${usersCount || 0}`)

    const { data: productsCount } = await supabase.from("products").select("id", { count: "exact", head: true })
    console.log(`📦 Produits: ${productsCount || 0}`)

    const { data: ordersCount } = await supabase.from("orders").select("id", { count: "exact", head: true })
    console.log(`🛒 Commandes: ${ordersCount || 0}`)

    // 5. Test avec un vrai utilisateur si disponible
    console.log("\n5. Test avec utilisateurs réels...")
    const { data: realUsers } = await supabase.from("users").select("id, email").limit(1)

    if (realUsers && realUsers.length > 0) {
      const userId = realUsers[0].id
      console.log(`🧪 Test avec utilisateur: ${realUsers[0].email}`)

      // Test produit
      const { data: userProducts, error: productsError } = await supabase
        .from("products")
        .select("*")
        .eq("user_id", userId)

      if (productsError) {
        console.log(`❌ Erreur récupération produits: ${productsError.message}`)
      } else {
        console.log(`✅ Produits utilisateur: ${userProducts.length}`)
      }

      // Test commandes
      const { data: userOrders, error: ordersError } = await supabase.from("orders").select("*").eq("user_id", userId)

      if (ordersError) {
        console.log(`❌ Erreur récupération commandes: ${ordersError.message}`)
      } else {
        console.log(`✅ Commandes utilisateur: ${userOrders.length}`)
      }
    } else {
      console.log("ℹ️ Aucun utilisateur trouvé pour les tests")
    }

    console.log("\n🎉 DIAGNOSTIC TERMINÉ")
  } catch (error) {
    console.error("❌ Erreur générale:", error)
  }
}

// Exécuter le diagnostic
completeDiagnostic()
