-- CORRECTION COMPLÈTE DES PERMISSIONS ET POLITIQUES RLS

-- 1. Désactiver temporairement RLS pour nettoyer
ALTER TABLE users DISABLE ROW LEVEL SECURITY;
ALTER TABLE products DISABLE ROW LEVEL SECURITY;
ALTER TABLE orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE order_items DISABLE ROW LEVEL SECURITY;
ALTER TABLE conversations DISABLE ROW LEVEL SECURITY;
ALTER TABLE messages DISABLE ROW LEVEL SECURITY;
ALTER TABLE ia_training_data DISABLE ROW LEVEL SECURITY;
ALTER TABLE user_settings DISABLE ROW LEVEL SECURITY;

-- 2. Supprimer toutes les anciennes politiques
DO $$ 
DECLARE 
    r RECORD;
BEGIN
    -- Supprimer toutes les politiques existantes
    FOR r IN (SELECT schemaname, tablename, policyname FROM pg_policies WHERE schemaname = 'public') 
    LOOP
        EXECUTE 'DROP POLICY IF EXISTS "' || r.policyname || '" ON ' || r.schemaname || '.' || r.tablename;
    END LOOP;
END $$;

-- 3. Réactiver RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE ia_training_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;

-- 4. Créer les nouvelles politiques SIMPLIFIÉES

-- USERS - Politiques simplifiées
CREATE POLICY "users_select_own" ON users FOR SELECT USING (auth.uid() = id);
CREATE POLICY "users_insert_own" ON users FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "users_update_own" ON users FOR UPDATE USING (auth.uid() = id);

-- PRODUCTS - Politiques simplifiées
CREATE POLICY "products_all_own" ON products FOR ALL USING (auth.uid() = user_id);

-- ORDERS - Politiques simplifiées  
CREATE POLICY "orders_all_own" ON orders FOR ALL USING (auth.uid() = user_id);

-- ORDER_ITEMS - Politiques simplifiées
CREATE POLICY "order_items_all_own" ON order_items FOR ALL USING (
    EXISTS (SELECT 1 FROM orders WHERE orders.id = order_items.order_id AND orders.user_id = auth.uid())
);

-- CONVERSATIONS - Politiques simplifiées
CREATE POLICY "conversations_all_own" ON conversations FOR ALL USING (auth.uid() = user_id);

-- MESSAGES - Politiques simplifiées
CREATE POLICY "messages_all_own" ON messages FOR ALL USING (auth.uid() = user_id);

-- IA_TRAINING_DATA - Politiques simplifiées
CREATE POLICY "ia_training_data_all_own" ON ia_training_data FOR ALL USING (auth.uid() = user_id);

-- USER_SETTINGS - Politiques simplifiées
CREATE POLICY "user_settings_all_own" ON user_settings FOR ALL USING (auth.uid() = user_id);

-- 5. Accorder toutes les permissions nécessaires
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT ALL ON ALL TABLES IN SCHEMA public TO anon, authenticated;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO anon, authenticated;
GRANT ALL ON ALL FUNCTIONS IN SCHEMA public TO anon, authenticated;

-- 6. Créer des index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_products_user_id ON products(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_user_id ON messages(user_id);

-- 7. Vérifier que tout fonctionne
SELECT 'Politiques créées avec succès' as status;
