// TEST FINAL DES OPÉRATIONS APRÈS RÉPARATION
import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

console.log("🧪 TEST FINAL AVEC CLÉ ANON (UTILISATEUR)")
console.log("=".repeat(50))

const supabase = createClient(supabaseUrl, anonKey)

async function testUserOperations() {
  try {
    const testUserId = "user-test-" + Date.now()

    console.log("\n1. Test création utilisateur...")
    const { data: user, error: userError } = await supabase
      .from("users")
      .insert({
        id: testUserId,
        full_name: "Utilisateur Test",
        email: "user@test.com",
        city: "Paris",
      })
      .select()

    if (userError) {
      console.log("❌ Erreur utilisateur:", userError.message)
      return
    }
    console.log("✅ Utilisateur créé avec succès!")

    console.log("\n2. Test création produit...")
    const { data: product, error: productError } = await supabase
      .from("products")
      .insert({
        user_id: testUserId,
        name: "Mon Premier Produit",
        category: "Vêtements",
        price: 49.99,
        quantity: 5,
        description: "Description de test",
        is_active: true,
      })
      .select()

    if (productError) {
      console.log("❌ Erreur produit:", productError.message)
      return
    }
    console.log("✅ Produit créé avec succès!")

    console.log("\n3. Test création commande...")
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert({
        user_id: testUserId,
        order_number: "CMD-" + Date.now(),
        client_name: "Jean Dupont",
        client_phone: "+33123456789",
        client_address: "123 Rue de la Paix, Paris",
        total_amount: 49.99,
        status: "pending",
        notes: "Première commande de test",
      })
      .select()

    if (orderError) {
      console.log("❌ Erreur commande:", orderError.message)
      return
    }
    console.log("✅ Commande créée avec succès!")

    console.log("\n4. Test lecture des données...")
    const { data: userProducts, error: readError } = await supabase
      .from("products")
      .select("*")
      .eq("user_id", testUserId)

    if (readError) {
      console.log("❌ Erreur lecture:", readError.message)
    } else {
      console.log("✅ Lecture réussie:", userProducts.length, "produits trouvés")
    }

    console.log("\n5. Nettoyage...")
    await supabase.from("orders").delete().eq("user_id", testUserId)
    await supabase.from("products").delete().eq("user_id", testUserId)
    await supabase.from("users").delete().eq("id", testUserId)
    console.log("✅ Nettoyage terminé")

    console.log("\n🎉 TOUS LES TESTS RÉUSSIS!")
    console.log("Votre application est maintenant 100% fonctionnelle!")
  } catch (error) {
    console.error("❌ Erreur:", error)
  }
}

testUserOperations()
