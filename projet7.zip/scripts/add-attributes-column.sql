-- Vérifier d'abord si la colonne existe déjà
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'products' AND column_name = 'attributes') THEN
        -- Ajouter la colonne attributes à la table products
        ALTER TABLE products ADD COLUMN attributes JSONB DEFAULT '{}';
        
        -- Ajouter un index pour améliorer les performances des requêtes sur les attributs
        CREATE INDEX IF NOT EXISTS idx_products_attributes ON products USING GIN (attributes);
        
        -- Mettre à jour les produits existants avec un objet JSON vide
        UPDATE products SET attributes = '{}' WHERE attributes IS NULL;
        
        RAISE NOTICE 'Colonne attributes ajoutée avec succès';
    ELSE
        RAISE NOTICE 'Colonne attributes existe déjà';
    END IF;
END $$;

-- Vérifier que la colonne a été créée
SELECT column_name, data_type, is_nullable, column_default 
FROM information_schema.columns 
WHERE table_name = 'products' AND column_name = 'attributes';
