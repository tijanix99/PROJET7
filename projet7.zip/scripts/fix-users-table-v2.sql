-- Correction complète de la table users
-- Supprimer la contrainte NOT NULL sur password_hash puis supprimer la colonne

-- Étape 1: Supprimer la contrainte NOT NULL si elle existe
ALTER TABLE users ALTER COLUMN password_hash DROP NOT NULL;

-- Étape 2: Supprimer complètement la colonne password_hash
ALTER TABLE users DROP COLUMN IF EXISTS password_hash;

-- Étape 3: Supprimer la contrainte d'unicité sur email (Supabase Auth s'en occupe)
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_email_key;

-- Étape 4: S'assurer que l'ID peut être une référence vers auth.users
-- (Pas besoin de contrainte FK car Supabase gère cela automatiquement)

-- Étape 5: Vérifier la structure finale
SELECT column_name, data_type, is_nullable 
FROM information_schema.columns 
WHERE table_name = 'users' 
ORDER BY ordinal_position;
