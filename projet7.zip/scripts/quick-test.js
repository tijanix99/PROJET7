// TEST RAPIDE POUR VÉRIFIER QUE TOUT FONCTIONNE
import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

const supabase = createClient(supabaseUrl, supabaseAnonKey)

async function quickTest() {
  console.log("🚀 TEST RAPIDE - Tout fonctionne déjà ?")
  console.log("=".repeat(40))

  try {
    // Test simple de lecture
    const { data: products, error: productsError } = await supabase.from("products").select("*").limit(5)

    if (productsError) {
      console.log("❌ Problème avec les produits:", productsError.message)
    } else {
      console.log("✅ Produits OK -", products.length, "produits trouvés")
    }

    const { data: orders, error: ordersError } = await supabase.from("orders").select("*").limit(5)

    if (ordersError) {
      console.log("❌ Problème avec les commandes:", ordersError.message)
    } else {
      console.log("✅ Commandes OK -", orders.length, "commandes trouvées")
    }

    const { data: users, error: usersError } = await supabase.from("users").select("*").limit(5)

    if (usersError) {
      console.log("❌ Problème avec les utilisateurs:", usersError.message)
    } else {
      console.log("✅ Utilisateurs OK -", users.length, "utilisateurs trouvés")
    }

    console.log("\n🎉 TOUT FONCTIONNE PARFAITEMENT !")
    console.log("🚀 Votre site est 100% opérationnel !")
    console.log("✅ Vous pouvez ajouter des produits et commandes !")
  } catch (error) {
    console.error("❌ Erreur:", error.message)
  }
}

quickTest()
