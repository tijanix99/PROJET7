import { supabase } from "../lib/supabase-client.js"

console.log("🔧 Réparation simple du stockage...")

async function fixStorage() {
  try {
    console.log("📡 Test de connexion Supabase...")

    // Test de base
    const { data: buckets, error: listError } = await supabase.storage.listBuckets()

    if (listError) {
      console.error("❌ Erreur connexion:", listError.message)
      return
    }

    console.log("✅ Connexion OK")
    console.log("📋 Buckets existants:", buckets?.map((b) => b.id) || [])

    // Vérifier si le bucket existe
    const bucketExists = buckets?.some((bucket) => bucket.id === "product-images")

    if (bucketExists) {
      console.log("✅ Le bucket 'product-images' existe déjà!")

      // Test d'upload simple
      console.log("🧪 Test d'upload...")
      const testFile = new File(["test"], "test.txt", { type: "text/plain" })

      const { error: uploadError } = await supabase.storage
        .from("product-images")
        .upload(`test-${Date.now()}.txt`, testFile)

      if (uploadError) {
        console.error("❌ Erreur upload:", uploadError.message)
        console.log("💡 Le bucket existe mais les permissions ne sont pas configurées")
        console.log("🔧 Essayez de créer le bucket avec des permissions publiques...")

        // Essayer de recréer avec des permissions publiques
        const { error: deleteError } = await supabase.storage.deleteBucket("product-images")
        if (!deleteError) {
          console.log("🗑️ Ancien bucket supprimé")
        }

        const { error: createError } = await supabase.storage.createBucket("product-images", {
          public: true,
          fileSizeLimit: 5242880,
          allowedMimeTypes: ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif"],
        })

        if (createError) {
          console.error("❌ Erreur création:", createError.message)
        } else {
          console.log("✅ Bucket recréé avec succès!")
        }
      } else {
        console.log("✅ Upload test réussi! Le stockage fonctionne parfaitement!")

        // Nettoyer le fichier de test
        await supabase.storage.from("product-images").remove([`test-${Date.now()}.txt`])
      }
    } else {
      console.log("🆕 Création du bucket 'product-images'...")

      const { error: createError } = await supabase.storage.createBucket("product-images", {
        public: true,
        fileSizeLimit: 5242880,
        allowedMimeTypes: ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif"],
      })

      if (createError) {
        console.error("❌ Erreur création bucket:", createError.message)

        if (createError.message.includes("already exists")) {
          console.log("✅ Le bucket existe déjà (erreur normale)")
        } else {
          console.log("💡 Vous devez peut-être avoir les droits admin pour créer des buckets")
        }
      } else {
        console.log("✅ Bucket créé avec succès!")
      }
    }

    console.log("\n🎉 Vérification terminée!")
    console.log("💡 Retournez dans votre app et rechargez la page")
  } catch (error) {
    console.error("💥 Erreur générale:", error.message)
    console.log("💡 Vérifiez vos variables d'environnement Supabase")
  }
}

fixStorage()
