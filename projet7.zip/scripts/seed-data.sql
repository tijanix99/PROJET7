-- Données de test pour la plateforme SaaS Instagram/WhatsApp

-- Insertion d'un utilisateur de test
INSERT INTO users (id, full_name, email, password_hash, whatsapp_number, city, shop_name) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'Sarah Martin', 'sarah@boutique-mode.com', '$2b$10$example_hash', '+33612345678', 'Paris', 'Boutique Mode Sarah');

-- Insertion des paramètres utilisateur
INSERT INTO user_settings (user_id) VALUES
('550e8400-e29b-41d4-a716-446655440000');

-- Insertion de produits de test
INSERT INTO products (user_id, name, price, quantity, category, description, is_active) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'Robe d''été fleurie', 89.00, 15, 'Vêtements', 'Belle robe d''été avec motifs floraux', true),
('550e8400-e29b-41d4-a716-446655440000', 'Sneakers blanches', 120.00, 8, 'Chaussures', 'Sneakers blanches tendance et confortables', true),
('550e8400-e29b-41d4-a716-446655440000', 'Sac à main cuir', 65.00, 0, 'Accessoires', 'Sac à main en cuir véritable', true),
('550e8400-e29b-41d4-a716-446655440000', 'T-shirt basique', 35.00, 25, 'Vêtements', 'T-shirt basique en coton bio', true),
('550e8400-e29b-41d4-a716-446655440000', 'Montre élégante', 199.00, 3, 'Accessoires', 'Montre élégante avec bracelet en cuir', true);

-- Insertion de commandes de test
INSERT INTO orders (user_id, order_number, client_name, client_phone, client_address, total_amount, status) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'ORD-001', 'Marie Dubois', '+33612345679', '123 Rue de la Paix, 75001 Paris', 134.00, 'pending'),
('550e8400-e29b-41d4-a716-446655440000', 'ORD-002', 'Pierre Martin', '+33698765432', '456 Avenue des Champs, 69000 Lyon', 240.00, 'shipped'),
('550e8400-e29b-41d4-a716-446655440000', 'ORD-003', 'Sophie Laurent', '+33611223344', '789 Boulevard Saint-Germain, 33000 Bordeaux', 100.00, 'delivered');

-- Insertion des articles de commande
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
((SELECT id FROM orders WHERE order_number = 'ORD-001'), (SELECT id FROM products WHERE name = 'Robe d''été fleurie'), 1, 89.00),
((SELECT id FROM orders WHERE order_number = 'ORD-001'), (SELECT id FROM products WHERE name = 'Sac à main cuir'), 1, 45.00),
((SELECT id FROM orders WHERE order_number = 'ORD-002'), (SELECT id FROM products WHERE name = 'Sneakers blanches'), 2, 120.00),
((SELECT id FROM orders WHERE order_number = 'ORD-003'), (SELECT id FROM products WHERE name = 'Sac à main cuir'), 1, 65.00),
((SELECT id FROM orders WHERE order_number = 'ORD-003'), (SELECT id FROM products WHERE name = 'T-shirt basique'), 1, 35.00);

-- Insertion de conversations de test
INSERT INTO conversations (user_id, whatsapp_number, client_name, last_message, unread_count) VALUES
('550e8400-e29b-41d4-a716-446655440000', '+33612345679', 'Marie Dubois', 'Bonjour, est-ce que la robe est disponible en taille M ?', 2),
('550e8400-e29b-41d4-a716-446655440000', '+33698765432', 'Pierre Martin', 'Merci pour la livraison rapide ! 👍', 0),
('550e8400-e29b-41d4-a716-446655440000', '+33611223344', 'Sophie Laurent', 'Avez-vous cette couleur en stock ?', 1);

-- Insertion de messages de test
INSERT INTO messages (user_id, whatsapp_number, sender, content, status) VALUES
('550e8400-e29b-41d4-a716-446655440000', '+33612345679', 'client', 'Bonjour ! J''ai vu votre robe d''été sur Instagram', 'read'),
('550e8400-e29b-41d4-a716-446655440000', '+33612345679', 'me', 'Bonjour Marie ! Merci pour votre intérêt 😊', 'read'),
('550e8400-e29b-41d4-a716-446655440000', '+33612345679', 'client', 'Est-ce qu''elle est disponible en taille M ?', 'read'),
('550e8400-e29b-41d4-a716-446655440000', '+33698765432', 'client', 'Bonjour, j''ai bien reçu ma commande', 'read'),
('550e8400-e29b-41d4-a716-446655440000', '+33698765432', 'me', 'Parfait ! J''espère que tout vous convient', 'read');

-- Insertion de données d'entraînement IA
INSERT INTO ia_training_data (user_id, question, answer, category) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'Quels sont vos prix ?', 'Bonjour ! Nos prix varient selon les produits. Nos t-shirts sont à partir de 35€, nos robes entre 65€ et 120€, et nos accessoires de 25€ à 199€. Que recherchez-vous exactement ?', 'Prix'),
('550e8400-e29b-41d4-a716-446655440000', 'Avez-vous des promotions ?', 'Oui ! Nous avons actuellement -20% sur toute la collection été avec le code SUMMER20. Cette offre est valable jusqu''à la fin du mois. Souhaitez-vous voir nos produits en promotion ?', 'Promotions'),
('550e8400-e29b-41d4-a716-446655440000', 'Comment passer commande ?', 'C''est très simple ! Envoyez-moi le nom du produit qui vous intéresse, votre taille et votre adresse de livraison. Je vous enverrai ensuite les détails de paiement. La livraison se fait sous 2-3 jours ouvrés.', 'Commande'),
('550e8400-e29b-41d4-a716-446655440000', 'Quelles sont vos tailles disponibles ?', 'Nous proposons les tailles S, M, L, XL et XXL pour la plupart de nos vêtements. Pour les chaussures, nous avons du 36 au 42. N''hésitez pas à me dire quel produit vous intéresse pour vérifier la disponibilité !', 'Tailles');

-- Insertion d'un résumé quotidien
INSERT INTO daily_summaries (user_id, date, total_sales, total_orders, total_messages) VALUES
('550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE, 2847.00, 18, 24);
