import { createClient } from "@supabase/supabase-js"

// Configuration Supabase
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !supabaseServiceKey) {
  console.error("❌ Variables d'environnement manquantes:")
  console.error("- NEXT_PUBLIC_SUPABASE_URL:", !!supabaseUrl)
  console.error("- SUPABASE_SERVICE_ROLE_KEY:", !!supabaseServiceKey)
  process.exit(1)
}

// Client Supabase avec clé de service (privilèges admin)
const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
})

async function setupStorage() {
  console.log("🚀 Configuration du stockage d'images...")

  try {
    // 1. Vérifier les buckets existants
    console.log("📋 Vérification des buckets existants...")
    const { data: buckets, error: listError } = await supabase.storage.listBuckets()

    if (listError) {
      console.error("❌ Erreur lors de la vérification des buckets:", listError)
      throw listError
    }

    console.log("📦 Buckets existants:", buckets?.map((b) => b.id) || [])

    // 2. Supprimer l'ancien bucket s'il existe
    const existingBucket = buckets?.find((bucket) => bucket.id === "product-images")
    if (existingBucket) {
      console.log("🗑️ Suppression de l'ancien bucket...")

      // Supprimer tous les fichiers d'abord
      const { data: files } = await supabase.storage.from("product-images").list()
      if (files && files.length > 0) {
        const filePaths = files.map((file) => file.name)
        await supabase.storage.from("product-images").remove(filePaths)
        console.log(`🗑️ ${filePaths.length} fichiers supprimés`)
      }

      // Supprimer le bucket
      const { error: deleteError } = await supabase.storage.deleteBucket("product-images")
      if (deleteError) {
        console.warn("⚠️ Erreur suppression bucket (peut être ignorée):", deleteError.message)
      }
    }

    // 3. Créer le nouveau bucket
    console.log("🆕 Création du bucket product-images...")
    const { data: newBucket, error: createError } = await supabase.storage.createBucket("product-images", {
      public: true,
      fileSizeLimit: 5242880, // 5MB
      allowedMimeTypes: ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif"],
    })

    if (createError) {
      console.error("❌ Erreur création bucket:", createError)
      throw createError
    }

    console.log("✅ Bucket créé avec succès:", newBucket)

    // 4. Test d'upload
    console.log("🧪 Test d'upload...")
    const testContent = "Test image upload - " + new Date().toISOString()
    const testFile = new File([testContent], "test.txt", { type: "text/plain" })

    const { data: uploadData, error: uploadError } = await supabase.storage
      .from("product-images")
      .upload(`test/test-${Date.now()}.txt`, testFile)

    if (uploadError) {
      console.error("❌ Test d'upload échoué:", uploadError)
      throw uploadError
    }

    console.log("✅ Test d'upload réussi:", uploadData.path)

    // 5. Test d'URL publique
    const {
      data: { publicUrl },
    } = supabase.storage.from("product-images").getPublicUrl(uploadData.path)

    console.log("🔗 URL publique de test:", publicUrl)

    // 6. Nettoyer le fichier de test
    await supabase.storage.from("product-images").remove([uploadData.path])
    console.log("🧹 Fichier de test nettoyé")

    // 7. Vérification finale
    console.log("🔍 Vérification finale...")
    const { data: finalBuckets } = await supabase.storage.listBuckets()
    const productBucket = finalBuckets?.find((b) => b.id === "product-images")

    if (productBucket) {
      console.log("✅ Configuration terminée avec succès!")
      console.log("📊 Détails du bucket:")
      console.log("  - ID:", productBucket.id)
      console.log("  - Public:", productBucket.public)
      console.log("  - Taille max:", productBucket.file_size_limit, "bytes")
      console.log("  - Types autorisés:", productBucket.allowed_mime_types)
      console.log("  - Créé le:", productBucket.created_at)
    } else {
      throw new Error("Bucket non trouvé après création")
    }
  } catch (error) {
    console.error("❌ Erreur lors de la configuration:", error)

    // Suggestions de résolution
    console.log("\n🔧 Suggestions de résolution:")
    console.log("1. Vérifiez que SUPABASE_SERVICE_ROLE_KEY est correcte")
    console.log("2. Vérifiez les permissions de votre projet Supabase")
    console.log("3. Essayez de créer le bucket manuellement dans l'interface Supabase")
    console.log("4. Contactez le support Supabase si le problème persiste")

    throw error
  }
}

// Exécuter la configuration
setupStorage()
  .then(() => {
    console.log("\n🎉 Configuration du stockage terminée!")
    console.log("Vous pouvez maintenant uploader des images de produits.")
  })
  .catch((error) => {
    console.error("\n💥 Échec de la configuration:", error.message)
    process.exit(1)
  })
