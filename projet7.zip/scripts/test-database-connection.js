// Test de connexion à la base de données
import { createClient } from "@supabase/supabase-js"

const supabaseUrl = "https://jwxtcnjcnxwtuwqizhkq.supabase.co"
const supabaseKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3eHRjbmpjbnh3dHV3cWl6aGtxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk5MTE0NDcsImV4cCI6MjA2NTQ4NzQ0N30.srb73bSz_U6j2ahMp3WnO1_VJp0sqsWt24L0KuzvhDY"

const supabase = createClient(supabaseUrl, supabaseKey)

async function testConnection() {
  console.log("🔍 Test de connexion à Supabase...")

  try {
    // Test 1: Vérifier la connexion
    const { data: tables, error: tablesError } = await supabase
      .from("information_schema.tables")
      .select("table_name")
      .eq("table_schema", "public")

    if (tablesError) {
      console.error("❌ Erreur connexion:", tablesError)
      return
    }

    console.log("✅ Connexion réussie!")
    console.log(
      "📋 Tables trouvées:",
      tables?.map((t) => t.table_name),
    )

    // Test 2: Vérifier l'authentification
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError) {
      console.log("⚠️ Pas d'utilisateur connecté (normal pour ce test)")
    } else {
      console.log("👤 Utilisateur connecté:", user?.email)
    }

    // Test 3: Tester l'accès aux tables
    console.log("\n🧪 Test d'accès aux tables...")

    const tables_to_test = ["users", "products", "orders", "order_items"]

    for (const table of tables_to_test) {
      try {
        const { data, error, count } = await supabase.from(table).select("*", { count: "exact", head: true })

        if (error) {
          console.log(`❌ ${table}: ${error.message}`)
        } else {
          console.log(`✅ ${table}: ${count} enregistrements`)
        }
      } catch (err) {
        console.log(`❌ ${table}: ${err.message}`)
      }
    }

    // Test 4: Tester l'insertion (sans utilisateur connecté)
    console.log("\n🧪 Test d'insertion...")

    const { data: insertData, error: insertError } = await supabase
      .from("products")
      .insert([
        {
          user_id: "00000000-0000-0000-0000-000000000000", // UUID fictif
          name: "Test Product",
          category: "Test",
          price: 10.0,
          quantity: 1,
          is_active: true,
        },
      ])
      .select()

    if (insertError) {
      console.log("❌ Erreur insertion:", insertError.message)
      console.log("💡 Détails:", insertError)
    } else {
      console.log("✅ Insertion réussie:", insertData)

      // Nettoyer le test
      await supabase.from("products").delete().eq("name", "Test Product")
    }
  } catch (error) {
    console.error("❌ Erreur générale:", error)
  }
}

testConnection()
