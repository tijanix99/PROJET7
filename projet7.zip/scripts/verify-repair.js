// VÉRIFICATION QUE TOUT FONCTIONNE APRÈS RÉPARATION
import { createClient } from "@supabase/supabase-js"

const supabaseUrl = "https://jwxtcnjcnxwtuwqizhkq.supabase.co"
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3eHRjbmpjbnh3dHV3cWl6aGtxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk5MTE0NDcsImV4cCI6MjA2NTQ4NzQ0N30.srb73bSz_U6j2ahMp3WnO1_VJp0sqsWt24L0KuzvhDY"

const supabase = createClient(supabaseUrl, supabaseAnonKey)

async function verifyRepair() {
  console.log("🔍 VÉRIFICATION APRÈS RÉPARATION")
  console.log("=".repeat(40))

  try {
    const testUserId = "verification-user-" + Date.now()

    // 1. Test création utilisateur
    console.log("\n1. Test création utilisateur...")
    const { data: user, error: userError } = await supabase
      .from("users")
      .upsert({
        id: testUserId,
        full_name: "Utilisateur Test",
        email: "test@verification.com",
      })
      .select()

    if (userError) {
      console.log("❌ Utilisateur:", userError.message)
    } else {
      console.log("✅ Utilisateur créé avec succès!")
    }

    // 2. Test création produit
    console.log("\n2. Test création produit...")
    const { data: product, error: productError } = await supabase
      .from("products")
      .insert({
        user_id: testUserId,
        name: "Produit Vérification",
        category: "Test",
        price: 25.5,
        quantity: 10,
        is_active: true,
      })
      .select()

    if (productError) {
      console.log("❌ Produit:", productError.message)
    } else {
      console.log("✅ Produit créé avec succès!")
    }

    // 3. Test création commande
    console.log("\n3. Test création commande...")
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert({
        user_id: testUserId,
        order_number: "VERIF-" + Date.now(),
        client_name: "Client Vérification",
        client_phone: "+33123456789",
        total_amount: 25.5,
        status: "pending",
      })
      .select()

    if (orderError) {
      console.log("❌ Commande:", orderError.message)
    } else {
      console.log("✅ Commande créée avec succès!")

      // 4. Test order items
      if (product && product[0]) {
        console.log("\n4. Test order items...")
        const { data: orderItem, error: itemError } = await supabase
          .from("order_items")
          .insert({
            order_id: order[0].id,
            product_id: product[0].id,
            quantity: 2,
            price: 25.5,
          })
          .select()

        if (itemError) {
          console.log("❌ Order Item:", itemError.message)
        } else {
          console.log("✅ Order Item créé avec succès!")
        }
      }
    }

    // 5. Test lecture des données
    console.log("\n5. Test lecture des données...")
    const { data: products, error: readError } = await supabase.from("products").select("*").eq("user_id", testUserId)

    if (readError) {
      console.log("❌ Lecture:", readError.message)
    } else {
      console.log("✅ Lecture réussie:", products.length, "produits trouvés")
    }

    // 6. Nettoyage
    console.log("\n6. Nettoyage...")
    await supabase.from("order_items").delete().eq("order_id", order?.[0]?.id)
    await supabase.from("orders").delete().eq("user_id", testUserId)
    await supabase.from("products").delete().eq("user_id", testUserId)
    await supabase.from("users").delete().eq("id", testUserId)
    console.log("✅ Nettoyage terminé")

    console.log("\n🎉 VÉRIFICATION TERMINÉE!")
    console.log("🚀 Votre application est maintenant prête à l'emploi!")
  } catch (error) {
    console.error("❌ Erreur de vérification:", error)
  }
}

verifyRepair()
