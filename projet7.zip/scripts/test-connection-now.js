// Test de connexion maintenant que les variables sont configurées
import { createClient } from "@supabase/supabase-js"

console.log("🔍 Test de connexion avec les nouvelles variables...")

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

console.log("📊 Variables détectées:")
console.log("- URL:", supabaseUrl ? "✅ Configurée" : "❌ Manquante")
console.log("- Key:", supabaseKey ? "✅ Configurée" : "❌ Manquante")

if (supabaseUrl && supabaseKey) {
  const supabase = createClient(supabaseUrl, supabaseKey)

  try {
    console.log("🔗 Test de connexion à la base de données...")

    // Test simple de lecture
    const { data, error, count } = await supabase.from("users").select("*", { count: "exact", head: true })

    if (error) {
      console.log("❌ Erreur:", error.message)
      console.log("💡 Détails:", error)
    } else {
      console.log("✅ Connexion réussie!")
      console.log("👥 Nombre d'utilisateurs:", count)

      // Test des autres tables
      const tables = ["products", "orders", "messages"]
      for (const table of tables) {
        const { count: tableCount, error: tableError } = await supabase
          .from(table)
          .select("*", { count: "exact", head: true })

        if (tableError) {
          console.log(`❌ ${table}: ${tableError.message}`)
        } else {
          console.log(`✅ ${table}: ${tableCount} enregistrements`)
        }
      }
    }
  } catch (err) {
    console.error("❌ Erreur de connexion:", err.message)
  }
} else {
  console.log("❌ Variables d'environnement manquantes!")
}
