import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY

console.log("🔧 Test des opérations de création...")
console.log("URL Supabase:", supabaseUrl)
console.log("Clé disponible:", supabaseKey ? "OUI" : "NON")

if (!supabaseUrl || !supabaseKey) {
  console.error("❌ Variables d'environnement manquantes")
  console.log(
    "Variables disponibles:",
    Object.keys(process.env).filter((key) => key.includes("SUPABASE")),
  )
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseKey)

async function testOperations() {
  try {
    console.log("\n📋 Test 1: Vérification des tables...")

    // Test de connexion
    const { data: tables, error: tablesError } = await supabase.from("products").select("count").limit(1)

    if (tablesError) {
      console.error("❌ Erreur accès table products:", tablesError)
      return
    }

    console.log("✅ Connexion à la base de données OK")

    // Test création d'un utilisateur test
    console.log("\n👤 Test 2: Création utilisateur test...")

    const testUser = {
      id: "test-user-" + Date.now(),
      full_name: "Test User",
      email: "test@example.com",
    }

    const { data: userData, error: userError } = await supabase.from("users").upsert(testUser).select()

    if (userError) {
      console.error("❌ Erreur création utilisateur:", userError)
      return
    }

    console.log("✅ Utilisateur test créé:", userData)

    // Test création produit
    console.log("\n📦 Test 3: Création produit...")

    const testProduct = {
      user_id: testUser.id,
      name: "Produit Test " + Date.now(),
      category: "Test",
      price: 29.99,
      quantity: 10,
      description: "Produit de test",
      is_active: true,
    }

    const { data: productData, error: productError } = await supabase.from("products").insert(testProduct).select()

    if (productError) {
      console.error("❌ Erreur création produit:", productError)
      return
    }

    console.log("✅ Produit créé:", productData)

    // Test création commande
    console.log("\n🛒 Test 4: Création commande...")

    const testOrder = {
      user_id: testUser.id,
      order_number: "TEST-" + Date.now(),
      client_name: "Client Test",
      client_phone: "0123456789",
      client_address: "Adresse test",
      total_amount: 29.99,
      status: "pending",
      notes: "Commande de test",
    }

    const { data: orderData, error: orderError } = await supabase.from("orders").insert(testOrder).select()

    if (orderError) {
      console.error("❌ Erreur création commande:", orderError)
      return
    }

    console.log("✅ Commande créée:", orderData)

    // Test création item de commande
    if (orderData && orderData[0] && productData && productData[0]) {
      console.log("\n📋 Test 5: Création item de commande...")

      const testOrderItem = {
        order_id: orderData[0].id,
        product_id: productData[0].id,
        quantity: 1,
        price: 29.99,
      }

      const { data: itemData, error: itemError } = await supabase.from("order_items").insert(testOrderItem).select()

      if (itemError) {
        console.error("❌ Erreur création item:", itemError)
        return
      }

      console.log("✅ Item de commande créé:", itemData)
    }

    console.log("\n🎉 TOUS LES TESTS SONT PASSÉS !")
    console.log("✅ La base de données fonctionne correctement")
    console.log("✅ Vous pouvez maintenant créer des produits et commandes")
  } catch (error) {
    console.error("❌ Erreur générale:", error)
  }
}

testOperations()
