import { supabase } from "../lib/supabase-client.js"

async function setupStorageBucket() {
  try {
    console.log("🚀 Configuration du bucket de stockage...")

    // Vérifier les buckets existants
    const { data: buckets, error: listError } = await supabase.storage.listBuckets()

    if (listError) {
      console.error("❌ Erreur lors de la vérification des buckets:", listError)
      return
    }

    console.log(
      "📦 Buckets existants:",
      buckets?.map((b) => b.id),
    )

    const bucketExists = buckets?.some((bucket) => bucket.id === "product-images")

    if (bucketExists) {
      console.log("✅ Le bucket product-images existe déjà")
    } else {
      console.log("🔧 Création du bucket product-images...")

      // Créer le bucket
      const { data, error: createError } = await supabase.storage.createBucket("product-images", {
        public: true,
        fileSizeLimit: 5242880, // 5MB
        allowedMimeTypes: ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif"],
      })

      if (createError) {
        console.error("❌ Erreur création bucket:", createError)
        return
      }

      console.log("✅ Bucket créé avec succès:", data)
    }

    // Tester l'upload d'un fichier de test
    console.log("🧪 Test d'upload...")

    // Créer un blob de test (image 1x1 pixel)
    const canvas = document.createElement("canvas")
    canvas.width = 1
    canvas.height = 1
    const ctx = canvas.getContext("2d")
    ctx.fillStyle = "#FF0000"
    ctx.fillRect(0, 0, 1, 1)

    canvas.toBlob(async (blob) => {
      if (blob) {
        const testFile = new File([blob], "test.png", { type: "image/png" })

        const { data: uploadData, error: uploadError } = await supabase.storage
          .from("product-images")
          .upload(`test/test-${Date.now()}.png`, testFile)

        if (uploadError) {
          console.error("❌ Erreur test upload:", uploadError)
        } else {
          console.log("✅ Test upload réussi:", uploadData)

          // Nettoyer le fichier de test
          await supabase.storage.from("product-images").remove([uploadData.path])
          console.log("🧹 Fichier de test supprimé")
        }
      }
    }, "image/png")

    console.log("🎉 Configuration terminée!")
  } catch (error) {
    console.error("💥 Erreur lors de la configuration:", error)
  }
}

// Exécuter la configuration
setupStorageBucket()
