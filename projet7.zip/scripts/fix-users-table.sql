-- Correction de la table users pour supprimer password_hash
-- Supabase Auth gère déjà l'authentification

-- Supprimer la colonne password_hash car Supabase Auth s'en occupe
ALTER TABLE users DROP COLUMN IF EXISTS password_hash;

-- Modifier la contrainte sur l'email car Supabase Auth gère déjà l'unicité
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_email_key;

-- Ajouter une contrainte de clé étrangère vers auth.users
-- L'ID utilisateur doit correspondre à l'ID dans auth.users de Supabase
ALTER TABLE users ADD CONSTRAINT users_id_fkey 
FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;
