import { supabase } from "../lib/supabase-client.js"

async function createBucketSimple() {
  console.log("🚀 Création simple du bucket...")

  try {
    // Vérifier si le bucket existe
    const { data: buckets, error: listError } = await supabase.storage.listBuckets()

    if (listError) {
      console.error("❌ Erreur:", listError.message)
      console.log("\n💡 Solution: Créez le bucket manuellement dans Supabase Dashboard")
      console.log("1. Allez sur https://supabase.com/dashboard")
      console.log("2. Sélectionnez votre projet")
      console.log("3. Allez dans Storage")
      console.log('4. Cliquez sur "New bucket"')
      console.log("5. Nom: product-images")
      console.log("6. Public: Oui")
      console.log("7. File size limit: 5242880 (5MB)")
      return
    }

    const bucketExists = buckets?.some((bucket) => bucket.id === "product-images")

    if (bucketExists) {
      console.log("✅ Le bucket product-images existe déjà!")

      // Test d'upload
      const testContent = "test"
      const testFile = new File([testContent], "test.txt", { type: "text/plain" })

      const { error: uploadError } = await supabase.storage
        .from("product-images")
        .upload(`test-${Date.now()}.txt`, testFile)

      if (uploadError) {
        console.error("❌ Test d'upload échoué:", uploadError.message)
        console.log("\n💡 Le bucket existe mais les permissions peuvent être incorrectes")
      } else {
        console.log("✅ Test d'upload réussi! Le stockage fonctionne.")
      }

      return
    }

    // Essayer de créer le bucket
    console.log("📦 Tentative de création du bucket...")
    const { data, error } = await supabase.storage.createBucket("product-images", {
      public: true,
      fileSizeLimit: 5242880,
      allowedMimeTypes: ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif"],
    })

    if (error) {
      console.error("❌ Impossible de créer le bucket:", error.message)
      console.log("\n💡 SOLUTION MANUELLE:")
      console.log("1. Ouvrez https://supabase.com/dashboard")
      console.log("2. Sélectionnez votre projet")
      console.log('3. Allez dans "Storage" dans le menu de gauche')
      console.log('4. Cliquez sur "New bucket"')
      console.log("5. Configurez:")
      console.log("   - Name: product-images")
      console.log("   - Public: ✅ Oui")
      console.log("   - File size limit: 5242880")
      console.log("   - Allowed MIME types: image/jpeg,image/jpg,image/png,image/webp,image/gif")
      console.log('6. Cliquez "Save"')
      console.log("\n🔄 Puis relancez ce script pour vérifier")
    } else {
      console.log("✅ Bucket créé avec succès!")
    }
  } catch (error) {
    console.error("❌ Erreur:", error.message)
    console.log("\n💡 Créez le bucket manuellement dans l'interface Supabase")
  }
}

createBucketSimple()
