// TEST MANUEL DE LA BASE DE DONNÉES
console.log("🔍 Test manuel de connexion Supabase...")

// Simuler une connexion Supabase
const supabaseConfig = {
  url: "https://jwxtcnjcnxwtuwqizhkq.supabase.co",
  anonKey:
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3eHRjbmpjbnh3dHV3cWl6aGtxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk5MTE0NDcsImV4cCI6MjA2NTQ4NzQ0N30.srb73bSz_U6j2ahMp3WnO1_VJp0sqsWt24L0KuzvhDY",
  serviceKey:
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3eHRjbmpjbnh3dHV3cWl6aGtxIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc0OTkxMTQ0NywiZXhwIjoyMDY1NDg3NDQ3fQ.LHlrYB8Ed4aV6B9x0shMvPersHjCAgHzvUyeJduNA6E",
}

console.log("✅ Configuration Supabase:")
console.log("📍 URL:", supabaseConfig.url)
console.log("🔑 Anon Key:", supabaseConfig.anonKey.substring(0, 50) + "...")
console.log("🔐 Service Key:", supabaseConfig.serviceKey.substring(0, 50) + "...")

// Test de connexion avec fetch
async function testConnection() {
  try {
    console.log("\n🧪 Test de connexion avec fetch...")

    const response = await fetch(`${supabaseConfig.url}/rest/v1/users?select=count`, {
      method: "GET",
      headers: {
        apikey: supabaseConfig.anonKey,
        Authorization: `Bearer ${supabaseConfig.anonKey}`,
        "Content-Type": "application/json",
        Prefer: "count=exact",
      },
    })

    if (response.ok) {
      const data = await response.text()
      console.log("✅ Connexion réussie!")
      console.log("📊 Réponse:", data)
    } else {
      console.log("❌ Erreur de connexion:", response.status, response.statusText)
      const errorText = await response.text()
      console.log("📝 Détails:", errorText)
    }
  } catch (error) {
    console.error("❌ Erreur:", error.message)
  }
}

// Test d'insertion
async function testInsert() {
  try {
    console.log("\n🧪 Test d'insertion de produit...")

    const productData = {
      user_id: "00000000-0000-0000-0000-000000000000",
      name: "Test Product",
      category: "Test",
      price: 10.0,
      quantity: 1,
      is_active: true,
    }

    const response = await fetch(`${supabaseConfig.url}/rest/v1/products`, {
      method: "POST",
      headers: {
        apikey: supabaseConfig.serviceKey,
        Authorization: `Bearer ${supabaseConfig.serviceKey}`,
        "Content-Type": "application/json",
        Prefer: "return=representation",
      },
      body: JSON.stringify(productData),
    })

    if (response.ok) {
      const data = await response.json()
      console.log("✅ Insertion réussie!")
      console.log("📦 Produit créé:", data)

      // Nettoyer le test
      if (data && data[0] && data[0].id) {
        await fetch(`${supabaseConfig.url}/rest/v1/products?id=eq.${data[0].id}`, {
          method: "DELETE",
          headers: {
            apikey: supabaseConfig.serviceKey,
            Authorization: `Bearer ${supabaseConfig.serviceKey}`,
          },
        })
        console.log("🧹 Test nettoyé")
      }
    } else {
      console.log("❌ Erreur d'insertion:", response.status, response.statusText)
      const errorText = await response.text()
      console.log("📝 Détails:", errorText)
    }
  } catch (error) {
    console.error("❌ Erreur:", error.message)
  }
}

// Exécuter les tests
testConnection()
setTimeout(testInsert, 2000)

console.log("\n💡 Si vous voyez des erreurs, c'est normal - nous diagnostiquons les problèmes!")
