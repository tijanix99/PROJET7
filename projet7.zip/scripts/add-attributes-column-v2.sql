-- Vérifier si la colonne attributes existe déjà
DO $$ 
BEGIN
    -- Ajouter la colonne attributes si elle n'existe pas
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'products' AND column_name = 'attributes'
    ) THEN
        ALTER TABLE products ADD COLUMN attributes JSONB DEFAULT '{}';
        
        -- Ajouter un index pour améliorer les performances des requêtes sur les attributs
        CREATE INDEX IF NOT EXISTS idx_products_attributes ON products USING GIN (attributes);
        
        -- Mettre à jour les produits existants avec un objet JSON vide
        UPDATE products SET attributes = '{}' WHERE attributes IS NULL;
        
        RAISE NOTICE 'Colonne attributes ajoutée avec succès à la table products';
    ELSE
        RAISE NOTICE 'La colonne attributes existe déjà dans la table products';
    END IF;
END $$;
