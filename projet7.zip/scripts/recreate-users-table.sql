-- Recréer la table users sans password_hash
-- À utiliser si la correction précédente ne fonctionne pas

-- Sauvegarder les données existantes (si il y en a)
CREATE TABLE users_backup AS SELECT * FROM users;

-- Supprimer l'ancienne table
DROP TABLE IF EXISTS users CASCADE;

-- Recréer la table users sans password_hash
CREATE TABLE users (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    whatsapp_number VARCHAR(20),
    city VARCHAR(100),
    shop_name VARCHAR(255),
    profile_image TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Recréer les index
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- Recréer le trigger pour updated_at
CREATE TRIGGER update_users_updated_at 
    BEFORE UPDATE ON users 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Restaurer les données (sans password_hash)
INSERT INTO users (id, full_name, email, whatsapp_number, city, shop_name, profile_image, created_at, updated_at)
SELECT id, full_name, email, whatsapp_number, city, shop_name, profile_image, created_at, updated_at
FROM users_backup
WHERE id IN (SELECT id FROM auth.users);

-- Supprimer la sauvegarde
DROP TABLE users_backup;
