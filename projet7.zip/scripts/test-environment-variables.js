// Test des variables d'environnement
console.log("🔍 Test des variables d'environnement Supabase...")

// Vérifier les variables côté client
const clientUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const clientKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

console.log("📊 Variables détectées:")
console.log("- NEXT_PUBLIC_SUPABASE_URL:", clientUrl ? "✅ Définie" : "❌ Manquante")
console.log("- NEXT_PUBLIC_SUPABASE_ANON_KEY:", clientKey ? "✅ Définie" : "❌ Manquante")
console.log("- SUPABASE_SERVICE_ROLE_KEY:", serviceKey ? "✅ Définie" : "❌ Manquante")

if (!clientUrl || !clientKey) {
  console.error("❌ Variables d'environnement manquantes!")
  console.log("💡 Assurez-vous d'avoir créé le fichier .env.local avec:")
  console.log("NEXT_PUBLIC_SUPABASE_URL=https://jwxtcnjcnxwtuwqizhkq.supabase.co")
  console.log("NEXT_PUBLIC_SUPABASE_ANON_KEY=votre_clé_anon")
  console.log("SUPABASE_SERVICE_ROLE_KEY=votre_clé_service_role")
} else {
  console.log("✅ Configuration de base OK!")

  // Test de connexion basique
  try {
    const { createClient } = await import("@supabase/supabase-js")
    const supabase = createClient(clientUrl, clientKey)

    console.log("🔗 Test de connexion...")
    const { data, error } = await supabase.from("users").select("count", { count: "exact", head: true })

    if (error) {
      console.error("❌ Erreur de connexion:", error.message)
    } else {
      console.log("✅ Connexion réussie!")
      console.log("📊 Nombre d'utilisateurs:", data)
    }
  } catch (err) {
    console.error("❌ Erreur test connexion:", err.message)
  }
}
