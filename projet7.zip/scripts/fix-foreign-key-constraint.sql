-- Supprimer la contrainte de clé étrangère problématique
-- et utiliser RLS (Row Level Security) à la place

-- Supprimer la contrainte FK vers auth.users
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_id_fkey;

-- Supprimer aussi toute autre contrainte FK qui pourrait poser problème
ALTER TABLE products DROP CONSTRAINT IF EXISTS products_user_id_fkey;
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_user_id_fkey;
ALTER TABLE order_items DROP CONSTRAINT IF EXISTS order_items_order_id_fkey;
ALTER TABLE order_items DROP CONSTRAINT IF EXISTS order_items_product_id_fkey;
ALTER TABLE messages DROP CONSTRAINT IF EXISTS messages_user_id_fkey;
ALTER TABLE conversations DROP CONSTRAINT IF EXISTS conversations_user_id_fkey;
ALTER TABLE ia_training_data DROP CONSTRAINT IF EXISTS ia_training_data_user_id_fkey;
ALTER TABLE daily_summaries DROP CONSTRAINT IF EXISTS daily_summaries_user_id_fkey;
ALTER TABLE user_settings DROP CONSTRAINT IF EXISTS user_settings_user_id_fkey;

-- Activer RLS (Row Level Security) sur toutes les tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE ia_training_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_summaries ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;

-- Créer les politiques RLS pour sécuriser l'accès aux données

-- Politique pour la table users
CREATE POLICY "Users can view own profile" ON users
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON users
    FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON users
    FOR INSERT WITH CHECK (auth.uid() = id);

-- Politique pour la table products
CREATE POLICY "Users can manage own products" ON products
    FOR ALL USING (auth.uid() = user_id);

-- Politique pour la table orders
CREATE POLICY "Users can manage own orders" ON orders
    FOR ALL USING (auth.uid() = user_id);

-- Politique pour la table order_items
CREATE POLICY "Users can manage own order items" ON order_items
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM orders 
            WHERE orders.id = order_items.order_id 
            AND orders.user_id = auth.uid()
        )
    );

-- Politique pour la table messages
CREATE POLICY "Users can manage own messages" ON messages
    FOR ALL USING (auth.uid() = user_id);

-- Politique pour la table conversations
CREATE POLICY "Users can manage own conversations" ON conversations
    FOR ALL USING (auth.uid() = user_id);

-- Politique pour la table ia_training_data
CREATE POLICY "Users can manage own AI data" ON ia_training_data
    FOR ALL USING (auth.uid() = user_id);

-- Politique pour la table daily_summaries
CREATE POLICY "Users can view own summaries" ON daily_summaries
    FOR ALL USING (auth.uid() = user_id);

-- Politique pour la table user_settings
CREATE POLICY "Users can manage own settings" ON user_settings
    FOR ALL USING (auth.uid() = user_id);
