-- Script pour corriger définitivement la contrainte de statut des commandes
-- Version 2 - Plus robuste

-- 1. Vérifier la contrainte actuelle
SELECT conname, consrc 
FROM pg_constraint 
WHERE conrelid = 'orders'::regclass 
AND contype = 'c';

-- 2. Supprimer toutes les contraintes de statut existantes
DO $$ 
DECLARE
    constraint_name TEXT;
BEGIN
    FOR constraint_name IN 
        SELECT conname 
        FROM pg_constraint 
        WHERE conrelid = 'orders'::regclass 
        AND contype = 'c' 
        AND consrc LIKE '%status%'
    LOOP
        EXECUTE 'ALTER TABLE orders DROP CONSTRAINT IF EXISTS ' || constraint_name;
        RAISE NOTICE 'Contrainte supprimée: %', constraint_name;
    END LOOP;
END $$;

-- 3. Ajouter la nouvelle contrainte avec tous les statuts
ALTER TABLE orders ADD CONSTRAINT orders_status_check 
CHECK (status IN ('pending', 'confirmed', 'shipped', 'delivered'));

-- 4. Mettre à jour les données existantes avec des statuts invalides
UPDATE orders 
SET status = 'pending' 
WHERE status NOT IN ('pending', 'confirmed', 'shipped', 'delivered');

-- 5. Vérifier que tout fonctionne
SELECT 'Test insertion pending' as test;
INSERT INTO orders (id, user_id, order_number, client_name, total_amount, status, created_at, updated_at) 
VALUES (gen_random_uuid(), gen_random_uuid(), 'TEST-001', 'Test Client', 100, 'pending', NOW(), NOW());

SELECT 'Test update to confirmed' as test;
UPDATE orders SET status = 'confirmed' WHERE order_number = 'TEST-001';

SELECT 'Test update to shipped' as test;
UPDATE orders SET status = 'shipped' WHERE order_number = 'TEST-001';

SELECT 'Test update to delivered' as test;
UPDATE orders SET status = 'delivered' WHERE order_number = 'TEST-001';

-- 6. Nettoyer le test
DELETE FROM orders WHERE order_number = 'TEST-001';

-- 7. Afficher un résumé final
SELECT 
    status, 
    COUNT(*) as count,
    CASE 
        WHEN status IN ('pending', 'confirmed', 'shipped', 'delivered') THEN '✅ Valide'
        ELSE '❌ Invalide'
    END as validation
FROM orders 
GROUP BY status 
ORDER BY status;

SELECT '✅ Contrainte mise à jour avec succès!' as result;
