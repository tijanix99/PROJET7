-- Mettre à jour la contrainte de statut des commandes pour inclure tous les statuts
-- Supprimer l'ancienne contrainte
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_status_check;

-- Ajouter la nouvelle contrainte avec tous les statuts
ALTER TABLE orders ADD CONSTRAINT orders_status_check 
CHECK (status IN ('pending', 'confirmed', 'shipped', 'delivered'));

-- Vérifier les données existantes et corriger si nécessaire
UPDATE orders 
SET status = 'pending' 
WHERE status NOT IN ('pending', 'confirmed', 'shipped', 'delivered');

-- Afficher un résumé des statuts
SELECT status, COUNT(*) as count 
FROM orders 
GROUP BY status 
ORDER BY status;
