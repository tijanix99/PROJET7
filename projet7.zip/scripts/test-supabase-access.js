import { createClient } from "@supabase/supabase-js"

console.log("🔍 Test d'accès à Supabase...")

// Vérification des variables d'environnement
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

console.log("URL Supabase:", supabaseUrl ? "✅ Configurée" : "❌ Manquante")
console.log("Service Key:", supabaseServiceKey ? "✅ Configurée" : "❌ Manquante")

if (!supabaseUrl || !supabaseServiceKey) {
  console.error("❌ Variables d'environnement manquantes!")
  process.exit(1)
}

// Création du client admin
const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
})

async function testDatabase() {
  try {
    console.log("\n📊 Test de connexion à la base de données...")

    // Test 1: Lister les tables
    const { data: tables, error: tablesError } = await supabase
      .from("information_schema.tables")
      .select("table_name")
      .eq("table_schema", "public")

    if (tablesError) {
      console.log("❌ Erreur listage tables:", tablesError.message)
    } else {
      console.log("✅ Tables trouvées:", tables?.map((t) => t.table_name).join(", "))
    }

    // Test 2: Compter les utilisateurs
    const { count: usersCount, error: usersError } = await supabase
      .from("users")
      .select("*", { count: "exact", head: true })

    if (usersError) {
      console.log("❌ Erreur table users:", usersError.message)
    } else {
      console.log("✅ Utilisateurs dans la DB:", usersCount)
    }

    // Test 3: Compter les produits
    const { count: productsCount, error: productsError } = await supabase
      .from("products")
      .select("*", { count: "exact", head: true })

    if (productsError) {
      console.log("❌ Erreur table products:", productsError.message)
    } else {
      console.log("✅ Produits dans la DB:", productsCount)
    }

    // Test 4: Compter les commandes
    const { count: ordersCount, error: ordersError } = await supabase
      .from("orders")
      .select("*", { count: "exact", head: true })

    if (ordersError) {
      console.log("❌ Erreur table orders:", ordersError.message)
    } else {
      console.log("✅ Commandes dans la DB:", ordersCount)
    }

    // Test 5: Créer un utilisateur test
    console.log("\n🧪 Test de création d'utilisateur...")
    const testUser = {
      id: "test-user-" + Date.now(),
      full_name: "Utilisateur Test",
      email: "test@example.com",
      whatsapp_number: "+1234567890",
      city: "Test City",
      shop_name: "Test Shop",
    }

    const { data: newUser, error: createError } = await supabase.from("users").insert(testUser).select()

    if (createError) {
      console.log("❌ Erreur création utilisateur:", createError.message)
    } else {
      console.log("✅ Utilisateur créé avec succès!")

      // Nettoyer - supprimer l'utilisateur test
      await supabase.from("users").delete().eq("id", testUser.id)
      console.log("✅ Utilisateur test supprimé")
    }

    console.log("\n🎉 Test terminé! Votre base de données fonctionne!")
  } catch (error) {
    console.error("❌ Erreur générale:", error.message)
  }
}

testDatabase()
