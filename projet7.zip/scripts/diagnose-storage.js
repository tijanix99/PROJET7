import { supabase } from "../lib/supabase-client.js"

console.log("🔍 Diagnostic du stockage Supabase...")

// Vérifier la connexion
console.log("📡 Vérification de la connexion...")
const {
  data: { user },
  error: authError,
} = await supabase.auth.getUser()

if (authError) {
  console.error("❌ Erreur d'authentification:", authError.message)
} else {
  console.log("✅ Utilisateur connecté:", user?.email || "Anonyme")
}

// Lister les buckets
console.log("\n🪣 Vérification des buckets...")
try {
  const { data: buckets, error: bucketsError } = await supabase.storage.listBuckets()

  if (bucketsError) {
    console.error("❌ Erreur listage buckets:", bucketsError.message)
  } else {
    console.log("✅ Buckets disponibles:")
    buckets.forEach((bucket) => {
      console.log(`  - ${bucket.id} (public: ${bucket.public})`)
    })

    const productImagesBucket = buckets.find((b) => b.id === "product-images")
    if (productImagesBucket) {
      console.log("✅ Bucket 'product-images' trouvé!")
      console.log("   Détails:", JSON.stringify(productImagesBucket, null, 2))
    } else {
      console.log("❌ Bucket 'product-images' non trouvé!")
    }
  }
} catch (error) {
  console.error("❌ Erreur lors de la vérification des buckets:", error.message)
}

// Test d'upload simple
console.log("\n📤 Test d'upload...")
try {
  const testContent = `Test upload - ${new Date().toISOString()}`
  const testFile = new File([testContent], "test.txt", { type: "text/plain" })

  const { data: uploadData, error: uploadError } = await supabase.storage
    .from("product-images")
    .upload(`test/diagnostic-${Date.now()}.txt`, testFile)

  if (uploadError) {
    console.error("❌ Test d'upload échoué:", uploadError.message)

    if (uploadError.message.includes("Bucket not found")) {
      console.log("💡 Solution: Exécutez le script 'create-storage-bucket-admin.sql'")
    }
    if (uploadError.message.includes("policy")) {
      console.log("💡 Solution: Vérifiez les politiques RLS dans Supabase")
    }
  } else {
    console.log("✅ Test d'upload réussi!")
    console.log("   Fichier uploadé:", uploadData.path)

    // Nettoyer le fichier de test
    const { error: deleteError } = await supabase.storage.from("product-images").remove([uploadData.path])

    if (deleteError) {
      console.log("⚠️ Impossible de supprimer le fichier de test:", deleteError.message)
    } else {
      console.log("✅ Fichier de test nettoyé")
    }
  }
} catch (error) {
  console.error("❌ Erreur lors du test d'upload:", error.message)
}

console.log("\n🏁 Diagnostic terminé!")
