"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { supabase } from "@/lib/supabase-client"
import { Database, Users, Package, ShoppingCart, MessageSquare, Settings, Brain } from "lucide-react"

export default function DatabaseAdminPage() {
  const [users, setUsers] = useState([])
  const [products, setProducts] = useState([])
  const [orders, setOrders] = useState([])
  const [messages, setMessages] = useState([])
  const [settings, setSettings] = useState([])
  const [aiData, setAiData] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadAllData()
  }, [])

  const loadAllData = async () => {
    try {
      setLoading(true)

      // Charger toutes les données
      const [usersRes, productsRes, ordersRes, messagesRes, settingsRes, aiRes] = await Promise.all([
        supabase.from("users").select("*").order("created_at", { ascending: false }),
        supabase.from("products").select("*").order("created_at", { ascending: false }),
        supabase.from("orders").select("*").order("created_at", { ascending: false }),
        supabase.from("messages").select("*").order("timestamp", { ascending: false }).limit(50),
        supabase.from("user_settings").select("*"),
        supabase.from("ia_training_data").select("*").order("created_at", { ascending: false }).limit(20),
      ])

      setUsers(usersRes.data || [])
      setProducts(productsRes.data || [])
      setOrders(ordersRes.data || [])
      setMessages(messagesRes.data || [])
      setSettings(settingsRes.data || [])
      setAiData(aiRes.data || [])
    } catch (error) {
      console.error("Erreur chargement données:", error)
    } finally {
      setLoading(false)
    }
  }

  const exportData = async (tableName: string, data: any[]) => {
    const csv = [
      Object.keys(data[0] || {}).join(","),
      ...data.map((row) =>
        Object.values(row)
          .map((val) => `"${val}"`)
          .join(","),
      ),
    ].join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${tableName}_${new Date().toISOString().split("T")[0]}.csv`
    a.click()
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center">
            <Database className="h-8 w-8 mr-3" />
            Administration Base de Données
          </h1>
          <p className="text-gray-600 dark:text-gray-400">Visualisez et gérez toutes vos données Supabase</p>
        </div>
        <Button onClick={loadAllData}>Actualiser</Button>
      </div>

      {/* Statistiques générales */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Utilisateurs</p>
                <p className="text-2xl font-bold">{users.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Package className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Produits</p>
                <p className="text-2xl font-bold">{products.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <ShoppingCart className="h-5 w-5 text-purple-600" />
              <div>
                <p className="text-sm text-gray-600">Commandes</p>
                <p className="text-2xl font-bold">{orders.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <MessageSquare className="h-5 w-5 text-orange-600" />
              <div>
                <p className="text-sm text-gray-600">Messages</p>
                <p className="text-2xl font-bold">{messages.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Settings className="h-5 w-5 text-gray-600" />
              <div>
                <p className="text-sm text-gray-600">Paramètres</p>
                <p className="text-2xl font-bold">{settings.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Brain className="h-5 w-5 text-pink-600" />
              <div>
                <p className="text-sm text-gray-600">Données IA</p>
                <p className="text-2xl font-bold">{aiData.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="users" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="users">Utilisateurs</TabsTrigger>
          <TabsTrigger value="products">Produits</TabsTrigger>
          <TabsTrigger value="orders">Commandes</TabsTrigger>
          <TabsTrigger value="messages">Messages</TabsTrigger>
          <TabsTrigger value="settings">Paramètres</TabsTrigger>
          <TabsTrigger value="ai">Données IA</TabsTrigger>
        </TabsList>

        {/* Utilisateurs */}
        <TabsContent value="users">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Utilisateurs ({users.length})</CardTitle>
                <CardDescription>Liste de tous les utilisateurs inscrits</CardDescription>
              </div>
              <Button onClick={() => exportData("users", users)} variant="outline">
                Exporter CSV
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {users.map((user: any) => (
                  <div key={user.id} className="border rounded-lg p-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div>
                        <p className="font-medium">{user.full_name}</p>
                        <p className="text-sm text-gray-600">{user.email}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Boutique</p>
                        <p className="font-medium">{user.shop_name || "Non défini"}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Ville</p>
                        <p className="font-medium">{user.city || "Non défini"}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Inscrit le</p>
                        <p className="font-medium">{new Date(user.created_at).toLocaleDateString("fr-FR")}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Produits */}
        <TabsContent value="products">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Produits ({products.length})</CardTitle>
                <CardDescription>Liste de tous les produits créés</CardDescription>
              </div>
              <Button onClick={() => exportData("products", products)} variant="outline">
                Exporter CSV
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {products.map((product: any) => (
                  <div key={product.id} className="border rounded-lg p-4">
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                      <div>
                        <p className="font-medium">{product.name}</p>
                        <p className="text-sm text-gray-600">{product.description?.substring(0, 50)}...</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Prix</p>
                        <p className="font-medium">{product.price}€</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Stock</p>
                        <p className="font-medium">{product.quantity}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Statut</p>
                        <Badge variant={product.is_active ? "default" : "secondary"}>
                          {product.is_active ? "Actif" : "Inactif"}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Créé le</p>
                        <p className="font-medium">{new Date(product.created_at).toLocaleDateString("fr-FR")}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Commandes */}
        <TabsContent value="orders">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Commandes ({orders.length})</CardTitle>
                <CardDescription>Liste de toutes les commandes</CardDescription>
              </div>
              <Button onClick={() => exportData("orders", orders)} variant="outline">
                Exporter CSV
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {orders.map((order: any) => (
                  <div key={order.id} className="border rounded-lg p-4">
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                      <div>
                        <p className="font-medium">#{order.id.substring(0, 8)}</p>
                        <p className="text-sm text-gray-600">{order.customer_name}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Montant</p>
                        <p className="font-medium">{order.total_amount}€</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Statut</p>
                        <Badge variant={order.status === "completed" ? "default" : "secondary"}>{order.status}</Badge>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">WhatsApp</p>
                        <p className="font-medium">{order.customer_whatsapp}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Créée le</p>
                        <p className="font-medium">{new Date(order.created_at).toLocaleDateString("fr-FR")}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Messages */}
        <TabsContent value="messages">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Messages ({messages.length})</CardTitle>
                <CardDescription>Derniers messages WhatsApp</CardDescription>
              </div>
              <Button onClick={() => exportData("messages", messages)} variant="outline">
                Exporter CSV
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {messages.map((message: any) => (
                  <div key={message.id} className="border rounded-lg p-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div>
                        <p className="font-medium">{message.whatsapp_number}</p>
                        <Badge variant={message.is_from_user ? "default" : "secondary"}>
                          {message.is_from_user ? "Envoyé" : "Reçu"}
                        </Badge>
                      </div>
                      <div className="col-span-2">
                        <p className="text-sm text-gray-600">Message</p>
                        <p className="font-medium">{message.content?.substring(0, 100)}...</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Date</p>
                        <p className="font-medium">{new Date(message.timestamp).toLocaleString("fr-FR")}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Paramètres */}
        <TabsContent value="settings">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Paramètres Utilisateurs ({settings.length})</CardTitle>
                <CardDescription>Configuration de chaque utilisateur</CardDescription>
              </div>
              <Button onClick={() => exportData("settings", settings)} variant="outline">
                Exporter CSV
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {settings.map((setting: any) => (
                  <div key={setting.id} className="border rounded-lg p-4">
                    <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Utilisateur</p>
                        <p className="font-medium">{setting.user_id.substring(0, 8)}...</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Email Summary</p>
                        <Badge variant={setting.email_summary ? "default" : "secondary"}>
                          {setting.email_summary ? "Activé" : "Désactivé"}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Alertes Commandes</p>
                        <Badge variant={setting.order_alerts ? "default" : "secondary"}>
                          {setting.order_alerts ? "Activé" : "Désactivé"}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Alertes Messages</p>
                        <Badge variant={setting.message_alerts ? "default" : "secondary"}>
                          {setting.message_alerts ? "Activé" : "Désactivé"}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Objectif Quotidien</p>
                        <p className="font-medium">{setting.daily_goal || 1000}€</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Thème</p>
                        <p className="font-medium">{setting.theme || "system"}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Données IA */}
        <TabsContent value="ai">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Données IA ({aiData.length})</CardTitle>
                <CardDescription>Réponses automatiques configurées</CardDescription>
              </div>
              <Button onClick={() => exportData("ai_data", aiData)} variant="outline">
                Exporter CSV
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {aiData.map((ai: any) => (
                  <div key={ai.id} className="border rounded-lg p-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Question</p>
                        <p className="font-medium">{ai.question?.substring(0, 50)}...</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Réponse</p>
                        <p className="font-medium">{ai.response?.substring(0, 50)}...</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Statut</p>
                        <Badge variant={ai.is_active ? "default" : "secondary"}>
                          {ai.is_active ? "Actif" : "Inactif"}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
