import MessagesContent from "@/components/dashboard/messages-content"

export default function MessagesPage() {
  return <MessagesContent />
}
