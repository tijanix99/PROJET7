"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Save, Building, MapPin, Phone, Camera, Upload, X } from "lucide-react"
import { supabase, getCurrentUser } from "@/lib/supabase-client"
import { uploadProductImage, deleteProductImage } from "@/lib/storage"

export default function ProfilePage() {
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [uploadingImage, setUploadingImage] = useState(false)
  const [user, setUser] = useState<any>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [stats, setStats] = useState({
    products: 0,
    orders: 0,
    messages: 0,
    totalSales: 0,
  })

  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    whatsapp_number: "",
    city: "",
    shop_name: "",
    profile_image: "",
  })

  useEffect(() => {
    async function loadUserProfile() {
      try {
        setLoading(true)

        // Récupérer l'utilisateur actuel
        const currentUser = await getCurrentUser()

        if (!currentUser) {
          toast({
            title: "Non connecté",
            description: "Veuillez vous connecter pour accéder à votre profil",
            variant: "destructive",
          })
          return
        }

        // Récupérer les données du profil
        const { data: profile, error } = await supabase.from("users").select("*").eq("id", currentUser.id).single()

        if (error) throw error

        if (profile) {
          setUser(profile)
          setFormData({
            full_name: profile.full_name || "",
            email: profile.email || "",
            whatsapp_number: profile.whatsapp_number || "",
            city: profile.city || "",
            shop_name: profile.shop_name || "",
            profile_image: profile.profile_image || "",
          })
        }

        // Récupérer les statistiques
        const { data: products } = await supabase.from("products").select("id").eq("user_id", currentUser.id)

        const { data: orders } = await supabase.from("orders").select("id, total_amount").eq("user_id", currentUser.id)

        const { data: messages } = await supabase.from("messages").select("id").eq("user_id", currentUser.id)

        setStats({
          products: products?.length || 0,
          orders: orders?.length || 0,
          messages: messages?.length || 0,
          totalSales: orders?.reduce((sum, order) => sum + order.total_amount, 0) || 0,
        })
      } catch (error: any) {
        console.error("Erreur lors du chargement du profil:", error)
        toast({
          title: "Erreur",
          description: "Impossible de charger votre profil",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    loadUserProfile()
  }, [toast])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  // Gérer la sélection d'image
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Vérifier le type de fichier
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Erreur",
        description: "Veuillez sélectionner une image valide",
        variant: "destructive",
      })
      return
    }

    // Vérifier la taille (5MB max)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Erreur",
        description: "L'image ne doit pas dépasser 5MB",
        variant: "destructive",
      })
      return
    }

    // Créer un aperçu
    const reader = new FileReader()
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string)
    }
    reader.readAsDataURL(file)

    // Upload de l'image
    handleImageUpload(file)
  }

  // Upload de l'image vers Supabase Storage
  const handleImageUpload = async (file: File) => {
    try {
      setUploadingImage(true)

      const currentUser = await getCurrentUser()
      if (!currentUser) throw new Error("Non connecté")

      // Supprimer l'ancienne image si elle existe
      if (formData.profile_image) {
        await deleteProductImage(formData.profile_image)
      }

      // Upload de la nouvelle image
      const imageUrl = await uploadProductImage(file, currentUser.id, "profile")

      // Mettre à jour le formData
      setFormData((prev) => ({ ...prev, profile_image: imageUrl }))

      // Mettre à jour directement en base de données
      const { error } = await supabase.from("users").update({ profile_image: imageUrl }).eq("id", currentUser.id)

      if (error) throw error

      // Mettre à jour l'état local
      setUser((prev: any) => ({ ...prev, profile_image: imageUrl }))

      toast({
        title: "✅ Photo mise à jour",
        description: "Votre photo de profil a été changée avec succès",
      })
    } catch (error: any) {
      console.error("Erreur upload image:", error)
      toast({
        title: "Erreur",
        description: error.message || "Impossible d'uploader l'image",
        variant: "destructive",
      })
      setImagePreview(null)
    } finally {
      setUploadingImage(false)
    }
  }

  // Supprimer la photo de profil
  const handleRemoveImage = async () => {
    try {
      setUploadingImage(true)

      const currentUser = await getCurrentUser()
      if (!currentUser) throw new Error("Non connecté")

      // Supprimer l'image du storage
      if (formData.profile_image) {
        await deleteProductImage(formData.profile_image)
      }

      // Mettre à jour en base de données
      const { error } = await supabase.from("users").update({ profile_image: null }).eq("id", currentUser.id)

      if (error) throw error

      // Mettre à jour les états
      setFormData((prev) => ({ ...prev, profile_image: "" }))
      setUser((prev: any) => ({ ...prev, profile_image: null }))
      setImagePreview(null)

      toast({
        title: "✅ Photo supprimée",
        description: "Votre photo de profil a été supprimée",
      })
    } catch (error: any) {
      console.error("Erreur suppression image:", error)
      toast({
        title: "Erreur",
        description: "Impossible de supprimer l'image",
        variant: "destructive",
      })
    } finally {
      setUploadingImage(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      setSaving(true)

      const currentUser = await getCurrentUser()
      if (!currentUser) throw new Error("Non connecté")

      const { error } = await supabase
        .from("users")
        .update({
          full_name: formData.full_name,
          whatsapp_number: formData.whatsapp_number,
          city: formData.city,
          shop_name: formData.shop_name,
        })
        .eq("id", currentUser.id)

      if (error) throw error

      toast({
        title: "Profil mis à jour",
        description: "Vos informations ont été enregistrées avec succès",
      })
    } catch (error: any) {
      console.error("Erreur lors de la sauvegarde:", error)
      toast({
        title: "Erreur",
        description: "Impossible de sauvegarder vos modifications",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  // Obtenir les initiales pour l'avatar
  const getInitials = (name: string) => {
    if (!name) return "U"
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2)
  }

  // Formater la date
  const formatDate = (dateString: string) => {
    if (!dateString) return "N/A"
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("fr-FR", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(date)
  }

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Mon Profil</h1>

      <div className="grid gap-6 md:grid-cols-[1fr_3fr]">
        <div className="space-y-6">
          <Card>
            <CardHeader className="text-center">
              <div className="relative mx-auto">
                <Avatar className="h-24 w-24 mx-auto">
                  <AvatarImage
                    src={imagePreview || user?.profile_image || "/placeholder.svg?height=96&width=96"}
                    alt="Photo de profil"
                  />
                  <AvatarFallback className="text-xl">{getInitials(user?.full_name || "")}</AvatarFallback>
                </Avatar>

                {/* Overlay de chargement */}
                {uploadingImage && (
                  <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center">
                    <Loader2 className="h-6 w-6 animate-spin text-white" />
                  </div>
                )}

                {/* Bouton caméra */}
                <Button
                  size="sm"
                  variant="secondary"
                  className="absolute -bottom-2 -right-2 rounded-full h-8 w-8 p-0"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadingImage}
                >
                  <Camera className="h-4 w-4" />
                </Button>
              </div>

              <CardTitle className="mt-4">{user?.full_name}</CardTitle>
              <CardDescription>{user?.email}</CardDescription>

              {/* Boutons de gestion de l'image */}
              <div className="flex gap-2 justify-center mt-4">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadingImage}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Changer
                </Button>
                {(user?.profile_image || imagePreview) && (
                  <Button size="sm" variant="outline" onClick={handleRemoveImage} disabled={uploadingImage}>
                    <X className="h-4 w-4 mr-2" />
                    Supprimer
                  </Button>
                )}
              </div>

              {/* Input file caché */}
              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageSelect} className="hidden" />
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex items-center gap-2">
                <Building className="h-4 w-4 opacity-70" />
                <span>{user?.shop_name || "Non défini"}</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 opacity-70" />
                <span>{user?.city || "Non défini"}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 opacity-70" />
                <span>{user?.whatsapp_number || "Non défini"}</span>
              </div>
            </CardContent>
            <CardFooter>
              <div className="text-sm text-muted-foreground">Membre depuis {formatDate(user?.created_at)}</div>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Statistiques</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span>Produits</span>
                <span className="font-medium">{stats.products}</span>
              </div>
              <Separator />
              <div className="flex justify-between">
                <span>Commandes</span>
                <span className="font-medium">{stats.orders}</span>
              </div>
              <Separator />
              <div className="flex justify-between">
                <span>Messages</span>
                <span className="font-medium">{stats.messages}</span>
              </div>
              <Separator />
              <div className="flex justify-between">
                <span>Ventes totales</span>
                <span className="font-medium">{stats.totalSales.toFixed(2)} DH</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Tabs defaultValue="personal">
            <TabsList className="mb-4">
              <TabsTrigger value="personal">Informations personnelles</TabsTrigger>
              <TabsTrigger value="business">Informations business</TabsTrigger>
            </TabsList>

            <form onSubmit={handleSubmit}>
              <TabsContent value="personal" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Informations personnelles</CardTitle>
                    <CardDescription>Mettez à jour vos informations personnelles</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="full_name">Nom complet</Label>
                      <Input id="full_name" name="full_name" value={formData.full_name} onChange={handleChange} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" name="email" value={formData.email} disabled />
                      <p className="text-sm text-muted-foreground">L'email ne peut pas être modifié</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="whatsapp_number">Numéro WhatsApp</Label>
                      <Input
                        id="whatsapp_number"
                        name="whatsapp_number"
                        value={formData.whatsapp_number}
                        onChange={handleChange}
                        placeholder="Ex: 612345678"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="city">Ville</Label>
                      <Input id="city" name="city" value={formData.city} onChange={handleChange} />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="business" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Informations business</CardTitle>
                    <CardDescription>Mettez à jour les informations de votre boutique</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="shop_name">Nom de la boutique</Label>
                      <Input id="shop_name" name="shop_name" value={formData.shop_name} onChange={handleChange} />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <div className="mt-6 flex justify-end">
                <Button type="submit" disabled={saving}>
                  {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  <Save className="mr-2 h-4 w-4" />
                  Enregistrer les modifications
                </Button>
              </div>
            </form>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
