import OrdersContent from "@/components/dashboard/orders-content"

export default function OrdersPage() {
  return <OrdersContent />
}
