"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  CheckCircle2,
  Circle,
  User,
  ShoppingBag,
  MessageCircle,
  Bot,
  ShoppingCart,
  Settings,
  Rocket,
  ArrowRight,
  Star,
  Target,
  Zap,
} from "lucide-react"
import { getCurrentUser } from "@/lib/supabase-client"
import { getOnboardingStatus, updateOnboardingStep } from "@/lib/database"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"

export default function OnboardingPage() {
  const [user, setUser] = useState<any>(null)
  const [onboardingStatus, setOnboardingStatus] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    loadOnboardingData()
  }, [])

  const loadOnboardingData = async () => {
    try {
      const currentUser = await getCurrentUser()
      if (!currentUser) return

      setUser(currentUser)
      const status = await getOnboardingStatus(currentUser.id)
      setOnboardingStatus(status)
    } catch (error) {
      console.error("Erreur onboarding:", error)
      toast({
        title: "Erreur",
        description: "Impossible de charger les données d'onboarding",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const completeStep = async (stepKey: string) => {
    try {
      await updateOnboardingStep(user.id, { [stepKey]: true })
      await loadOnboardingData()
      toast({
        title: "Étape complétée !",
        description: "Vous progressez bien dans la configuration de votre boutique",
      })
    } catch (error) {
      console.error("Erreur completion step:", error)
    }
  }

  const onboardingSteps = [
    {
      id: "profile",
      title: "Complétez votre profil",
      description: "Ajoutez vos informations personnelles et votre ville",
      icon: User,
      completed: onboardingStatus?.profile_completed || false,
      link: "/dashboard/settings",
      color: "from-gray-800 to-gray-900",
      points: 20,
    },
    {
      id: "products",
      title: "Ajoutez vos premiers produits",
      description: `Ajoutez au moins 3 produits (${onboardingStatus?.products_added || 0}/3)`,
      icon: ShoppingBag,
      completed: (onboardingStatus?.products_added || 0) >= 3,
      link: "/dashboard/products",
      color: "from-green-500 to-emerald-500",
      points: 30,
    },
    {
      id: "whatsapp",
      title: "Connectez WhatsApp",
      description: "Configurez votre numéro WhatsApp Business",
      icon: MessageCircle,
      completed: onboardingStatus?.whatsapp_connected || false,
      link: "/dashboard/messages",
      color: "from-green-600 to-green-700",
      points: 25,
    },
    {
      id: "ai",
      title: "Configurez l'IA",
      description: `Créez au moins 5 réponses automatiques (${onboardingStatus?.ai_responses || 0}/5)`,
      icon: Bot,
      completed: (onboardingStatus?.ai_responses || 0) >= 5,
      link: "/dashboard/ai-assistant",
      color: "from-purple-500 to-violet-500",
      points: 35,
    },
    {
      id: "order",
      title: "Créez votre première commande",
      description: "Testez le système avec une commande d'exemple",
      icon: ShoppingCart,
      completed: onboardingStatus?.first_order_created || false,
      link: "/dashboard/orders",
      color: "from-orange-500 to-red-500",
      points: 40,
    },
    {
      id: "settings",
      title: "Personnalisez vos paramètres",
      description: "Configurez vos préférences et notifications",
      icon: Settings,
      completed: false, // À implémenter
      link: "/dashboard/settings",
      color: "from-indigo-500 to-purple-500",
      points: 15,
    },
  ]

  const completedSteps = onboardingSteps.filter((step) => step.completed).length
  const totalSteps = onboardingSteps.length
  const progressPercentage = (completedSteps / totalSteps) * 100
  const totalPoints = onboardingSteps.filter((step) => step.completed).reduce((sum, step) => sum + step.points, 0)

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
          className="animate-spin rounded-full h-8 w-8 border-b-2 border-lime-500"
        />
      </div>
    )
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header avec animation */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center"
      >
        <div className="flex items-center justify-center mb-4">
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
          >
            <Rocket className="h-12 w-12 text-lime-500" />
          </motion.div>
        </div>
        <h1 className="text-4xl font-bold bg-lime-500 bg-clip-text text-transparent mb-2">
          Bienvenue sur InstaSell Pro+ 🚀
        </h1>
        <p className="text-gray-600 dark:text-gray-400 text-lg">
          Configurons votre boutique en ligne en quelques étapes simples
        </p>
      </motion.div>

      {/* Progression globale */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center">
                  <Target className="h-5 w-5 mr-2 text-lime-500" />
                  Progression de l'onboarding
                </CardTitle>
                <CardDescription>
                  {completedSteps} sur {totalSteps} étapes complétées
                </CardDescription>
              </div>
              <div className="text-right">
                <div className="flex items-center space-x-2">
                  <Star className="h-5 w-5 text-yellow-500" />
                  <span className="text-2xl font-bold text-yellow-600">{totalPoints}</span>
                  <span className="text-sm text-gray-500">points</span>
                </div>
                <Badge
                  className={
                    progressPercentage === 100
                      ? "bg-green-100 text-green-800"
                      : progressPercentage >= 50
                        ? "bg-gray-900 text-lime-500"
                        : "bg-yellow-100 text-yellow-800"
                  }
                >
                  {progressPercentage === 100
                    ? "🎉 Terminé !"
                    : progressPercentage >= 50
                      ? "🔥 En bonne voie"
                      : "🚀 Démarrage"}
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between text-sm">
                <span>Progression</span>
                <span className="font-medium">{progressPercentage.toFixed(0)}%</span>
              </div>
              <Progress value={progressPercentage} className="h-3" />
              {progressPercentage === 100 && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg"
                >
                  <h3 className="font-semibold text-green-800 dark:text-green-200 mb-2">
                    🎉 Félicitations ! Votre boutique est prête !
                  </h3>
                  <p className="text-green-600 dark:text-green-300 text-sm mb-4">
                    Vous avez terminé toutes les étapes d'onboarding. Votre boutique InstaSell Pro+ est maintenant
                    opérationnelle !
                  </p>
                  <Link href="/dashboard">
                    <Button className="bg-green-600 hover:bg-green-700">
                      <Zap className="h-4 w-4 mr-2" />
                      Accéder au Dashboard
                    </Button>
                  </Link>
                </motion.div>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Liste des étapes */}
      <div className="grid gap-4">
        {onboardingSteps.map((step, index) => (
          <motion.div
            key={step.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            whileHover={{ scale: 1.02 }}
          >
            <Card
              className={`cursor-pointer transition-all duration-300 hover:shadow-lg ${
                step.completed
                  ? "bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800"
                  : "hover:shadow-xl"
              }`}
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <motion.div
                      className={`p-3 rounded-full bg-gradient-to-r ${step.color} ${
                        step.completed ? "ring-4 ring-green-200 dark:ring-green-800" : ""
                      }`}
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.6 }}
                    >
                      <step.icon className="h-6 w-6 text-white" />
                    </motion.div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <h3 className="font-semibold text-lg">{step.title}</h3>
                        {step.completed ? (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{ type: "spring", delay: 0.2 }}
                          >
                            <CheckCircle2 className="h-6 w-6 text-green-600" />
                          </motion.div>
                        ) : (
                          <Circle className="h-6 w-6 text-gray-400" />
                        )}
                      </div>
                      <p className="text-gray-600 dark:text-gray-400 mt-1">{step.description}</p>
                      <div className="flex items-center space-x-4 mt-2">
                        <Badge variant="outline" className="text-xs">
                          +{step.points} points
                        </Badge>
                        {step.completed && <Badge className="bg-green-100 text-green-800 text-xs">✅ Terminé</Badge>}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Link href={step.link}>
                      <Button
                        variant={step.completed ? "outline" : "default"}
                        className={
                          step.completed
                            ? "border-green-300 text-green-700 hover:bg-green-50"
                            : `bg-gradient-to-r ${step.color} hover:shadow-lg`
                        }
                      >
                        {step.completed ? "Modifier" : "Commencer"}
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Actions rapides */}
      {progressPercentage < 100 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="h-5 w-5 mr-2 text-yellow-500" />
                Actions recommandées
              </CardTitle>
              <CardDescription>Étapes prioritaires pour lancer votre boutique rapidement</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {onboardingSteps
                  .filter((step) => !step.completed)
                  .slice(0, 4)
                  .map((step, index) => (
                    <motion.div
                      key={step.id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      whileHover={{ scale: 1.05 }}
                    >
                      <Link href={step.link}>
                        <Card className="cursor-pointer hover:shadow-lg transition-all duration-300 h-full">
                          <CardContent className="p-4">
                            <div className="flex items-center space-x-3">
                              <div className={`p-2 rounded-lg bg-gradient-to-r ${step.color}`}>
                                <step.icon className="h-5 w-5 text-white" />
                              </div>
                              <div className="flex-1">
                                <h4 className="font-medium">{step.title}</h4>
                                <p className="text-sm text-gray-600 dark:text-gray-400">{step.description}</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    </motion.div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  )
}
