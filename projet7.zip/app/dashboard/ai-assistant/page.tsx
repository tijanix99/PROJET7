import AIAssistantContent from "@/components/dashboard/ai-assistant-content"

export default function AIAssistantPage() {
  return <AIAssistantContent />
}
