import SettingsContent from "@/components/dashboard/settings-content"

export default function SettingsPage() {
  return <SettingsContent />
}
