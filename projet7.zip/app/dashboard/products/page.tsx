import ProductsContent from "@/components/dashboard/products-content"

export default function ProductsPage() {
  return <ProductsContent />
}
