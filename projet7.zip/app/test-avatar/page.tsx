import TestAvatarMenu from "@/components/test-avatar-menu"

export default function TestAvatarPage() {
  return <TestAvatarMenu />
}
