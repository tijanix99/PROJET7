# Guide de Configuration du Stockage d'Images

## Méthode 1: Création Manuelle (Recommandée)

### Étapes dans l'interface Supabase:

1. **Ouvrir Supabase Dashboard**
   - Allez sur https://supabase.com/dashboard
   - Connectez-vous à votre compte
   - Sélectionnez votre projet

2. **Accéder au Storage**
   - Dans le menu de gauche, cliquez sur "Storage"
   - Vous verrez la liste des buckets existants

3. **Créer le Bucket**
   - Cliquez sur "New bucket"
   - Configurez:
     - **Name**: `product-images`
     - **Public**: ✅ Coché (important!)
     - **File size limit**: `5242880` (5MB)
     - **Allowed MIME types**: 
       \`\`\`
       image/jpeg
       image/jpg
       image/png
       image/webp
       image/gif
       \`\`\`

4. **Configurer les Politiques RLS**
   - Allez dans l'onglet "Policies" du bucket
   - Créez ces politiques:

   **Politique 1: Upload**
   \`\`\`sql
   CREATE POLICY "Authenticated users can upload" ON storage.objects
   FOR INSERT WITH CHECK (
     bucket_id = 'product-images' 
     AND auth.role() = 'authenticated'
   );
   \`\`\`

   **Politique 2: Lecture publique**
   \`\`\`sql
   CREATE POLICY "Public read access" ON storage.objects
   FOR SELECT USING (bucket_id = 'product-images');
   \`\`\`

   **Politique 3: Suppression**
   \`\`\`sql
   CREATE POLICY "Users can delete their files" ON storage.objects
   FOR DELETE USING (
     bucket_id = 'product-images' 
     AND auth.role() = 'authenticated'
   );
   \`\`\`

5. **Vérifier la Configuration**
   - Exécutez le script `create-bucket-simple.js`
   - Il devrait afficher "✅ Le bucket product-images existe déjà!"

## Méthode 2: Script Automatique

Si vous avez la clé de service (service_role_key):

\`\`\`bash
# Exécuter le script de configuration complète
node scripts/setup-storage-complete.js
\`\`\`

## Vérification

Une fois configuré, testez l'upload d'images dans votre application:

1. Allez sur `/dashboard/products`
2. Cliquez sur "Ajouter un produit"
3. Essayez d'uploader une image
4. Vous ne devriez plus voir d'erreur de bucket

## Dépannage

### Erreur "Bucket not found"
- Le bucket n'existe pas → Suivez la Méthode 1

### Erreur "Policy violation"
- Les politiques RLS ne sont pas configurées → Ajoutez les politiques de l'étape 4

### Erreur "File too large"
- L'image dépasse 5MB → Réduisez la taille de l'image

### Erreur "Invalid file type"
- Le type de fichier n'est pas autorisé → Utilisez JPG, PNG, WEBP ou GIF
\`\`\`

Maintenant, mettons à jour la fonction de stockage pour être plus robuste :
