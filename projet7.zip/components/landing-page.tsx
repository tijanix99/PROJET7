"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  MessageCircle,
  Bot,
  Package,
  ShoppingCart,
  BarChart3,
  Mail,
  Users,
  Smartphone,
  Globe,
  Shield,
  Zap,
  Star,
  Check,
  ArrowRight,
  Play,
} from "lucide-react"
import Link from "next/link"

export default function LandingPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  useEffect(() => {
    // Scroll animation observer
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible")
          }
        })
      },
      { threshold: 0.1 },
    )

    const animatedElements = document.querySelectorAll(".animate-on-scroll")
    animatedElements.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-700 text-white overflow-hidden">
      {/* Header */}
      <header className="border-b border-slate-600/50 bg-slate-800/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-green-500 to-blue-600 p-2 rounded-lg shadow-lg">
                <MessageCircle className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold text-white">TJR</span>
            </Link>

            {/* Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <a href="#fonctionnalites" className="text-slate-300 hover:text-white transition-colors">
                Fonctionnalités
              </a>
              <a href="#pourquoi-tjr" className="text-slate-300 hover:text-white transition-colors">
                Pourquoi TJR
              </a>
              <a href="#tarifs" className="text-slate-300 hover:text-white transition-colors">
                Tarifs
              </a>
              <a href="#temoignages" className="text-slate-300 hover:text-white transition-colors">
                Témoignages
              </a>
            </nav>

            {/* Auth Buttons */}
            <div className="flex items-center space-x-4">
              <Link href="/auth/login">
                <Button variant="ghost" className="text-white hover:bg-slate-700/50">
                  Se connecter
                </Button>
              </Link>
              <Link href="/auth/register">
                <Button className="bg-gradient-to-r from-green-600 to-blue-600 text-white hover:from-green-700 hover:to-blue-700 shadow-lg">
                  Commencer maintenant
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden bg-pattern">
        {/* Background Effects */}
        <div className="absolute inset-0">
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-full blur-3xl"></div>
          <div className="absolute top-1/4 right-1/4 w-[400px] h-[400px] bg-gradient-to-r from-blue-500/10 to-green-500/10 rounded-full blur-2xl"></div>
        </div>

        <div className="container mx-auto text-center relative z-10">
          {/* Badge */}
          <div className="mb-8 animate-fade-in">
            <Badge className="bg-green-500/20 text-green-300 border border-green-500/30 px-4 py-2 text-sm shadow-lg">
              🇲🇦 Plateforme SaaS 100% marocaine
            </Badge>
          </div>

          {/* Main Title */}
          <h1 className="text-5xl md:text-7xl font-bold mb-8 leading-tight animate-fade-in delay-100">
            Transformez WhatsApp en{" "}
            <span className="bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
              machine de vente intelligente
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-slate-300 mb-12 max-w-4xl mx-auto animate-fade-in delay-200">
            Transformez WhatsApp en machine de vente intelligente. Vendez mieux, plus vite, avec plus d'impact grâce à
            notre agent IA redoutablement efficace qui gère instantanément vos conversations clients.
          </p>

          {/* Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16 animate-fade-in delay-300">
            <Link href="/auth/register">
              <Button
                size="lg"
                className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 px-8 py-4 text-lg font-medium shadow-xl"
              >
                <Play className="mr-2 h-5 w-5" />
                Voir la démo
              </Button>
            </Link>
            <Button
              size="lg"
              variant="outline"
              className="border-slate-500 text-white hover:bg-slate-700/50 px-8 py-4 text-lg font-medium"
            >
              <ArrowRight className="mr-2 h-5 w-5" />
              Commencer maintenant
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-2xl mx-auto mb-16 animate-fade-in delay-400">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400 mb-2">500 MAD</div>
              <div className="text-slate-400">Prix unique par mois</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-400 mb-2">24h/24</div>
              <div className="text-slate-400">Agent IA disponible</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-400 mb-2">100%</div>
              <div className="text-slate-400">Interface responsive</div>
            </div>
          </div>

          {/* Dashboard Preview */}
          <div className="relative max-w-6xl mx-auto animate-fade-in delay-500">
            {/* Glow Effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-2xl blur-2xl scale-105"></div>

            {/* Dashboard Interface */}
            <div className="relative bg-slate-800/90 backdrop-blur-sm rounded-2xl overflow-hidden shadow-2xl border border-slate-600/50">
              {/* Title Bar */}
              <div className="bg-slate-700/80 px-4 py-3 flex items-center justify-between border-b border-slate-600/50">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                </div>
                <div className="flex items-center space-x-4 text-sm text-slate-400">
                  <span>DASHBOARD</span>
                  <span>WHATSAPP</span>
                  <span>PRODUITS</span>
                </div>
                <div className="flex items-center space-x-2 text-slate-400">
                  <button className="hover:text-white">−</button>
                  <button className="hover:text-white">□</button>
                  <button className="hover:text-white">×</button>
                </div>
              </div>

              <div className="flex h-96">
                {/* Sidebar */}
                <div className="w-64 bg-slate-700/50 border-r border-slate-600/50 p-4">
                  <div className="text-xs text-slate-400 mb-3 uppercase tracking-wide">TJR Dashboard</div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2 text-green-400 bg-green-500/20 p-2 rounded">
                      <BarChart3 className="h-4 w-4" />
                      <span>Statistiques</span>
                    </div>
                    <div className="flex items-center space-x-2 text-slate-300 p-2 hover:bg-slate-600/50 rounded cursor-pointer">
                      <MessageCircle className="h-4 w-4" />
                      <span>Messages WhatsApp</span>
                    </div>
                    <div className="flex items-center space-x-2 text-slate-300 p-2 hover:bg-slate-600/50 rounded cursor-pointer">
                      <Package className="h-4 w-4" />
                      <span>Produits</span>
                    </div>
                    <div className="flex items-center space-x-2 text-slate-300 p-2 hover:bg-slate-600/50 rounded cursor-pointer">
                      <ShoppingCart className="h-4 w-4" />
                      <span>Commandes</span>
                    </div>
                    <div className="flex items-center space-x-2 text-slate-300 p-2 hover:bg-slate-600/50 rounded cursor-pointer">
                      <Bot className="h-4 w-4" />
                      <span>Agent IA</span>
                    </div>
                  </div>
                </div>

                {/* Main Content */}
                <div className="flex-1 bg-slate-800/50 p-6">
                  <div className="grid grid-cols-2 gap-4 h-full">
                    <div className="bg-slate-700/50 rounded-lg p-4 border border-slate-600/50">
                      <h3 className="text-white font-medium mb-2">Ventes du jour</h3>
                      <div className="text-2xl font-bold text-green-400">2,450 MAD</div>
                      <div className="text-sm text-slate-400">+15% vs hier</div>
                    </div>
                    <div className="bg-slate-700/50 rounded-lg p-4 border border-slate-600/50">
                      <h3 className="text-white font-medium mb-2">Messages reçus</h3>
                      <div className="text-2xl font-bold text-blue-400">23</div>
                      <div className="text-sm text-slate-400">12 traités par l'IA</div>
                    </div>
                    <div className="bg-slate-700/50 rounded-lg p-4 border border-slate-600/50">
                      <h3 className="text-white font-medium mb-2">Commandes</h3>
                      <div className="text-2xl font-bold text-purple-400">8</div>
                      <div className="text-sm text-slate-400">5 en cours</div>
                    </div>
                    <div className="bg-slate-700/50 rounded-lg p-4 border border-slate-600/50">
                      <h3 className="text-white font-medium mb-2">Produits actifs</h3>
                      <div className="text-2xl font-bold text-orange-400">47</div>
                      <div className="text-sm text-slate-400">3 en rupture</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Fonctionnalités Section */}
      <section id="fonctionnalites" className="py-20 px-4 border-t border-slate-600/50 bg-slate-800/30">
        <div className="container mx-auto">
          <div className="text-center mb-16 animate-on-scroll">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Tout ce dont vous avez besoin pour{" "}
              <span className="bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
                vendre efficacement
              </span>
            </h2>
            <p className="text-xl text-slate-400 max-w-3xl mx-auto">
              TJR révolutionne puissamment votre business Instagram avec des outils redoutablement efficaces qui
              optimisent instantanément vos ventes
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: MessageCircle,
                title: "Chat WhatsApp ultra-performant",
                description:
                  "Transformez instantanément WhatsApp en centre de commande. Gérez puissamment tous vos clients depuis une interface redoutablement efficace.",
                color: "text-green-400",
              },
              {
                icon: Bot,
                title: "Agent IA commercial révolutionnaire",
                description:
                  "Agent IA qui vend intelligemment 24h/24. Personnalisez redoutablement son ton pour convertir puissamment vos prospects en clients.",
                color: "text-blue-400",
              },
              {
                icon: Package,
                title: "Gestion produits simplifiée",
                description:
                  "Gérez instantanément votre catalogue avec une simplicité déconcertante. Synchronisation intelligente redoutablement efficace.",
                color: "text-purple-400",
              },
              {
                icon: ShoppingCart,
                title: "Commandes ultra-fluides",
                description:
                  "Gérez vos commandes avec une simplicité déconcertante. Workflow intelligent de la vente à la livraison, puissamment optimisé.",
                color: "text-orange-400",
              },
              {
                icon: BarChart3,
                title: "Analytics redoutablement précis",
                description:
                  "Analysez instantanément vos performances avec des données puissamment détaillées. Optimisez intelligemment vos ventes.",
                color: "text-pink-400",
              },
              {
                icon: Mail,
                title: "Notifications intelligentes",
                description:
                  "Recevez chaque matin un résumé intelligent dans votre boîte mail. Alertes instantanées redoutablement efficaces.",
                color: "text-cyan-400",
              },
              {
                icon: Users,
                title: "Collaboration puissante",
                description:
                  "Gérez intelligemment plusieurs boutiques et équipes. Permissions redoutablement flexibles et sécurisées.",
                color: "text-red-400",
              },
              {
                icon: Smartphone,
                title: "Expérience mobile parfaite",
                description:
                  "Interface puissamment responsive. Vendez instantanément depuis n'importe quel appareil avec une efficacité déconcertante.",
                color: "text-yellow-400",
              },
              {
                icon: Shield,
                title: "Sécurité militaire",
                description:
                  "Protection redoutablement avancée. Vos données sont intelligemment chiffrées et puissamment sécurisées.",
                color: "text-indigo-400",
              },
            ].map((feature, index) => (
              <div key={index} className="animate-on-scroll">
                <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-600/50 hover:border-slate-500/50 transition-all duration-300 h-full hover:scale-105 shadow-lg">
                  <CardHeader>
                    <feature.icon className={`h-8 w-8 ${feature.color} mb-2`} />
                    <CardTitle className="text-white">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-slate-400">{feature.description}</CardDescription>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pourquoi TJR Section */}
      <section id="pourquoi-tjr" className="py-20 px-4 border-t border-slate-600/50 bg-slate-900/50">
        <div className="container mx-auto">
          <div className="text-center mb-16 animate-on-scroll">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Pourquoi choisir{" "}
              <span className="bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">TJR ?</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="animate-on-scroll">
              <div className="space-y-8">
                {[
                  {
                    icon: Zap,
                    title: "Gain de temps spectaculaire",
                    description:
                      "L'agent IA répond intelligemment à vos clients 24h/24. Libérez-vous instantanément des tâches répétitives pour vous concentrer puissamment sur la croissance.",
                  },
                  {
                    icon: BarChart3,
                    title: "Boostez redoutablement vos ventes",
                    description:
                      "Dashboard puissamment analytique pour optimiser instantanément vos performances. Identifiez intelligemment vos produits stars et maximisez vos profits.",
                  },
                  {
                    icon: Globe,
                    title: "Solution 100% marocaine premium",
                    description:
                      "Développée puissamment au Maroc, pour les entrepreneurs marocains. Support instantané en français, tarification transparente en MAD.",
                  },
                  {
                    icon: Shield,
                    title: "Fiabilité redoutablement solide",
                    description:
                      "Infrastructure puissamment sécurisée, données intelligemment chiffrées, sauvegardes instantanées. Votre business est protégé.",
                  },
                ].map((benefit, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="bg-green-500/20 p-3 rounded-lg">
                      <benefit.icon className="h-6 w-6 text-green-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-white mb-2">{benefit.title}</h3>
                      <p className="text-slate-400">{benefit.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative animate-on-scroll">
              <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-2xl p-8 border border-slate-600/50 backdrop-blur-sm">
                <div className="text-center">
                  <div className="text-6xl font-bold text-green-400 mb-4">500 MAD</div>
                  <div className="text-xl text-white mb-6">par mois seulement</div>
                  <div className="space-y-3 text-left">
                    {[
                      "Chat WhatsApp intégré",
                      "Agent IA personnalisable",
                      "Gestion complète produits/commandes",
                      "Dashboard statistiques avancé",
                      "Notifications email automatiques",
                      "Support technique inclus",
                    ].map((feature, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <Check className="h-5 w-5 text-green-400" />
                        <span className="text-slate-300">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="tarifs" className="py-20 px-4 border-t border-slate-600/50">
        <div className="container mx-auto">
          <div className="text-center mb-16 animate-on-scroll">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Boostez vos ventes pour{" "}
              <span className="bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
                seulement 500 MAD/mois
              </span>
            </h2>
            <p className="text-xl text-slate-400">
              Une solution redoutablement complète, puissamment efficace. Transformez instantanément votre business sans
              engagement.
            </p>
          </div>

          <div className="max-w-lg mx-auto animate-on-scroll">
            <Card className="bg-gradient-to-b from-slate-800/80 to-slate-700/80 backdrop-blur-sm border-green-500/50 border-2 relative overflow-hidden shadow-2xl">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-green-400 to-blue-500"></div>

              <CardHeader className="text-center pb-8">
                <div className="inline-block bg-green-500/20 text-green-400 px-3 py-1 rounded-full text-sm font-medium mb-4">
                  TJR PRO
                </div>
                <CardTitle className="text-4xl font-bold text-white mb-2">
                  500 MAD
                  <span className="text-lg font-normal text-slate-400">/mois</span>
                </CardTitle>
                <CardDescription className="text-slate-400">Tout inclus, sans limite</CardDescription>
              </CardHeader>

              <CardContent className="space-y-6">
                <div className="space-y-4">
                  {[
                    "Chat WhatsApp intégré illimité",
                    "Agent IA intelligent",
                    "Gestion produits et commandes",
                    "Dashboard statistiques complet",
                    "Notifications email automatiques",
                    "Multi-utilisateur / Multi-boutique",
                    "Interface 100% responsive",
                    "Support technique prioritaire",
                    "Mises à jour automatiques",
                    "Données sécurisées et protégées",
                  ].map((feature, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <Check className="h-5 w-5 text-green-400 flex-shrink-0" />
                      <span className="text-slate-300">{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-6 space-y-4">
                  <Link href="/auth/register" className="block">
                    <Button className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white py-3 text-lg font-medium shadow-lg">
                      Commencer maintenant
                    </Button>
                  </Link>
                  <Button variant="outline" className="w-full border-slate-500 text-white hover:bg-slate-700/50">
                    <Play className="mr-2 h-4 w-4" />
                    Voir la démo
                  </Button>
                </div>

                <div className="text-center text-sm text-slate-400 pt-4">
                  Pas d'engagement, résiliable à tout moment
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Témoignages Section */}
      <section id="temoignages" className="py-20 px-4 border-t border-slate-600/50 bg-slate-900/50">
        <div className="container mx-auto">
          <div className="text-center mb-16 animate-on-scroll">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Ce que disent nos{" "}
              <span className="bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
                utilisateurs
              </span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Fatima Z.",
                role: "Vendeuse mode féminine",
                content:
                  "TJR a puissamment révolutionné ma boutique Instagram ! L'agent IA répond intelligemment même la nuit. Mes ventes ont explosé de 40% en 2 mois - redoutablement efficace !",
                rating: 5,
              },
              {
                name: "Ahmed M.",
                role: "Vendeur électronique",
                content:
                  "Enfin une solution marocaine qui comprend instantanément nos besoins ! Le dashboard est puissamment intuitif et le support français est redoutablement réactif.",
                rating: 5,
              },
              {
                name: "Khadija L.",
                role: "Vendeuse cosmétiques",
                content:
                  "Je gagne intelligemment 3h par jour ! L'interface WhatsApp intégrée est redoutablement géniale - tout est puissamment centralisé et simplifié.",
                rating: 5,
              },
            ].map((testimonial, index) => (
              <div key={index} className="animate-on-scroll">
                <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-600/50 h-full hover:scale-105 transition-transform duration-300 shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <p className="text-slate-300 mb-6 italic">"{testimonial.content}"</p>
                    <div>
                      <div className="font-semibold text-white">{testimonial.name}</div>
                      <div className="text-sm text-slate-400">{testimonial.role}</div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technologies Section */}
      <section className="py-16 px-4 border-t border-slate-600/50">
        <div className="container mx-auto">
          <div className="text-center mb-12 animate-on-scroll">
            <p className="text-slate-400 text-lg mb-8">Propulsé par les meilleures technologies</p>
          </div>

          {/* Animated Logo Carousel */}
          <div className="relative overflow-hidden">
            <div className="flex items-center space-x-16 animate-tech-carousel">
              {/* Google */}
              <div className="flex items-center space-x-3 opacity-60 hover:opacity-100 transition-all duration-300 cursor-pointer min-w-max hover:scale-110 transition-transform">
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-lg">
                  <svg className="w-7 h-7" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    />
                  </svg>
                </div>
                <span className="text-white font-medium text-lg">Google</span>
              </div>

              {/* OpenAI */}
              <div className="flex items-center space-x-3 opacity-60 hover:opacity-100 transition-all duration-300 cursor-pointer min-w-max hover:scale-110 transition-transform">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Bot className="w-7 h-7 text-white" />
                </div>
                <span className="text-white font-medium text-lg">OpenAI</span>
              </div>

              {/* WhatsApp */}
              <div className="flex items-center space-x-3 opacity-60 hover:opacity-100 transition-all duration-300 cursor-pointer min-w-max hover:scale-110 transition-transform">
                <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center shadow-lg">
                  <MessageCircle className="w-7 h-7 text-white" />
                </div>
                <span className="text-white font-medium text-lg">WhatsApp</span>
              </div>

              {/* VS Code */}
              <div className="flex items-center space-x-3 opacity-60 hover:opacity-100 transition-all duration-300 cursor-pointer min-w-max hover:scale-110 transition-transform">
                <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                  <span className="text-white font-bold text-sm">{"</>"}</span>
                </div>
                <span className="text-white font-medium text-lg">VS Code</span>
              </div>

              {/* GitHub */}
              <div className="flex items-center space-x-3 opacity-60 hover:opacity-100 transition-all duration-300 cursor-pointer min-w-max hover:scale-110 transition-transform">
                <div className="w-12 h-12 bg-slate-800 rounded-xl flex items-center justify-center border border-slate-600 shadow-lg">
                  <svg className="w-7 h-7 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" />
                  </svg>
                </div>
                <span className="text-white font-medium text-lg">GitHub</span>
              </div>

              {/* Duplicate for seamless loop */}
              <div className="flex items-center space-x-3 opacity-60 hover:opacity-100 transition-all duration-300 cursor-pointer min-w-max hover:scale-110 transition-transform">
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-lg">
                  <svg className="w-7 h-7" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    />
                  </svg>
                </div>
                <span className="text-white font-medium text-lg">Google</span>
              </div>

              <div className="flex items-center space-x-3 opacity-60 hover:opacity-100 transition-all duration-300 cursor-pointer min-w-max hover:scale-110 transition-transform">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Bot className="w-7 h-7 text-white" />
                </div>
                <span className="text-white font-medium text-lg">OpenAI</span>
              </div>

              <div className="flex items-center space-x-3 opacity-60 hover:opacity-100 transition-all duration-300 cursor-pointer min-w-max hover:scale-110 transition-transform">
                <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center shadow-lg">
                  <MessageCircle className="w-7 h-7 text-white" />
                </div>
                <span className="text-white font-medium text-lg">WhatsApp</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 px-4 border-t border-slate-600/50 bg-gradient-to-b from-slate-900 to-slate-800">
        <div className="container mx-auto text-center">
          <div className="max-w-4xl mx-auto animate-on-scroll">
            <h2 className="text-4xl md:text-6xl font-bold mb-8">
              Prêt à{" "}
              <span className="bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
                transformer puissamment
              </span>{" "}
              votre business ?
            </h2>
            <p className="text-xl md:text-2xl text-slate-300 mb-12">
              Rejoignez instantanément les centaines d'entrepreneurs marocains qui optimisent redoutablement leurs
              ventes Instagram avec TJR. Vendez mieux, plus vite, avec plus d'impact.
            </p>

            <div className="flex flex-col sm:flex-row gap-6 justify-center mb-12">
              <Link href="/auth/register">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 px-12 py-4 text-xl font-medium shadow-xl"
                >
                  <Zap className="mr-3 h-6 w-6" />
                  Commencer maintenant
                </Button>
              </Link>
              <Button
                size="lg"
                variant="outline"
                className="border-slate-500 text-white hover:bg-slate-700/50 px-12 py-4 text-xl font-medium"
              >
                <Play className="mr-3 h-6 w-6" />
                Voir la démo
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400 mb-2">✓</div>
                <div className="text-slate-300">Configuration en 5 minutes</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400 mb-2">✓</div>
                <div className="text-slate-300">Support technique inclus</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-400 mb-2">✓</div>
                <div className="text-slate-300">Résiliable à tout moment</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-600/50 bg-slate-900/80 backdrop-blur-sm py-16 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            {/* Logo & Description */}
            <div className="md:col-span-2">
              <Link href="/" className="flex items-center space-x-2 mb-6">
                <div className="bg-gradient-to-r from-green-500 to-blue-600 p-2 rounded-lg shadow-lg">
                  <MessageCircle className="h-6 w-6 text-white" />
                </div>
                <span className="text-2xl font-bold text-white">TJR</span>
              </Link>
              <p className="text-slate-400 mb-6 max-w-md">
                La plateforme SaaS marocaine qui transforme puissamment la vente Instagram. Optimisez instantanément vos
                ventes WhatsApp avec un agent IA redoutablement intelligent. Gérez vos commandes avec une simplicité
                déconcertante.
              </p>
              <div className="flex space-x-4">
                <Button
                  size="sm"
                  variant="outline"
                  className="border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700/50"
                >
                  <Mail className="h-4 w-4" />
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700/50"
                >
                  <MessageCircle className="h-4 w-4" />
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700/50"
                >
                  <Globe className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Produit */}
            <div>
              <h3 className="text-white font-semibold mb-4">Produit</h3>
              <ul className="space-y-3 text-slate-400">
                <li>
                  <a href="#fonctionnalites" className="hover:text-white transition-colors">
                    Fonctionnalités
                  </a>
                </li>
                <li>
                  <a href="#tarifs" className="hover:text-white transition-colors">
                    Tarifs
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Démo
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Mises à jour
                  </a>
                </li>
              </ul>
            </div>

            {/* Support */}
            <div>
              <h3 className="text-white font-semibold mb-4">Support</h3>
              <ul className="space-y-3 text-slate-400">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Centre d'aide
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Documentation
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Status
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="border-t border-slate-600/50 pt-8 flex flex-col md:flex-row justify-between items-center">
            <div className="text-slate-400 text-sm mb-4 md:mb-0">
              © 2024 TJR. Tous droits réservés. Développé avec ❤️ au Maroc.
            </div>
            <div className="flex space-x-6 text-sm text-slate-400">
              <a href="#" className="hover:text-white transition-colors">
                Politique de confidentialité
              </a>
              <a href="#" className="hover:text-white transition-colors">
                Conditions d'utilisation
              </a>
              <a href="#" className="hover:text-white transition-colors">
                Mentions légales
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
