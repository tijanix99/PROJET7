"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"

interface NavItem {
  name?: string
  title?: string
  href: string
  icon: LucideIcon
  description?: string
}

interface MainNavProps {
  items: NavItem[]
}

export function MainNav({ items }: MainNavProps) {
  const pathname = usePathname()

  return (
    <nav className="flex flex-col space-y-2 p-4">
      {items.map((item) => {
        // Logique de détection de page active corrigée
        const isActive = pathname === item.href
        const Icon = item.icon
        const title = item.name || item.title || ""

        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex items-center space-x-3 rounded-lg px-4 py-3 text-sm font-medium transition-all duration-200 hover:bg-white/10",
              isActive
                ? "bg-gradient-to-r from-green-500/20 to-blue-500/20 text-white border-l-4 border-green-400"
                : "text-gray-300 hover:text-white",
            )}
          >
            <Icon className="h-5 w-5" />
            <span>{title}</span>
          </Link>
        )
      })}
    </nav>
  )
}
