"use client"

import React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { MessageCircle, Eye, EyeOff, ArrowLeft, Star } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { signIn } from "@/lib/supabase-client"

export default function LoginForm() {
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [currentTestimonial, setCurrentTestimonial] = useState(0)
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  })

  const router = useRouter()
  const { toast } = useToast()

  // Témoignages qui défilent
  const testimonials = [
    {
      name: "Sarah M.",
      role: "Boutique Mode",
      content: "TJR a révolutionné ma façon de vendre sur Instagram. +300% de ventes !",
      avatar: "SM",
      rating: 5,
    },
    {
      name: "Ahmed K.",
      role: "Électronique",
      content: "L'agent IA répond à mes clients 24/7. Je peux enfin me concentrer sur mon business.",
      avatar: "AK",
      rating: 5,
    },
    {
      name: "Fatima L.",
      role: "Cosmétiques",
      content: "Interface intuitive et support client exceptionnel. Je recommande vivement !",
      avatar: "FL",
      rating: 5,
    },
  ]

  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.email || !formData.password) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      await signIn(formData.email, formData.password)

      toast({
        title: "Connexion réussie !",
        description: "Vous allez être redirigé vers le dashboard",
      })

      router.push("/dashboard")
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message || "Email ou mot de passe incorrect",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-700 text-white">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-pattern">
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-full blur-3xl"></div>
        <div className="absolute top-1/4 right-1/4 w-[400px] h-[400px] bg-gradient-to-r from-blue-500/10 to-green-500/10 rounded-full blur-2xl"></div>
      </div>

      <div className="relative z-10 grid lg:grid-cols-2 gap-8 items-center max-w-6xl mx-auto min-h-screen p-4">
        {/* Formulaire de connexion */}
        <div className="animate-fade-in">
          <Card className="w-full max-w-md mx-auto bg-slate-800/80 backdrop-blur-sm border-slate-600/50 shadow-2xl">
            <CardHeader className="text-center">
              <div className="flex items-center justify-center space-x-2 mb-4 animate-bounce-in">
                <div className="bg-gradient-to-r from-green-500 to-blue-600 p-2 rounded-lg shadow-lg">
                  <MessageCircle className="h-6 w-6 text-white" />
                </div>
                <span className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
                  TJR
                </span>
              </div>
              <CardTitle className="text-2xl text-white">Se connecter</CardTitle>
              <CardDescription className="text-slate-400">Accédez à votre dashboard de vente WhatsApp</CardDescription>
            </CardHeader>

            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2 animate-slide-in-left">
                  <Label htmlFor="email" className="text-slate-300">
                    Email
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="votre@email.com"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400 focus:border-green-500 transition-all duration-300 focus:scale-105"
                  />
                </div>

                <div className="space-y-2 animate-slide-in-left">
                  <Label htmlFor="password" className="text-slate-300">
                    Mot de passe
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="••••••••"
                      value={formData.password}
                      onChange={handleInputChange}
                      required
                      className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400 focus:border-green-500 transition-all duration-300 focus:scale-105"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent text-slate-400 hover:text-white"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                <div className="flex items-center justify-between animate-fade-in text-sm">
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="remember" className="rounded bg-slate-700 border-slate-600" />
                    <Label htmlFor="remember" className="text-slate-400">
                      Se souvenir de moi
                    </Label>
                  </div>
                  <Link href="/auth/forgot-password" className="text-green-400 hover:text-green-300 hover:underline">
                    Mot de passe oublié ?
                  </Link>
                </div>

                <div className="animate-slide-in-left">
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 transition-all duration-300 hover:scale-105 hover:shadow-xl text-white"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <div className="flex items-center">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        Connexion...
                      </div>
                    ) : (
                      "Se connecter"
                    )}
                  </Button>
                </div>

                {/* Bouton WhatsApp factice */}
                <div className="animate-slide-in-left">
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full border-green-500 text-green-400 hover:bg-green-500/20 transition-all duration-300 hover:scale-105"
                    disabled
                  >
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Connexion avec WhatsApp (Bientôt)
                  </Button>
                </div>
              </form>

              <div className="mt-6 text-center animate-fade-in">
                <p className="text-sm text-slate-400">
                  Pas encore de compte ?{" "}
                  <Link
                    href="/auth/register"
                    className="text-green-400 hover:text-green-300 hover:underline font-medium"
                  >
                    S'inscrire gratuitement
                  </Link>
                </p>
              </div>

              <div className="mt-4 animate-fade-in">
                <Link
                  href="/"
                  className="flex items-center justify-center text-sm text-slate-400 hover:text-green-400 transition-colors"
                >
                  <ArrowLeft className="h-4 w-4 mr-1" />
                  Retour à l'accueil
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Carousel de témoignages */}
        <div className="hidden lg:block animate-slide-in-right">
          <div className="relative h-96 overflow-hidden rounded-2xl">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className={`absolute inset-0 flex items-center justify-center p-8 transition-all duration-500 ${
                  index === currentTestimonial ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
                }`}
              >
                <Card className="w-full max-w-md bg-slate-800/80 backdrop-blur-sm border-slate-600/50 shadow-xl">
                  <CardContent className="p-8 text-center">
                    <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-xl mx-auto mb-4 shadow-lg">
                      {testimonial.avatar}
                    </div>

                    <div className="flex justify-center mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>

                    <blockquote className="text-lg italic text-slate-300 mb-4">"{testimonial.content}"</blockquote>

                    <div>
                      <p className="font-semibold text-white">{testimonial.name}</p>
                      <p className="text-sm text-slate-400">{testimonial.role}</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}

            {/* Indicateurs */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
              {testimonials.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all duration-300 hover:scale-125 ${
                    index === currentTestimonial ? "bg-green-500 w-8" : "bg-slate-600"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
