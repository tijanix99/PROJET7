"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  TrendingUp,
  Package,
  ShoppingCart,
  MessageSquare,
  DollarSign,
  Clock,
  AlertTriangle,
  Plus,
  Eye,
  ArrowUpRight,
} from "lucide-react"
import { getCurrentUser } from "@/lib/supabase-client"
import { getOrders, getProducts, getMessages, getUserProfile } from "@/lib/database"
import { useToast } from "@/hooks/use-toast"
import { formatMAD } from "@/lib/utils"
import Link from "next/link"

export default function DashboardContent() {
  const [stats, setStats] = useState({
    totalOrders: 0,
    totalProducts: 0,
    totalMessages: 0,
    totalRevenue: 0,
    pendingOrders: 0,
    lowStockProducts: 0,
    unreadMessages: 0,
    todayOrders: 0,
  })
  const [recentOrders, setRecentOrders] = useState([])
  const [recentMessages, setRecentMessages] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [userProfile, setUserProfile] = useState<any>(null)
  const { toast } = useToast()

  useEffect(() => {
    loadDashboardData()
  }, [])

  const loadDashboardData = async () => {
    try {
      setIsLoading(true)
      const user = await getCurrentUser()
      if (!user) return

      const [ordersData, productsData, messagesData, profileData] = await Promise.all([
        getOrders(user.id),
        getProducts(user.id),
        getMessages(user.id),
        getUserProfile(user.id),
      ])

      // Calculer les statistiques
      const totalRevenue = ordersData.reduce((sum: number, order: any) => sum + Number(order.total_amount), 0)
      const pendingOrders = ordersData.filter((order: any) => order.status === "pending").length
      const lowStockProducts = productsData.filter((product: any) => product.quantity < 10).length
      const unreadMessages = messagesData.filter((message: any) => !message.is_read).length

      const today = new Date().toDateString()
      const todayOrders = ordersData.filter((order: any) => new Date(order.created_at).toDateString() === today).length

      setStats({
        totalOrders: ordersData.length,
        totalProducts: productsData.length,
        totalMessages: messagesData.length,
        totalRevenue,
        pendingOrders,
        lowStockProducts,
        unreadMessages,
        todayOrders,
      })

      // Récupérer les commandes récentes (5 dernières)
      setRecentOrders(ordersData.slice(0, 5))

      // Récupérer les messages récents (5 derniers)
      setRecentMessages(messagesData.slice(0, 5))

      setUserProfile(profileData)
    } catch (error: any) {
      console.error("Erreur chargement dashboard:", error)
      toast({
        title: "Erreur",
        description: "Impossible de charger les données du dashboard",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">En attente</Badge>
      case "confirmed":
        return <Badge className="bg-lime-500/20 text-lime-400">Confirmée</Badge>
      case "shipped":
        return <Badge className="bg-purple-100 text-purple-800">Expédiée</Badge>
      case "delivered":
        return <Badge className="bg-green-100 text-green-800">Livrée</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-lime-500"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Tableau de bord</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Bienvenue {userProfile?.full_name || "dans votre espace admin"}
          </p>
        </div>
        <div className="flex gap-2">
          <Link href="/dashboard/orders">
            <Button className="bg-lime-500 hover:bg-lime-600">
              <Plus className="h-4 w-4 mr-2" />
              Nouvelle commande
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Commandes totales</p>
                <p className="text-2xl font-bold text-white">{stats.totalOrders}</p>
                <div className="flex items-center text-sm text-lime-400">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  {stats.todayOrders} aujourd'hui
                </div>
              </div>
              <ShoppingCart className="h-8 w-8 text-lime-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Chiffre d'affaires</p>
                <p className="text-2xl font-bold text-white">{formatMAD(stats.totalRevenue)}</p>
                <div className="flex items-center text-sm text-lime-400">
                  <ArrowUpRight className="h-4 w-4 mr-1" />
                  +12% ce mois
                </div>
              </div>
              <DollarSign className="h-8 w-8 text-lime-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Produits</p>
                <p className="text-2xl font-bold text-white">{stats.totalProducts}</p>
                <div className="flex items-center text-sm text-red-400">
                  <AlertTriangle className="h-4 w-4 mr-1" />
                  {stats.lowStockProducts} stock faible
                </div>
              </div>
              <Package className="h-8 w-8 text-lime-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Messages</p>
                <p className="text-2xl font-bold text-white">{stats.totalMessages}</p>
                <div className="flex items-center text-sm text-yellow-400">
                  <MessageSquare className="h-4 w-4 mr-1" />
                  {stats.unreadMessages} non lus
                </div>
              </div>
              <MessageSquare className="h-8 w-8 text-lime-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alerts */}
      {(stats.pendingOrders > 0 || stats.lowStockProducts > 0 || stats.unreadMessages > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {stats.pendingOrders > 0 && (
            <Card className="border-yellow-200 bg-yellow-50/10">
              <CardContent className="pt-6">
                <div className="flex items-center space-x-2">
                  <Clock className="h-5 w-5 text-yellow-400" />
                  <div>
                    <p className="text-sm font-medium text-white">Commandes en attente</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {stats.pendingOrders} commandes à traiter
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {stats.lowStockProducts > 0 && (
            <Card className="border-red-200 bg-red-50/10">
              <CardContent className="pt-6">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5 text-red-400" />
                  <div>
                    <p className="text-sm font-medium text-white">Stock faible</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {stats.lowStockProducts} produits à réapprovisionner
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {stats.unreadMessages > 0 && (
            <Card className="border-blue-200 bg-blue-50/10">
              <CardContent className="pt-6">
                <div className="flex items-center space-x-2">
                  <MessageSquare className="h-5 w-5 text-blue-400" />
                  <div>
                    <p className="text-sm font-medium text-white">Messages non lus</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{stats.unreadMessages} nouveaux messages</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-white">Commandes récentes</CardTitle>
              <CardDescription>Vos {recentOrders.length} dernières commandes</CardDescription>
            </div>
            <Link href="/dashboard/orders">
              <Button variant="outline" size="sm">
                <Eye className="h-4 w-4 mr-2" />
                Voir tout
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentOrders.length > 0 ? (
                recentOrders.map((order: any) => (
                  <div key={order.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="bg-lime-500/20 p-2 rounded-lg">
                        <ShoppingCart className="h-4 w-4 text-lime-400" />
                      </div>
                      <div>
                        <p className="font-medium text-white">{order.client_name}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {new Date(order.created_at).toLocaleDateString("fr-FR")}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-white">{formatMAD(Number(order.total_amount))}</p>
                      {getStatusBadge(order.status)}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <ShoppingCart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Aucune commande récente</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Messages */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-white">Messages récents</CardTitle>
              <CardDescription>Vos {recentMessages.length} derniers messages</CardDescription>
            </div>
            <Link href="/dashboard/messages">
              <Button variant="outline" size="sm">
                <Eye className="h-4 w-4 mr-2" />
                Voir tout
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentMessages.length > 0 ? (
                recentMessages.map((message: any) => (
                  <div key={message.id} className="flex items-center space-x-3 p-3 border rounded-lg">
                    <div className="bg-lime-500/20 p-2 rounded-lg">
                      <MessageSquare className="h-4 w-4 text-lime-400" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-white">{message.whatsapp_number}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400 truncate">{message.content}</p>
                      <p className="text-xs text-gray-500">{new Date(message.timestamp).toLocaleString("fr-FR")}</p>
                    </div>
                    {!message.is_read && <div className="w-2 h-2 bg-lime-500 rounded-full"></div>}
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Aucun message récent</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-white">Actions rapides</CardTitle>
          <CardDescription>Accédez rapidement aux fonctionnalités principales</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Link href="/dashboard/orders">
              <Button variant="outline" className="h-20 flex flex-col space-y-2 w-full">
                <Plus className="h-6 w-6 text-lime-400" />
                <span className="text-sm">Nouvelle commande</span>
              </Button>
            </Link>
            <Link href="/dashboard/products">
              <Button variant="outline" className="h-20 flex flex-col space-y-2 w-full">
                <Package className="h-6 w-6 text-lime-400" />
                <span className="text-sm">Ajouter produit</span>
              </Button>
            </Link>
            <Link href="/dashboard/messages">
              <Button variant="outline" className="h-20 flex flex-col space-y-2 w-full">
                <MessageSquare className="h-6 w-6 text-lime-400" />
                <span className="text-sm">Messages</span>
              </Button>
            </Link>
            <Link href="/dashboard/analytics">
              <Button variant="outline" className="h-20 flex flex-col space-y-2 w-full">
                <TrendingUp className="h-6 w-6 text-lime-400" />
                <span className="text-sm">Analytics</span>
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
