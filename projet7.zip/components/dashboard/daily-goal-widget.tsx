"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Target, TrendingUp, Edit3, Check, Trophy, Zap } from "lucide-react"
import { getCurrentUser } from "@/lib/supabase-client"
import { getDailyGoal, updateDailyGoal, getTodaySales } from "@/lib/database"
import { useToast } from "@/hooks/use-toast"

export default function DailyGoalWidget() {
  const [goal, setGoal] = useState(0)
  const [currentSales, setCurrentSales] = useState(0)
  const [isEditing, setIsEditing] = useState(false)
  const [newGoal, setNewGoal] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    loadDailyGoalData()
    // Actualiser toutes les 5 minutes
    const interval = setInterval(loadDailyGoalData, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  const loadDailyGoalData = async () => {
    try {
      const user = await getCurrentUser()
      if (!user) return

      const [goalData, salesData] = await Promise.all([getDailyGoal(user.id), getTodaySales(user.id)])

      setGoal(goalData?.daily_goal || 100) // Objectif par défaut : 100€
      setCurrentSales(salesData || 0)
    } catch (error) {
      console.error("Erreur objectif quotidien:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSaveGoal = async () => {
    try {
      const user = await getCurrentUser()
      if (!user) return

      const goalValue = Number.parseFloat(newGoal)
      if (isNaN(goalValue) || goalValue <= 0) {
        toast({
          title: "Erreur",
          description: "Veuillez entrer un objectif valide",
          variant: "destructive",
        })
        return
      }

      await updateDailyGoal(user.id, goalValue)
      setGoal(goalValue)
      setIsEditing(false)
      setNewGoal("")

      toast({
        title: "Objectif mis à jour",
        description: `Nouvel objectif quotidien : ${goalValue}€`,
      })
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour l'objectif",
        variant: "destructive",
      })
    }
  }

  const progressPercentage = goal > 0 ? Math.min((currentSales / goal) * 100, 100) : 0
  const isGoalReached = currentSales >= goal
  const remaining = Math.max(goal - currentSales, 0)

  const getMotivationMessage = () => {
    if (isGoalReached) {
      return "🎉 Objectif atteint ! Continuez sur cette lancée !"
    }
    if (progressPercentage >= 75) {
      return "🔥 Presque là ! Plus que quelques ventes !"
    }
    if (progressPercentage >= 50) {
      return "💪 Bon rythme ! Vous êtes à mi-chemin !"
    }
    if (progressPercentage >= 25) {
      return "🚀 C'est parti ! Continuez comme ça !"
    }
    return "⭐ Nouvelle journée, nouvelles opportunités !"
  }

  if (isLoading) {
    return (
      <Card className="backdrop-blur-md bg-white/70 dark:bg-gray-800/70 border-0 shadow-xl">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-8 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ scale: 1.02 }}
    >
      <Card className="backdrop-blur-md bg-white/70 dark:bg-gray-800/70 border-0 shadow-xl overflow-hidden relative">
        <motion.div
          className={`absolute inset-0 bg-gradient-to-br ${
            isGoalReached ? "from-green-400 to-emerald-600" : "from-blue-400 to-purple-600"
          } opacity-10`}
          animate={{ opacity: [0.1, 0.15, 0.1] }}
          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
        />

        <CardHeader className="pb-4 relative z-10">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center text-lg">
              <Target className="h-5 w-5 mr-2 text-blue-600" />
              Objectif du jour
            </CardTitle>
            <div className="flex items-center space-x-2">
              {isGoalReached && (
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", delay: 0.5 }}>
                  <Trophy className="h-5 w-5 text-yellow-500" />
                </motion.div>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setIsEditing(!isEditing)
                  setNewGoal(goal.toString())
                }}
              >
                <Edit3 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="relative z-10">
          {isEditing ? (
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Input
                  type="number"
                  placeholder="Objectif en €"
                  value={newGoal}
                  onChange={(e) => setNewGoal(e.target.value)}
                  className="flex-1"
                />
                <Button size="sm" onClick={handleSaveGoal}>
                  <Check className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold">{currentSales.toFixed(2)}€</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">sur {goal}€</div>
                </div>
                <Badge
                  variant={isGoalReached ? "default" : "secondary"}
                  className={
                    isGoalReached
                      ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                      : "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
                  }
                >
                  {Math.round(progressPercentage)}%
                </Badge>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Progression</span>
                  <span className="text-gray-600">{remaining.toFixed(2)}€ restants</span>
                </div>
                <Progress value={progressPercentage} className="h-3" />
              </div>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className={`p-3 rounded-lg border ${
                  isGoalReached
                    ? "bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800"
                    : "bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800"
                }`}
              >
                <div className="flex items-center space-x-2">
                  <Zap className="h-4 w-4 text-yellow-500" />
                  <p className="text-sm font-medium">{getMotivationMessage()}</p>
                </div>
              </motion.div>

              {/* Statistiques rapides */}
              <div className="grid grid-cols-2 gap-4 pt-2 border-t">
                <div className="text-center">
                  <div className="text-lg font-bold text-green-600">
                    {progressPercentage >= 100 ? "+" : ""}
                    {(progressPercentage - 100).toFixed(0)}%
                  </div>
                  <div className="text-xs text-gray-600">vs objectif</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-blue-600">
                    <TrendingUp className="h-4 w-4 inline mr-1" />
                    {Math.round(progressPercentage / 10)}
                  </div>
                  <div className="text-xs text-gray-600">score du jour</div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  )
}
