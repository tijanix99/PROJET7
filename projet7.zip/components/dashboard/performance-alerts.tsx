"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  X,
  Bell,
  Zap,
  MessageCircle,
  ShoppingCart,
} from "lucide-react"
import { getCurrentUser } from "@/lib/supabase-client"
import { getPerformanceAlerts, dismissAlert } from "@/lib/database"
import { useToast } from "@/hooks/use-toast"

interface Alert {
  id: string
  type: "success" | "warning" | "info" | "danger"
  title: string
  message: string
  icon: React.ReactNode
  timestamp: string
  dismissed: boolean
  actionable?: boolean
}

export default function PerformanceAlerts() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    loadPerformanceAlerts()
    // Actualiser toutes les 10 minutes
    const interval = setInterval(loadPerformanceAlerts, 10 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  const loadPerformanceAlerts = async () => {
    try {
      const user = await getCurrentUser()
      if (!user) return

      const alertsData = await getPerformanceAlerts(user.id)

      // Transformer les données en alertes avec icônes
      const formattedAlerts: Alert[] = alertsData.map((alert: any) => ({
        ...alert,
        icon: getAlertIcon(alert.type, alert.category),
      }))

      setAlerts(formattedAlerts.filter((alert) => !alert.dismissed))
    } catch (error) {
      console.error("Erreur alertes performance:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const getAlertIcon = (type: string, category?: string) => {
    switch (category) {
      case "sales":
        return <TrendingUp className="h-4 w-4" />
      case "orders":
        return <ShoppingCart className="h-4 w-4" />
      case "messages":
        return <MessageCircle className="h-4 w-4" />
      case "stock":
        return <AlertTriangle className="h-4 w-4" />
      default:
        switch (type) {
          case "success":
            return <CheckCircle className="h-4 w-4" />
          case "warning":
            return <AlertTriangle className="h-4 w-4" />
          case "danger":
            return <TrendingDown className="h-4 w-4" />
          default:
            return <Bell className="h-4 w-4" />
        }
    }
  }

  const getAlertColor = (type: string) => {
    switch (type) {
      case "success":
        return "from-green-500 to-emerald-600"
      case "warning":
        return "from-yellow-500 to-orange-600"
      case "danger":
        return "from-red-500 to-pink-600"
      default:
        return "from-blue-500 to-purple-600"
    }
  }

  const getAlertBgColor = (type: string) => {
    switch (type) {
      case "success":
        return "bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800"
      case "warning":
        return "bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800"
      case "danger":
        return "bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800"
      default:
        return "bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800"
    }
  }

  const handleDismissAlert = async (alertId: string) => {
    try {
      await dismissAlert(alertId)
      setAlerts(alerts.filter((alert) => alert.id !== alertId))
      toast({
        title: "Alerte masquée",
        description: "L'alerte a été supprimée de votre tableau de bord",
      })
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible de masquer l'alerte",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <Card className="backdrop-blur-md bg-white/70 dark:bg-gray-800/70 border-0 shadow-xl">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (alerts.length === 0) {
    return (
      <Card className="backdrop-blur-md bg-white/70 dark:bg-gray-800/70 border-0 shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center text-lg">
            <Zap className="h-5 w-5 mr-2 text-green-600" />
            Alertes Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Tout va bien ! Aucune alerte pour le moment.</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card className="backdrop-blur-md bg-white/70 dark:bg-gray-800/70 border-0 shadow-xl">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center text-lg">
              <Zap className="h-5 w-5 mr-2 text-blue-600" />
              Alertes Performance
            </CardTitle>
            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
              {alerts.length} nouvelle{alerts.length > 1 ? "s" : ""}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-4 max-h-96 overflow-y-auto">
          <AnimatePresence>
            {alerts.map((alert, index) => (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: index * 0.1 }}
                className={`p-4 rounded-xl border ${getAlertBgColor(alert.type)} relative overflow-hidden`}
              >
                <motion.div
                  className={`absolute inset-0 bg-gradient-to-r ${getAlertColor(alert.type)} opacity-5`}
                  animate={{ opacity: [0.05, 0.1, 0.05] }}
                  transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                />

                <div className="flex items-start justify-between relative z-10">
                  <div className="flex items-start space-x-3 flex-1">
                    <div className={`p-2 rounded-lg bg-gradient-to-r ${getAlertColor(alert.type)}`}>
                      <div className="text-white">{alert.icon}</div>
                    </div>

                    <div className="flex-1">
                      <h4 className="font-medium mb-1">{alert.title}</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{alert.message}</p>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-gray-500">
                          {new Date(alert.timestamp).toLocaleString("fr-FR")}
                        </span>
                        {alert.actionable && (
                          <Badge variant="outline" className="text-xs">
                            Action requise
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>

                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDismissAlert(alert.id)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </CardContent>
      </Card>
    </motion.div>
  )
}
