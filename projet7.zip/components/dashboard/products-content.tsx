"use client"

import { Plus, FileText } from "lucide-react"
import { useState, useEffect } from "react"

import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"

import type { Product } from "@/types"
import { getProducts, getUserProfile } from "@/lib/database"
import { getCurrentUser } from "@/lib/supabase-client"
import { ProductTable } from "./product-table"
import { AddProductDialog } from "./add-product-dialog"

// Import pour la génération de catalogue PDF
import { generateCatalogPDF } from "@/lib/export-utils"

export default function ProductsContent() {
  const [products, setProducts] = useState<Product[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [userProfile, setUserProfile] = useState<any>(null)

  const handleOpenAddDialog = () => setIsAddDialogOpen(true)
  const handleCloseAddDialog = () => setIsAddDialogOpen(false)

  // Charger les produits et le profil utilisateur
  const loadProducts = async () => {
    try {
      setIsLoading(true)

      // Simuler des données de test si pas d'utilisateur connecté
      const user = await getCurrentUser().catch(() => null)

      if (!user) {
        // Données de test pour la démonstration
        const testProducts: Product[] = [
          {
            id: "1",
            name: "T-shirt Premium",
            description: "T-shirt en coton bio de haute qualité",
            price: 150,
            quantity: 25,
            category: "Vêtements",
            image_url: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop",
            user_id: "demo",
            is_active: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          },
          {
            id: "2",
            name: "Sneakers Sport",
            description: "Chaussures de sport confortables",
            price: 450,
            quantity: 12,
            category: "Chaussures",
            image_url: "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop",
            user_id: "demo",
            is_active: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          },
          {
            id: "3",
            name: "Sac à Main Élégant",
            description: "Sac à main en cuir véritable",
            price: 320,
            quantity: 8,
            category: "Accessoires",
            image_url: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=400&fit=crop",
            user_id: "demo",
            is_active: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          },
        ]

        setProducts(testProducts)
        setUserProfile({
          shop_name: "Ma Boutique Demo",
          full_name: "Utilisateur Demo",
          email: "demo@example.com",
        })

        toast({
          title: "Mode Démonstration",
          description: "Données de test chargées. Connectez-vous pour vos vrais produits.",
        })
        return
      }

      const [productsData, profileData] = await Promise.all([getProducts(user.id), getUserProfile(user.id)])

      setProducts(productsData || [])
      setUserProfile(profileData)
    } catch (error: any) {
      console.error("Erreur chargement produits:", error)
      toast({
        title: "Erreur",
        description: "Impossible de charger les produits",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    loadProducts()
  }, [])

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Gestion des produits</h1>
          <p className="text-gray-600 dark:text-gray-400">Gérez votre catalogue de {products.length} produits</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            onClick={() => generateCatalogPDF(products, userProfile)}
            className="flex items-center gap-2"
          >
            <FileText className="h-4 w-4" />
            Générer Catalogue PDF
          </Button>
          <Button onClick={handleOpenAddDialog} className="bg-lime-500 hover:bg-lime-600">
            <Plus className="h-4 w-4 mr-2" />
            Nouveau produit
          </Button>
        </div>
      </div>

      <ProductTable products={products} isLoading={isLoading} refreshProducts={loadProducts} />
      <AddProductDialog open={isAddDialogOpen} onOpenChange={handleCloseAddDialog} refreshProducts={loadProducts} />
    </div>
  )
}
