"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Cloud, Sun, CloudRain, CloudSnow, Wind, Droplets } from "lucide-react"
import { getCurrentUser } from "@/lib/supabase-client"
import { getUserProfile } from "@/lib/database"

interface WeatherData {
  temperature: number
  condition: string
  humidity: number
  windSpeed: number
  city: string
  icon: string
}

export default function WeatherWidget() {
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [userCity, setUserCity] = useState("Paris")

  useEffect(() => {
    loadUserCityAndWeather()
  }, [])

  const loadUserCityAndWeather = async () => {
    try {
      const user = await getCurrentUser()
      if (user) {
        const profile = await getUserProfile(user.id)
        if (profile?.city) {
          setUserCity(profile.city)
        }
      }

      // Simulation de données météo (en production, utiliser une vraie API comme OpenWeatherMap)
      const mockWeatherData: WeatherData = {
        temperature: Math.floor(Math.random() * 25) + 10, // 10-35°C
        condition: ["Ensoleillé", "Nuageux", "Pluvieux", "Venteux"][Math.floor(Math.random() * 4)],
        humidity: Math.floor(Math.random() * 40) + 40, // 40-80%
        windSpeed: Math.floor(Math.random() * 20) + 5, // 5-25 km/h
        city: userCity,
        icon: "sun",
      }

      // Simuler un délai d'API
      setTimeout(() => {
        setWeather(mockWeatherData)
        setIsLoading(false)
      }, 1000)
    } catch (error) {
      console.error("Erreur météo:", error)
      setIsLoading(false)
    }
  }

  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case "ensoleillé":
        return <Sun className="h-8 w-8 text-yellow-500" />
      case "nuageux":
        return <Cloud className="h-8 w-8 text-gray-500" />
      case "pluvieux":
        return <CloudRain className="h-8 w-8 text-blue-500" />
      case "neigeux":
        return <CloudSnow className="h-8 w-8 text-blue-300" />
      default:
        return <Sun className="h-8 w-8 text-yellow-500" />
    }
  }

  const getWeatherColor = (condition: string) => {
    switch (condition.toLowerCase()) {
      case "ensoleillé":
        return "from-yellow-400 to-orange-500"
      case "nuageux":
        return "from-gray-400 to-gray-600"
      case "pluvieux":
        return "from-blue-400 to-blue-600"
      case "neigeux":
        return "from-blue-300 to-blue-500"
      default:
        return "from-yellow-400 to-orange-500"
    }
  }

  if (isLoading) {
    return (
      <Card className="backdrop-blur-md bg-white/70 dark:bg-gray-800/70 border-0 shadow-xl">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-8 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!weather) {
    return (
      <Card className="backdrop-blur-md bg-white/70 dark:bg-gray-800/70 border-0 shadow-xl">
        <CardContent className="p-6 text-center">
          <p className="text-gray-500">Météo indisponible</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      whileHover={{ scale: 1.02 }}
    >
      <Card className="backdrop-blur-md bg-white/70 dark:bg-gray-800/70 border-0 shadow-xl overflow-hidden relative">
        <motion.div
          className={`absolute inset-0 bg-gradient-to-br ${getWeatherColor(weather.condition)} opacity-10`}
          animate={{ opacity: [0.1, 0.2, 0.1] }}
          transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
        />

        <CardHeader className="pb-2 relative z-10">
          <CardTitle className="flex items-center justify-between text-lg">
            <span>Météo - {weather.city}</span>
            <Badge variant="outline" className="bg-white/50">
              Maintenant
            </Badge>
          </CardTitle>
        </CardHeader>

        <CardContent className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-4">
              <motion.div
                animate={{ rotate: weather.condition === "Ensoleillé" ? [0, 360] : 0 }}
                transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
              >
                {getWeatherIcon(weather.condition)}
              </motion.div>
              <div>
                <div className="text-3xl font-bold">{weather.temperature}°C</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">{weather.condition}</div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center space-x-2">
              <Droplets className="h-4 w-4 text-blue-500" />
              <span>{weather.humidity}% humidité</span>
            </div>
            <div className="flex items-center space-x-2">
              <Wind className="h-4 w-4 text-gray-500" />
              <span>{weather.windSpeed} km/h</span>
            </div>
          </div>

          {/* Conseil basé sur la météo */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800"
          >
            <p className="text-xs text-blue-700 dark:text-blue-300">
              💡{" "}
              {weather.condition === "Ensoleillé"
                ? "Parfait pour promouvoir vos produits d'été !"
                : weather.condition === "Pluvieux"
                  ? "Idéal pour vendre des parapluies et imperméables !"
                  : "Bonne journée pour les ventes en ligne !"}
            </p>
          </motion.div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
