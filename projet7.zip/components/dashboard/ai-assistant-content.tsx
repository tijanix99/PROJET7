"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Bot, Send, Brain, MessageSquare, Plus, Trash2 } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { getCurrentUser } from "@/lib/supabase-client"
import {
  getAITrainingData,
  createAIResponse,
  getUserSettings,
  updateUserSettings,
  deleteAIResponse,
} from "@/lib/database"
import { useToast } from "@/hooks/use-toast"

export default function AIAssistantContent() {
  const [aiResponses, setAiResponses] = useState([])
  const [userSettings, setUserSettings] = useState<any>(null)
  const [selectedStyle, setSelectedStyle] = useState("amical")
  const [isAIEnabled, setIsAIEnabled] = useState(true)
  const [testMessage, setTestMessage] = useState("")
  const [testResponse, setTestResponse] = useState("")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [newResponse, setNewResponse] = useState({
    question: "",
    answer: "",
    category: "",
  })
  const { toast } = useToast()

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      console.log("🔄 Chargement des données IA...")
      const user = await getCurrentUser()
      if (!user) {
        console.log("❌ Pas d'utilisateur connecté")
        return
      }

      console.log("👤 Utilisateur:", user.id)
      const [aiData, settings] = await Promise.all([getAITrainingData(user.id), getUserSettings(user.id)])

      console.log("📊 Données IA:", aiData)
      console.log("⚙️ Paramètres:", settings)

      setAiResponses(aiData || [])
      if (settings) {
        setUserSettings(settings)
        setSelectedStyle(settings.ia_style || "amical")
        setIsAIEnabled(settings.ia_enabled !== false)
      }
    } catch (error: any) {
      console.error("❌ Erreur chargement IA:", error)
      toast({
        title: "Erreur",
        description: "Impossible de charger les données de l'assistant IA",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleTestAI = () => {
    console.log("🧪 Test IA avec message:", testMessage)

    if (!testMessage.trim()) {
      toast({
        title: "Message vide",
        description: "Veuillez saisir un message pour tester l'IA",
        variant: "destructive",
      })
      return
    }

    // Recherche dans les réponses de la base de données
    const matchingResponse = aiResponses.find(
      (response: any) =>
        response.question.toLowerCase().includes(testMessage.toLowerCase()) ||
        testMessage.toLowerCase().includes(response.question.toLowerCase()),
    )

    if (matchingResponse) {
      console.log("✅ Réponse trouvée:", matchingResponse)
      setTestResponse(matchingResponse.answer)
      toast({
        title: "Réponse trouvée !",
        description: "L'IA a trouvé une réponse dans votre base de données",
      })
    } else {
      console.log("❌ Aucune réponse trouvée")
      setTestResponse(
        "Aucune réponse trouvée dans la base de données. Ajoutez des réponses personnalisées pour améliorer l'assistant IA.",
      )
      toast({
        title: "Aucune réponse",
        description: "Ajoutez plus de réponses pour améliorer l'IA",
        variant: "destructive",
      })
    }
  }

  const handleAddResponse = async () => {
    if (!newResponse.question.trim() || !newResponse.answer.trim()) {
      toast({
        title: "Champs requis",
        description: "Veuillez remplir au moins la question et la réponse",
        variant: "destructive",
      })
      return
    }

    try {
      console.log("➕ Ajout nouvelle réponse:", newResponse)
      setIsSaving(true)

      const user = await getCurrentUser()
      if (!user) {
        toast({
          title: "Erreur",
          description: "Utilisateur non connecté",
          variant: "destructive",
        })
        return
      }

      const responseData = {
        user_id: user.id,
        question: newResponse.question.trim(),
        answer: newResponse.answer.trim(),
        category: newResponse.category.trim() || "Général",
        is_active: true,
      }

      console.log("📝 Données à sauvegarder:", responseData)
      await createAIResponse(responseData)

      toast({
        title: "✅ Réponse ajoutée",
        description: "La réponse IA a été ajoutée à la base de données",
      })

      setIsAddDialogOpen(false)
      setNewResponse({ question: "", answer: "", category: "" })
      await loadData() // Recharger les données
    } catch (error: any) {
      console.error("❌ Erreur ajout réponse:", error)
      toast({
        title: "Erreur",
        description: "Impossible d'ajouter la réponse: " + error.message,
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleDeleteResponse = async (responseId: string) => {
    try {
      console.log("🗑️ Suppression réponse:", responseId)
      await deleteAIResponse(responseId)

      toast({
        title: "✅ Réponse supprimée",
        description: "La réponse a été supprimée de la base de données",
      })

      await loadData() // Recharger les données
    } catch (error: any) {
      console.error("❌ Erreur suppression:", error)
      toast({
        title: "Erreur",
        description: "Impossible de supprimer la réponse: " + error.message,
        variant: "destructive",
      })
    }
  }

  const handleSaveSettings = async () => {
    try {
      console.log("💾 Sauvegarde paramètres IA...")
      setIsSaving(true)

      const user = await getCurrentUser()
      if (!user) {
        toast({
          title: "Erreur",
          description: "Utilisateur non connecté",
          variant: "destructive",
        })
        return
      }

      const settingsData = {
        ia_style: selectedStyle,
        ia_enabled: isAIEnabled,
      }

      console.log("⚙️ Paramètres à sauvegarder:", settingsData)
      await updateUserSettings(user.id, settingsData)

      toast({
        title: "✅ Paramètres sauvegardés",
        description: "Les paramètres ont été mis à jour dans la base",
      })
    } catch (error: any) {
      console.error("❌ Erreur sauvegarde:", error)
      toast({
        title: "Erreur",
        description: "Impossible de sauvegarder: " + error.message,
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleAIToggle = (enabled: boolean) => {
    console.log("🔄 Toggle IA:", enabled)
    setIsAIEnabled(enabled)
    toast({
      title: enabled ? "IA Activée" : "IA Désactivée",
      description: `L'assistant IA est maintenant ${enabled ? "actif" : "inactif"}`,
    })
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-lime-400"></div>
        <span className="ml-2 text-white">Chargement...</span>
      </div>
    )
  }

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center text-white">
            <Bot className="h-6 w-6 mr-2 text-lime-400" />
            Assistant IA
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            {aiResponses.length} réponses configurées dans la base de données
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant={isAIEnabled ? "default" : "secondary"} className="bg-lime-500/20 text-lime-400">
            {isAIEnabled ? "Actif" : "Inactif"}
          </Badge>
          <Switch checked={isAIEnabled} onCheckedChange={handleAIToggle} />
        </div>
      </div>

      <Tabs defaultValue="chat" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 bg-gray-900 border border-gray-800">
          <TabsTrigger
            value="chat"
            className="text-gray-400 data-[state=active]:text-white data-[state=active]:bg-gray-800"
          >
            Test IA
          </TabsTrigger>
          <TabsTrigger
            value="responses"
            className="text-gray-400 data-[state=active]:text-white data-[state=active]:bg-gray-800"
          >
            Réponses DB
          </TabsTrigger>
          <TabsTrigger
            value="training"
            className="text-gray-400 data-[state=active]:text-white data-[state=active]:bg-gray-800"
          >
            Entraînement
          </TabsTrigger>
          <TabsTrigger
            value="settings"
            className="text-gray-400 data-[state=active]:text-white data-[state=active]:bg-gray-800"
          >
            Paramètres
          </TabsTrigger>
        </TabsList>

        {/* Chat Test Tab */}
        <TabsContent value="chat" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Test Chat */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-white">
                  <MessageSquare className="h-5 w-5 mr-2 text-lime-400" />
                  Test Assistant
                </CardTitle>
                <CardDescription>Testez avec les {aiResponses.length} réponses de votre base</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4 h-64 overflow-y-auto border rounded-lg p-4 bg-gray-50 dark:bg-gray-800">
                  {testResponse && (
                    <div className="space-y-2">
                      <div className="flex justify-end">
                        <div className="bg-lime-500 text-white px-3 py-2 rounded-lg max-w-xs">
                          <p className="text-sm">{testMessage}</p>
                        </div>
                      </div>
                      <div className="flex justify-start">
                        <div className="bg-white dark:bg-gray-700 border px-3 py-2 rounded-lg max-w-xs">
                          <p className="text-sm text-gray-900 dark:text-gray-100">{testResponse}</p>
                          <span className="text-xs text-gray-500">Depuis base Supabase</span>
                        </div>
                      </div>
                    </div>
                  )}
                  {!testResponse && (
                    <div className="flex items-center justify-center h-full text-gray-400">
                      Tapez un message pour tester l'IA avec vos données
                    </div>
                  )}
                </div>
                <div className="flex space-x-2">
                  <Input
                    placeholder="Tapez votre message de test..."
                    value={testMessage}
                    onChange={(e) => setTestMessage(e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === "Enter") {
                        handleTestAI()
                      }
                    }}
                  />
                  <Button
                    onClick={handleTestAI}
                    disabled={!testMessage.trim()}
                    className="bg-lime-500 hover:bg-lime-600 disabled:opacity-50"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Stats from Database */}
            <div className="space-y-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Réponses en base</p>
                      <p className="text-2xl font-bold text-gray-100">{aiResponses.length}</p>
                    </div>
                    <Brain className="h-8 w-8 text-lime-400" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Catégories</p>
                      <p className="text-2xl font-bold text-lime-400">
                        {new Set(aiResponses.map((r: any) => r.category).filter(Boolean)).size}
                      </p>
                    </div>
                    <div className="bg-lime-500/20 p-2 rounded-lg">
                      <div className="h-4 w-4 bg-lime-500 rounded-full"></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Responses Tab */}
        <TabsContent value="responses" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-white">Réponses de la base de données</CardTitle>
                <CardDescription>{aiResponses.length} réponses configurées dans Supabase</CardDescription>
              </div>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-lime-500 hover:bg-lime-600">
                    <Plus className="h-4 w-4 mr-2" />
                    Ajouter réponse
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Ajouter une réponse IA</DialogTitle>
                    <DialogDescription>Cette réponse sera sauvegardée dans Supabase</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="question" className="text-gray-100">
                        Question/Mot-clé *
                      </Label>
                      <Input
                        id="question"
                        value={newResponse.question}
                        onChange={(e) => setNewResponse({ ...newResponse, question: e.target.value })}
                        placeholder="Ex: prix, livraison, tailles..."
                      />
                    </div>
                    <div>
                      <Label htmlFor="answer" className="text-gray-100">
                        Réponse *
                      </Label>
                      <Textarea
                        id="answer"
                        value={newResponse.answer}
                        onChange={(e) => setNewResponse({ ...newResponse, answer: e.target.value })}
                        placeholder="La réponse que l'IA donnera..."
                        rows={3}
                      />
                    </div>
                    <div>
                      <Label htmlFor="category" className="text-gray-100">
                        Catégorie
                      </Label>
                      <Input
                        id="category"
                        value={newResponse.category}
                        onChange={(e) => setNewResponse({ ...newResponse, category: e.target.value })}
                        placeholder="Ex: Prix, Livraison, Produits..."
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsAddDialogOpen(false)} disabled={isSaving}>
                      Annuler
                    </Button>
                    <Button onClick={handleAddResponse} className="bg-lime-500 hover:bg-lime-600" disabled={isSaving}>
                      {isSaving ? "Sauvegarde..." : "Sauvegarder en base"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {aiResponses.length > 0 ? (
                  aiResponses.map((response: any) => (
                    <div key={response.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <Badge variant="outline">{response.category || "Sans catégorie"}</Badge>
                            <span className="text-xs text-gray-500">ID: {response.id.slice(0, 8)}</span>
                          </div>
                          <h4 className="font-medium mb-1 text-white">{response.question}</h4>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{response.answer}</p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteResponse(response.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <Brain className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-400 mb-2">Aucune réponse dans la base</p>
                    <p className="text-sm text-gray-500">Ajoutez des réponses pour entraîner votre IA</p>
                    <Button className="mt-4 bg-lime-500 hover:bg-lime-600" onClick={() => setIsAddDialogOpen(true)}>
                      <Plus className="h-4 w-4 mr-2" />
                      Première réponse
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Training Tab */}
        <TabsContent value="training" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-white">Entraînement de l'IA</CardTitle>
              <CardDescription>Toutes les données sont stockées dans Supabase</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 border rounded-lg">
                    <div className="text-2xl font-bold text-lime-400">{aiResponses.length}</div>
                    <p className="text-sm text-gray-600">Réponses totales</p>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <div className="text-2xl font-bold text-lime-400">
                      {new Set(aiResponses.map((r: any) => r.category).filter(Boolean)).size}
                    </div>
                    <p className="text-sm text-gray-600">Catégories</p>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <div className="text-2xl font-bold text-lime-400">
                      {aiResponses.filter((r: any) => r.is_active).length}
                    </div>
                    <p className="text-sm text-gray-600">Actives</p>
                  </div>
                </div>

                <div className="bg-lime-500/5 p-4 rounded-lg">
                  <h4 className="font-medium mb-2 text-white">💡 Conseils pour l'entraînement</h4>
                  <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                    <li>• Ajoutez des réponses pour les questions fréquentes</li>
                    <li>• Utilisez des catégories pour organiser vos réponses</li>
                    <li>• Testez régulièrement votre IA avec l'onglet "Test IA"</li>
                    <li>• Toutes les données sont sauvegardées en temps réel</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-white">Paramètres IA</CardTitle>
              <CardDescription>Configuration sauvegardée dans la base de données</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label className="text-base font-medium text-gray-100">Style de réponse</Label>
                  <Select value={selectedStyle} onValueChange={setSelectedStyle}>
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="formel">Formel</SelectItem>
                      <SelectItem value="amical">Amical</SelectItem>
                      <SelectItem value="enthousiaste">Enthousiaste</SelectItem>
                      <SelectItem value="concis">Concis</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium text-gray-100">Assistant IA activé</Label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Activer/désactiver les réponses automatiques
                    </p>
                  </div>
                  <Switch checked={isAIEnabled} onCheckedChange={handleAIToggle} />
                </div>

                <Button
                  onClick={handleSaveSettings}
                  className="w-full bg-lime-500 hover:bg-lime-600"
                  disabled={isSaving}
                >
                  {isSaving ? "Sauvegarde..." : "Sauvegarder dans Supabase"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
