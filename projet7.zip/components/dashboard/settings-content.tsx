"use client"
import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Settings, Bell, Shield, Palette, Smartphone, Eye, EyeOff, Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"
import { useToast } from "@/hooks/use-toast"

export default function SettingsContent() {
  const [showPassword, setShowPassword] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [notifications, setNotifications] = useState({
    email_summary: true,
    order_alerts: true,
    message_alerts: true,
    stock_alerts: true,
    promotional_emails: false,
  })
  const { theme, setTheme } = useTheme()
  const { toast } = useToast()

  // Fonction pour sauvegarder les notifications
  const handleSaveNotifications = async () => {
    try {
      setIsSaving(true)
      console.log("💾 Sauvegarde notifications:", notifications)

      // Simuler une sauvegarde
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "✅ Notifications sauvegardées",
        description: "Vos préférences de notification ont été mises à jour",
      })
    } catch (error) {
      console.error("❌ Erreur sauvegarde notifications:", error)
      toast({
        title: "Erreur",
        description: "Impossible de sauvegarder les notifications",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  // Fonction pour changer le thème
  const handleThemeChange = (newTheme: string) => {
    console.log("🎨 Changement de thème:", newTheme)
    setTheme(newTheme)
    toast({
      title: "Thème modifié",
      description: `Thème changé vers: ${newTheme === "light" ? "Clair" : newTheme === "dark" ? "Sombre" : "Système"}`,
    })
  }

  // Fonction pour changer le mot de passe
  const handlePasswordChange = async () => {
    try {
      setIsSaving(true)
      console.log("🔐 Changement de mot de passe...")

      // Simuler un changement de mot de passe
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "✅ Mot de passe modifié",
        description: "Votre mot de passe a été mis à jour avec succès",
      })
    } catch (error) {
      console.error("❌ Erreur changement mot de passe:", error)
      toast({
        title: "Erreur",
        description: "Impossible de changer le mot de passe",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  // Fonction pour toggle les notifications
  const handleNotificationToggle = (key: string, value: boolean) => {
    console.log(`🔔 Toggle notification ${key}:`, value)
    setNotifications((prev) => ({
      ...prev,
      [key]: value,
    }))

    toast({
      title: value ? "Notification activée" : "Notification désactivée",
      description: `${key.replace("_", " ")} ${value ? "activé" : "désactivé"}`,
    })
  }

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold flex items-center text-white">
          <Settings className="h-6 w-6 mr-2 text-lime-400" />
          Paramètres
        </h1>
        <p className="text-gray-600 dark:text-gray-400">Gérez vos préférences et paramètres de compte</p>
      </div>

      <Tabs defaultValue="notifications" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 bg-gray-900 border border-gray-800">
          <TabsTrigger
            value="notifications"
            className="text-gray-400 data-[state=active]:text-white data-[state=active]:bg-gray-800"
          >
            Notifications
          </TabsTrigger>
          <TabsTrigger
            value="appearance"
            className="text-gray-400 data-[state=active]:text-white data-[state=active]:bg-gray-800"
          >
            Apparence
          </TabsTrigger>
          <TabsTrigger
            value="security"
            className="text-gray-400 data-[state=active]:text-white data-[state=active]:bg-gray-800"
          >
            Sécurité
          </TabsTrigger>
          <TabsTrigger
            value="integrations"
            className="text-gray-400 data-[state=active]:text-white data-[state=active]:bg-gray-800"
          >
            Intégrations
          </TabsTrigger>
        </TabsList>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <Bell className="h-5 w-5 mr-2 text-lime-400" />
                Préférences de notification
              </CardTitle>
              <CardDescription>Choisissez comment vous souhaitez être notifié</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="emailSummary" className="text-gray-100">
                      Résumé quotidien par email
                    </Label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Recevez un résumé de vos ventes et messages chaque jour
                    </p>
                  </div>
                  <Switch
                    id="emailSummary"
                    checked={notifications.email_summary}
                    onCheckedChange={(checked) => handleNotificationToggle("email_summary", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="orderAlerts" className="text-gray-100">
                      Alertes de commandes
                    </Label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Notifications pour les nouvelles commandes
                    </p>
                  </div>
                  <Switch
                    id="orderAlerts"
                    checked={notifications.order_alerts}
                    onCheckedChange={(checked) => handleNotificationToggle("order_alerts", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="messageAlerts" className="text-gray-100">
                      Alertes de messages
                    </Label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Notifications pour les nouveaux messages WhatsApp
                    </p>
                  </div>
                  <Switch
                    id="messageAlerts"
                    checked={notifications.message_alerts}
                    onCheckedChange={(checked) => handleNotificationToggle("message_alerts", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="stockAlerts" className="text-gray-100">
                      Alertes de stock
                    </Label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Notifications quand un produit est en rupture
                    </p>
                  </div>
                  <Switch
                    id="stockAlerts"
                    checked={notifications.stock_alerts}
                    onCheckedChange={(checked) => handleNotificationToggle("stock_alerts", checked)}
                  />
                </div>
              </div>

              <Button
                onClick={handleSaveNotifications}
                className="w-full bg-lime-500 hover:bg-lime-600"
                disabled={isSaving}
              >
                {isSaving ? "Sauvegarde..." : "Sauvegarder les notifications"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Appearance Tab */}
        <TabsContent value="appearance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <Palette className="h-5 w-5 mr-2 text-lime-400" />
                Apparence
              </CardTitle>
              <CardDescription>Personnalisez l'apparence de votre interface</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label className="text-base font-medium text-gray-100">Thème</Label>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">Choisissez votre thème préféré</p>
                  <div className="grid grid-cols-3 gap-4">
                    <div
                      className={`border-2 rounded-lg p-4 cursor-pointer transition-colors hover:bg-gray-800 ${
                        theme === "light" ? "border-lime-500 bg-lime-500/10" : "border-gray-700"
                      }`}
                      onClick={() => handleThemeChange("light")}
                    >
                      <div className="flex items-center space-x-2">
                        <Sun className="h-5 w-5 text-lime-400" />
                        <span className="font-medium text-gray-100">Clair</span>
                      </div>
                    </div>
                    <div
                      className={`border-2 rounded-lg p-4 cursor-pointer transition-colors hover:bg-gray-800 ${
                        theme === "dark" ? "border-lime-500 bg-lime-500/10" : "border-gray-700"
                      }`}
                      onClick={() => handleThemeChange("dark")}
                    >
                      <div className="flex items-center space-x-2">
                        <Moon className="h-5 w-5 text-lime-400" />
                        <span className="font-medium text-gray-100">Sombre</span>
                      </div>
                    </div>
                    <div
                      className={`border-2 rounded-lg p-4 cursor-pointer transition-colors hover:bg-gray-800 ${
                        theme === "system" ? "border-lime-500 bg-lime-500/10" : "border-gray-700"
                      }`}
                      onClick={() => handleThemeChange("system")}
                    >
                      <div className="flex items-center space-x-2">
                        <Settings className="h-5 w-5 text-lime-400" />
                        <span className="font-medium text-gray-100">Système</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-lime-500/5 p-4 rounded-lg">
                  <h4 className="font-medium mb-2 text-white">ℹ️ Information</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Le thème actuel est: <span className="text-lime-400 font-medium">{theme || "system"}</span>
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <Shield className="h-5 w-5 mr-2 text-lime-400" />
                Sécurité
              </CardTitle>
              <CardDescription>Gérez la sécurité de votre compte</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="current-password" className="text-gray-100">
                    Mot de passe actuel
                  </Label>
                  <div className="relative">
                    <Input
                      id="current-password"
                      type={showPassword ? "text" : "password"}
                      placeholder="••••••••"
                      className="bg-gray-900 border-gray-700 text-white"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => {
                        console.log("👁️ Toggle password visibility")
                        setShowPassword(!showPassword)
                      }}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4 text-gray-400" />
                      ) : (
                        <Eye className="h-4 w-4 text-gray-400" />
                      )}
                    </Button>
                  </div>
                </div>

                <div>
                  <Label htmlFor="new-password" className="text-gray-100">
                    Nouveau mot de passe
                  </Label>
                  <Input
                    id="new-password"
                    type="password"
                    placeholder="••••••••"
                    className="bg-gray-900 border-gray-700 text-white"
                  />
                </div>

                <Button onClick={handlePasswordChange} className="bg-lime-500 hover:bg-lime-600" disabled={isSaving}>
                  {isSaving ? "Changement..." : "Changer le mot de passe"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Integrations Tab */}
        <TabsContent value="integrations" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <Smartphone className="h-5 w-5 mr-2 text-lime-400" />
                Intégrations
              </CardTitle>
              <CardDescription>Gérez vos intégrations et API</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border border-gray-700 rounded-lg hover:bg-gray-800 transition-colors">
                  <div>
                    <h4 className="font-medium text-gray-100">WhatsApp Business</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Connectez votre compte WhatsApp Business</p>
                  </div>
                  <Badge className="bg-lime-500/20 text-lime-400 border-lime-500/30">Connecté</Badge>
                </div>

                <div className="flex items-center justify-between p-4 border border-gray-700 rounded-lg hover:bg-gray-800 transition-colors">
                  <div>
                    <h4 className="font-medium text-gray-100">API Keys</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Gérez vos clés API pour les intégrations</p>
                  </div>
                  <Button
                    variant="outline"
                    className="border-gray-700 text-white hover:bg-gray-800"
                    onClick={() => {
                      console.log("🔑 Gestion API Keys")
                      toast({
                        title: "API Keys",
                        description: "Fonctionnalité en développement",
                      })
                    }}
                  >
                    Gérer
                  </Button>
                </div>

                <div className="bg-lime-500/5 p-4 rounded-lg">
                  <h4 className="font-medium mb-2 text-white">🔗 Intégrations disponibles</h4>
                  <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                    <li>• WhatsApp Business API</li>
                    <li>• Notifications par email</li>
                    <li>• Webhooks personnalisés</li>
                    <li>• API REST complète</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
