"use client"

import type React from "react"
import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  User,
  Settings,
  LogOut,
  Home,
  BarChart3,
  Package,
  ShoppingCart,
  MessageSquare,
  Bot,
  Cog,
  Search,
  Bell,
} from "lucide-react"
import { supabase, getCurrentUser } from "@/lib/supabase-client"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface DashboardLayoutProps {
  children: React.ReactNode
}

interface UserProfile {
  id: string
  full_name: string
  email: string
  profile_image?: string
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [mounted, setMounted] = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    setMounted(true)
    const fetchUserProfile = async () => {
      try {
        const user = await getCurrentUser()
        if (user) {
          const { data: profile, error } = await supabase
            .from("users")
            .select("id, full_name, email, profile_image")
            .eq("id", user.id)
            .single()

          if (error) {
            setUserProfile({
              id: user.id,
              full_name: user.user_metadata?.full_name || "Utilisateur",
              email: user.email || "",
              profile_image: user.user_metadata?.avatar_url,
            })
          } else {
            setUserProfile(profile)
          }
        }
      } catch (error) {
        console.error("Erreur:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchUserProfile()
  }, [])

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((word) => word.charAt(0))
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element
      if (!target.closest(".avatar-menu")) {
        setIsMenuOpen(false)
      }
    }

    if (isMenuOpen) {
      document.addEventListener("click", handleClickOutside)
    }

    return () => {
      document.removeEventListener("click", handleClickOutside)
    }
  }, [isMenuOpen])

  const navItems = [
    { href: "/dashboard", icon: Home, label: "Accueil" },
    { href: "/dashboard/orders", icon: ShoppingCart, label: "Commandes" },
    { href: "/dashboard/products", icon: Package, label: "Produits" },
    { href: "/dashboard/analytics", icon: BarChart3, label: "Analytics" },
    { href: "/dashboard/messages", icon: MessageSquare, label: "Messages" },
    { href: "/dashboard/ai-assistant", icon: Bot, label: "Assistant IA" },
    { href: "/dashboard/settings", icon: Cog, label: "Paramètres" },
  ]

  if (!mounted) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-lime-500"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Background Effects Animés VERT */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/4 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-lime-500/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-lime-500/3 rounded-full blur-2xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/4 right-1/2 w-[300px] h-[300px] bg-lime-500/5 rounded-full blur-xl animate-bounce delay-2000"></div>
      </div>

      {/* Sidebar NOIR avec bordures VERTES */}
      <div className="fixed inset-y-0 left-0 z-50 w-64 bg-black border-r border-lime-500/20 animate-slide-in-left">
        {/* Logo avec animation bounce */}
        <div className="flex items-center h-16 px-6 border-b border-lime-500/20 animate-fade-in">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-lime-500 rounded-lg flex items-center justify-center animate-bounce-in shadow-lg shadow-lime-500/50">
              <span className="text-black font-bold text-sm">TJR</span>
            </div>
            <span className="text-white font-semibold text-lg animate-slide-in-right">TJR Admin</span>
          </div>
        </div>

        {/* Navigation avec animations décalées */}
        <nav className="mt-6 px-3">
          {navItems.map((item, index) => {
            const Icon = item.icon
            const isActive = pathname === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`group flex items-center px-3 py-2 text-sm font-medium rounded-lg mb-1 transition-all duration-300 transform hover:scale-105 hover:shadow-lg animate-slide-in-left ${
                  isActive
                    ? "bg-lime-500/20 text-lime-400 border-l-2 border-lime-500 shadow-lg shadow-lime-500/20"
                    : "text-white hover:text-lime-400 hover:bg-lime-500/10"
                }`}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <Icon
                  className={`mr-3 h-5 w-5 transition-all duration-300 ${isActive ? "animate-pulse text-lime-400" : "group-hover:scale-110 group-hover:text-lime-400"}`}
                />
                {item.label}
              </Link>
            )
          })}
        </nav>

        {/* User Profile in Sidebar avec animation */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-lime-500/20 animate-fade-in-up">
          <div className="flex items-center space-x-3 p-2 rounded-lg hover:bg-lime-500/10 transition-all duration-300 hover:scale-105">
            <Avatar className="h-8 w-8 border border-lime-500 shadow-lg shadow-lime-500/20 animate-bounce-in">
              <AvatarImage
                src={userProfile?.profile_image || "/placeholder.svg?height=32&width=32"}
                alt="Photo de profil"
              />
              <AvatarFallback className="bg-lime-500 text-black text-sm font-medium">
                {loading ? "..." : getInitials(userProfile?.full_name || "User")}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate animate-slide-in-right">
                {loading ? "Chargement..." : userProfile?.full_name || "Utilisateur"}
              </p>
              <p className="text-xs text-white truncate animate-slide-in-right delay-100">
                {loading ? "..." : userProfile?.email || "email@example.com"}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="pl-64">
        {/* Top Header NOIR avec bordures VERTES */}
        <header className="bg-black border-b border-lime-500/20 h-16 animate-slide-in-down">
          <div className="flex items-center justify-between h-full px-6">
            {/* Search Bar avec animation */}
            <div className="flex-1 max-w-lg animate-slide-in-left">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-lime-400 animate-pulse" />
                <input
                  type="text"
                  placeholder="Rechercher..."
                  className="w-full pl-10 pr-4 py-2 bg-black border border-lime-500/30 rounded-lg text-white placeholder-white focus:ring-2 focus:ring-lime-500 focus:border-lime-500 transition-all duration-300 focus:scale-105 focus:shadow-lg focus:shadow-lime-500/20"
                />
              </div>
            </div>

            {/* Right Side avec animations */}
            <div className="flex items-center space-x-4 animate-slide-in-right">
              {/* Notifications avec animation */}
              <button className="p-2 text-white hover:text-lime-400 relative transition-all duration-300 hover:scale-110 hover:bg-lime-500/10 rounded-lg">
                <Bell className="h-5 w-5 animate-pulse" />
                <span className="absolute -top-1 -right-1 h-4 w-4 bg-lime-500 rounded-full text-xs text-black flex items-center justify-center font-medium animate-bounce shadow-lg shadow-lime-500/50">
                  3
                </span>
              </button>

              {/* User Menu avec animations */}
              <div className="relative avatar-menu">
                <button
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="flex items-center space-x-3 p-2 rounded-lg hover:bg-lime-500/10 transition-all duration-300 hover:scale-105 hover:shadow-lg"
                >
                  <Avatar className="h-8 w-8 border-2 border-lime-500 shadow-lg shadow-lime-500/20 animate-bounce-in">
                    <AvatarImage
                      src={userProfile?.profile_image || "/placeholder.svg?height=32&width=32"}
                      alt="Photo de profil"
                    />
                    <AvatarFallback className="bg-lime-500 text-black text-sm font-medium">
                      {loading ? "..." : getInitials(userProfile?.full_name || "User")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden md:block text-left">
                    <p className="text-sm font-medium text-white animate-slide-in-right">
                      {loading ? "Chargement..." : userProfile?.full_name || "Utilisateur"}
                    </p>
                    <p className="text-xs text-white animate-slide-in-right delay-100">Admin</p>
                  </div>
                </button>

                {/* Dropdown Menu avec animations */}
                {isMenuOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-black border border-lime-500/30 rounded-lg shadow-2xl z-50 animate-fade-in-up">
                    <div className="p-4 border-b border-lime-500/20 animate-slide-in-down">
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-10 w-10 border border-lime-500 shadow-lg shadow-lime-500/20">
                          <AvatarImage
                            src={userProfile?.profile_image || "/placeholder.svg?height=40&width=40"}
                            alt="Photo de profil"
                          />
                          <AvatarFallback className="bg-lime-500 text-black font-medium">
                            {getInitials(userProfile?.full_name || "User")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-white animate-slide-in-right">
                            {loading ? "Chargement..." : userProfile?.full_name || "Utilisateur"}
                          </p>
                          <p className="text-sm text-white animate-slide-in-right delay-100">
                            {loading ? "..." : userProfile?.email || "email@example.com"}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="py-2">
                      <Link
                        href="/dashboard/profile"
                        className="flex items-center px-4 py-2 text-sm text-white hover:text-lime-400 hover:bg-lime-500/10 transition-all duration-300 hover:scale-105 animate-slide-in-left"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <User className="mr-3 h-4 w-4 text-lime-400" />
                        Mon Profil
                      </Link>
                      <Link
                        href="/dashboard/settings"
                        className="flex items-center px-4 py-2 text-sm text-white hover:text-lime-400 hover:bg-lime-500/10 transition-all duration-300 hover:scale-105 animate-slide-in-left delay-100"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <Settings className="mr-3 h-4 w-4 text-lime-400" />
                        Paramètres
                      </Link>
                      <div className="border-t border-lime-500/20 my-2"></div>
                      <Link
                        href="/auth/login"
                        className="flex items-center px-4 py-2 text-sm text-white hover:text-red-400 hover:bg-red-500/10 transition-all duration-300 hover:scale-105 animate-slide-in-left delay-200"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <LogOut className="mr-3 h-4 w-4 text-red-400" />
                        Déconnexion
                      </Link>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Page Content avec animation */}
        <main className="text-white">
          <div className="animate-fade-in-up">{children}</div>
        </main>
      </div>
    </div>
  )
}
