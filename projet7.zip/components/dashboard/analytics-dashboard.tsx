"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  LineChart,
  Line,
} from "recharts"
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  ShoppingCart,
  Users,
  Target,
  AlertTriangle,
  Lightbulb,
  MapPin,
} from "lucide-react"

// Données simulées pour les graphiques
const revenueData = [
  { date: "01/01", revenus: 12000, commandes: 45 },
  { date: "02/01", revenus: 15000, commandes: 52 },
  { date: "03/01", revenus: 18000, commandes: 61 },
  { date: "04/01", revenus: 14000, commandes: 48 },
  { date: "05/01", revenus: 22000, commandes: 73 },
  { date: "06/01", revenus: 25000, commandes: 82 },
  { date: "07/01", revenus: 28000, commandes: 95 },
]

const orderStatusData = [
  { name: "Livrées", value: 65, color: "#10b981" },
  { name: "En cours", value: 25, color: "#f59e0b" },
  { name: "Annulées", value: 10, color: "#ef4444" },
]

const topProductsData = [
  { name: "Robe Été", revenus: 15000, ventes: 120 },
  { name: "Sneakers", revenus: 12000, ventes: 80 },
  { name: "Sac à Main", revenus: 10000, ventes: 95 },
  { name: "Montre", revenus: 8000, ventes: 40 },
  { name: "Parfum", revenus: 6000, ventes: 60 },
]

const cityData = [
  { city: "Casablanca", orders: 145, revenue: 45000, percentage: 35 },
  { city: "Rabat", orders: 98, revenue: 32000, percentage: 25 },
  { city: "Fès", orders: 76, revenue: 24000, percentage: 18 },
  { city: "Marrakech", orders: 65, revenue: 20000, percentage: 15 },
  { city: "Tanger", orders: 45, revenue: 15000, percentage: 12 },
  { city: "Agadir", orders: 32, revenue: 10000, percentage: 8 },
]

const COLORS = ["#84cc16", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6", "#6B7280"]

export function AnalyticsDashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState("7j")

  const kpiData = [
    {
      title: "Revenus Total",
      value: "125,430 MAD",
      change: "+12.5%",
      trend: "up",
      icon: DollarSign,
      color: "text-green-600",
    },
    {
      title: "Commandes",
      value: "1,247",
      change: "+8.2%",
      trend: "up",
      icon: ShoppingCart,
      color: "text-lime-500",
    },
    {
      title: "Panier Moyen",
      value: "185 MAD",
      change: "+5.1%",
      trend: "up",
      icon: Users,
      color: "text-purple-600",
    },
    {
      title: "Taux Conversion",
      value: "3.2%",
      change: "-0.5%",
      trend: "down",
      icon: Target,
      color: "text-orange-600",
    },
  ]

  const alerts = [
    {
      type: "warning",
      title: "Stock Faible",
      message: "5 produits ont un stock inférieur à 10 unités",
      action: "Voir les produits",
    },
    {
      type: "info",
      title: "Pic de Commandes",
      message: "25% d'augmentation des commandes cette semaine",
      action: "Analyser",
    },
    {
      type: "success",
      title: "Objectif Atteint",
      message: "Objectif mensuel de revenus dépassé de 15%",
      action: "Célébrer",
    },
  ]

  const insights = [
    {
      icon: Lightbulb,
      title: "Opportunité Géographique",
      description: "Casablanca représente 35% de vos ventes. Considérez une expansion à Salé.",
      priority: "high",
    },
    {
      icon: TrendingUp,
      title: "Produit Tendance",
      description: "Les robes d'été ont 40% de croissance. Augmentez le stock.",
      priority: "medium",
    },
    {
      icon: Users,
      title: "Fidélisation Client",
      description: "30% de vos clients sont récurrents. Lancez un programme de fidélité.",
      priority: "medium",
    },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white">Analytics Dashboard</h1>
          <p className="text-gray-400">Analysez vos performances business</p>
        </div>
        <div className="flex gap-2">
          {["7j", "30j", "90j"].map((period) => (
            <Button
              key={period}
              variant={selectedPeriod === period ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedPeriod(period)}
              className={selectedPeriod === period ? "bg-lime-500" : "border-gray-600 text-gray-300 hover:text-white"}
            >
              {period}
            </Button>
          ))}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiData.map((kpi, index) => (
          <Card key={index} className="bg-black border-gray-900">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-400">{kpi.title}</p>
                  <p className="text-2xl font-bold text-white">{kpi.value}</p>
                  <div className="flex items-center mt-2">
                    {kpi.trend === "up" ? (
                      <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                    )}
                    <span className={`text-sm font-medium ${kpi.trend === "up" ? "text-green-500" : "text-red-500"}`}>
                      {kpi.change}
                    </span>
                  </div>
                </div>
                <div className={`p-3 rounded-full bg-slate-700/50`}>
                  <kpi.icon className={`h-6 w-6 ${kpi.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Analytics */}
      <Tabs defaultValue="revenue" className="space-y-6">
        <TabsList className="bg-black border-gray-900">
          <TabsTrigger value="revenue" className="data-[state=active]:bg-lime-500">
            Revenus
          </TabsTrigger>
          <TabsTrigger value="orders" className="data-[state=active]:bg-lime-500">
            Commandes
          </TabsTrigger>
          <TabsTrigger value="products" className="data-[state=active]:bg-lime-500">
            Produits
          </TabsTrigger>
          <TabsTrigger value="geography" className="data-[state=active]:bg-lime-500">
            Géographie
          </TabsTrigger>
          <TabsTrigger value="insights" className="data-[state=active]:bg-lime-500">
            Insights
          </TabsTrigger>
        </TabsList>

        {/* Revenue Tab */}
        <TabsContent value="revenue">
          <Card className="bg-black border-gray-900">
            <CardHeader>
              <CardTitle className="text-white">Évolution des Revenus</CardTitle>
              <CardDescription className="text-gray-400">Revenus quotidiens sur les {selectedPeriod}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={revenueData}>
                    <defs>
                      <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="date" stroke="#9ca3af" />
                    <YAxis stroke="#9ca3af" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#1f2937",
                        border: "1px solid #374151",
                        borderRadius: "8px",
                        color: "#fff",
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="revenus"
                      stroke="#10b981"
                      strokeWidth={2}
                      fill="url(#revenueGradient)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Orders Tab */}
        <TabsContent value="orders">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-black border-gray-900">
              <CardHeader>
                <CardTitle className="text-white">Statut des Commandes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={orderStatusData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {orderStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1f2937",
                          border: "1px solid #374151",
                          borderRadius: "8px",
                          color: "#fff",
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-4 mt-4">
                  {orderStatusData.map((item, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-sm text-gray-300">{item.name}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black border-gray-900">
              <CardHeader>
                <CardTitle className="text-white">Évolution Commandes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={revenueData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="date" stroke="#9ca3af" />
                      <YAxis stroke="#9ca3af" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1f2937",
                          border: "1px solid #374151",
                          borderRadius: "8px",
                          color: "#fff",
                        }}
                      />
                      <Line
                        type="monotone"
                        dataKey="commandes"
                        stroke="#84cc16"
                        strokeWidth={3}
                        dot={{ fill: "#84cc16", strokeWidth: 2, r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Products Tab */}
        <TabsContent value="products">
          <Card className="bg-black border-gray-900">
            <CardHeader>
              <CardTitle className="text-white">Top Produits par Revenus</CardTitle>
              <CardDescription className="text-gray-400">Vos produits les plus performants</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={topProductsData} layout="horizontal">
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis type="number" stroke="#9ca3af" />
                    <YAxis dataKey="name" type="category" stroke="#9ca3af" width={100} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#1f2937",
                        border: "1px solid #374151",
                        borderRadius: "8px",
                        color: "#fff",
                      }}
                    />
                    <Bar dataKey="revenus" fill="#10b981" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Geography Tab */}
        <TabsContent value="geography">
          <Card className="bg-black border-gray-900">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Performance par Ville
              </CardTitle>
              <CardDescription className="text-gray-400">
                Répartition géographique de vos ventes au Maroc
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {cityData.map((city, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <div className="w-3 h-3 rounded-full bg-gradient-to-r from-green-500 to-lime-500" />
                        <span className="font-medium text-white">{city.city}</span>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium text-white">{city.revenue.toLocaleString()} MAD</div>
                        <div className="text-xs text-gray-400">{city.orders} commandes</div>
                      </div>
                    </div>
                    <Progress value={city.percentage} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Insights Tab */}
        <TabsContent value="insights">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Alerts */}
            <Card className="bg-black border-gray-900">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  Alertes Business
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {alerts.map((alert, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg border-l-4 ${
                      alert.type === "warning"
                        ? "bg-yellow-500/10 border-yellow-500"
                        : alert.type === "info"
                          ? "bg-gray-800 border-gray-700"
                          : "bg-green-500/10 border-green-500"
                    }`}
                  >
                    <h4 className="font-medium text-white">{alert.title}</h4>
                    <p className="text-sm text-gray-300 mt-1">{alert.message}</p>
                    <Button size="sm" variant="ghost" className="mt-2 p-0 h-auto text-lime-400 hover:text-lime-300">
                      {alert.action} →
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Insights */}
            <Card className="bg-black border-gray-900">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Lightbulb className="h-5 w-5" />
                  Recommandations IA
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {insights.map((insight, index) => (
                  <div key={index} className="p-4 bg-slate-700/30 rounded-lg">
                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-gradient-to-r from-green-500/20 to-lime-500/20 rounded-lg">
                        <insight.icon className="h-5 w-5 text-green-400" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium text-white">{insight.title}</h4>
                          <Badge
                            variant={insight.priority === "high" ? "destructive" : "secondary"}
                            className="text-xs"
                          >
                            {insight.priority === "high" ? "Urgent" : "Moyen"}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-300">{insight.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
