"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ShoppingBag,
  ShoppingCart,
  MessageCircle,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Clock,
  Download,
  Filter,
  Calendar,
  BarChart3,
  RefreshCw,
} from "lucide-react"
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart as RechartsPieChart,
  Cell,
  AreaChart,
  Area,
  Pie,
} from "recharts"
import { getCurrentUser } from "@/lib/supabase-client"
import {
  getDashboardStats,
  getOrders,
  getConversations,
  getProducts,
  getPerformanceAlerts,
  getDailyGoal,
  getTodaySales,
} from "@/lib/database"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"
import { WeatherWidget } from "./weather-widget"
import { DailyGoalWidget } from "./daily-goal-widget"
import { PerformanceAlerts } from "./performance-alerts"

const COLORS = ["#3B82F6", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6", "#06B6D4"]

export default function AdvancedDashboard() {
  const [stats, setStats] = useState({
    todaySales: 0,
    totalOrders: 0,
    totalProducts: 0,
    unreadMessages: 0,
    weeklyOrders: [],
  })
  const [recentOrders, setRecentOrders] = useState([])
  const [recentMessages, setRecentMessages] = useState([])
  const [products, setProducts] = useState([])
  const [alerts, setAlerts] = useState([])
  const [dailyGoal, setDailyGoal] = useState(0)
  const [todaySales, setTodaySales] = useState(0)
  const [isLoading, setIsLoading] = useState(true)
  const [user, setUser] = useState<any>(null)
  const [selectedPeriod, setSelectedPeriod] = useState("7d")
  const [isRefreshing, setIsRefreshing] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    loadDashboardData()
    // Actualiser les données toutes les 30 secondes
    const interval = setInterval(loadDashboardData, 30000)
    return () => clearInterval(interval)
  }, [])

  const loadDashboardData = async (showRefresh = false) => {
    try {
      if (showRefresh) setIsRefreshing(true)

      const currentUser = await getCurrentUser()
      if (!currentUser) {
        setIsLoading(false)
        return
      }
      setUser(currentUser)

      // Charger toutes les données en parallèle
      const [dashboardStats, orders, conversations, productsData, performanceAlerts, goalData, todaySalesData] =
        await Promise.all([
          getDashboardStats(currentUser.id),
          getOrders(currentUser.id),
          getConversations(currentUser.id),
          getProducts(currentUser.id),
          getPerformanceAlerts(currentUser.id),
          getDailyGoal(currentUser.id),
          getTodaySales(currentUser.id),
        ])

      setStats(dashboardStats)
      setRecentOrders(orders.slice(0, 5))
      setRecentMessages(conversations.slice(0, 3))
      setProducts(productsData)
      setAlerts(performanceAlerts)
      setDailyGoal(goalData?.daily_goal || 100)
      setTodaySales(todaySalesData)
    } catch (error: any) {
      console.error("Erreur dashboard:", error)
      toast({
        title: "Erreur",
        description: "Impossible de charger les données du dashboard",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
      if (showRefresh) setIsRefreshing(false)
    }
  }

  const refreshData = () => {
    loadDashboardData(true)
    toast({
      title: "Actualisation",
      description: "Données mises à jour avec succès",
    })
  }

  // Préparer les données pour les graphiques
  const prepareChartData = () => {
    if (!stats || !stats.weeklyOrders || stats.weeklyOrders.length === 0) {
      return Array.from({ length: 7 }, (_, i) => ({
        day: `J-${6 - i}`,
        ventes: 0,
        commandes: 0,
      }))
    }

    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date()
      date.setDate(date.getDate() - (6 - i))
      return date.toISOString().split("T")[0]
    })

    return last7Days.map((date, index) => {
      const dayOrders = stats.weeklyOrders.filter((order: any) => order.created_at.startsWith(date))

      return {
        day: `J-${6 - index}`,
        ventes: dayOrders.reduce((sum: number, order: any) => sum + Number(order.total_amount || 0), 0),
        commandes: dayOrders.length,
      }
    })
  }

  // Données pour le graphique en secteurs des catégories
  const prepareCategoryData = () => {
    const categories = products.reduce((acc: any, product: any) => {
      const category = product.category || "Autres"
      acc[category] = (acc[category] || 0) + 1
      return acc
    }, {})

    return Object.entries(categories).map(([name, value], index) => ({
      name,
      value,
      color: COLORS[index % COLORS.length],
    }))
  }

  const chartData = prepareChartData()
  const categoryData = prepareCategoryData()
  const goalProgress = dailyGoal > 0 ? (todaySales / dailyGoal) * 100 : 0

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
          className="animate-spin rounded-full h-8 w-8 border-b-2 border-lime-600"
        />
      </div>
    )
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <p className="text-gray-500">Veuillez vous connecter pour accéder au dashboard</p>
          <Link href="/auth/login">
            <Button className="mt-4">Se connecter</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header avec contrôles */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold bg-lime-500 bg-clip-text text-transparent">Dashboard PRO+ 🚀</h1>
          <p className="text-gray-600 dark:text-gray-400">Données en temps réel • Dernière mise à jour: maintenant</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" size="sm" onClick={refreshData} disabled={isRefreshing}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
            Actualiser
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Exporter
          </Button>
          <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">🟢 Temps réel</Badge>
        </div>
      </motion.div>

      {/* Widgets principaux */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Widget météo */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          <WeatherWidget city={user?.city || "Paris"} />
        </motion.div>

        {/* Widget objectif quotidien */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <DailyGoalWidget
            goal={dailyGoal}
            current={todaySales}
            progress={goalProgress}
            onUpdateGoal={(newGoal) => setDailyGoal(newGoal)}
          />
        </motion.div>

        {/* Alertes de performance */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <PerformanceAlerts alerts={alerts} onDismiss={(id) => setAlerts(alerts.filter((a) => a.id !== id))} />
        </motion.div>
      </div>

      {/* Stats Cards améliorées */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          {
            title: "Ventes Aujourd'hui",
            value: `${stats.todaySales.toFixed(2)}€`,
            icon: DollarSign,
            color: "from-green-500 to-emerald-600",
            change: "+12%",
            description: "vs hier",
            trend: "up",
          },
          {
            title: "Commandes Totales",
            value: stats.totalOrders.toString(),
            icon: ShoppingCart,
            color: "from-gray-800 to-gray-900",
            change: `+${stats.totalOrders}`,
            description: "depuis le début",
            trend: "up",
          },
          {
            title: "Produits Actifs",
            value: products.filter((p) => p.is_active && p.quantity > 0).length.toString(),
            icon: ShoppingBag,
            color: "from-purple-500 to-violet-600",
            change: `/${stats.totalProducts}`,
            description: "total produits",
            trend: "neutral",
          },
          {
            title: "Messages Non Lus",
            value: stats.unreadMessages.toString(),
            icon: MessageCircle,
            color: "from-orange-500 to-red-600",
            change: stats.unreadMessages > 0 ? "🔴" : "✅",
            description: "à traiter",
            trend: stats.unreadMessages > 0 ? "down" : "up",
          },
        ].map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            whileHover={{ y: -5, scale: 1.02 }}
          >
            <Card className="cursor-pointer hover:shadow-xl transition-all duration-300 bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm border-0 relative overflow-hidden group">
              <motion.div
                className={`absolute inset-0 bg-gradient-to-r ${stat.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`}
              />
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <motion.div
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.6 }}
                  className={`p-2 rounded-lg bg-gradient-to-r ${stat.color}`}
                >
                  <stat.icon className="h-4 w-4 text-white" />
                </motion.div>
              </CardHeader>
              <CardContent>
                <motion.div
                  className="text-2xl font-bold"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: index * 0.1 + 0.3, type: "spring" }}
                >
                  {stat.value}
                </motion.div>
                <div className="flex items-center text-xs">
                  {stat.trend === "up" && <TrendingUp className="h-3 w-3 text-green-600 mr-1" />}
                  {stat.trend === "down" && <TrendingDown className="h-3 w-3 text-red-600 mr-1" />}
                  <span
                    className={stat.trend === "up" ? "text-green-600" : stat.trend === "down" ? "text-red-600" : ""}
                  >
                    {stat.change}
                  </span>
                  <span className="text-gray-500 ml-1">{stat.description}</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Graphiques avancés avec onglets */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.5 }}
      >
        <Card className="hover:shadow-lg transition-all duration-300">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  Analytics Avancés
                </CardTitle>
                <CardDescription>Visualisations interactives de vos données</CardDescription>
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtrer
                </Button>
                <Button variant="outline" size="sm">
                  <Calendar className="h-4 w-4 mr-2" />
                  Période
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="sales" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="sales">Ventes</TabsTrigger>
                <TabsTrigger value="orders">Commandes</TabsTrigger>
                <TabsTrigger value="categories">Catégories</TabsTrigger>
                <TabsTrigger value="performance">Performance</TabsTrigger>
              </TabsList>

              <TabsContent value="sales" className="space-y-4">
                <ResponsiveContainer width="100%" height={400}>
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="salesGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#84cc16" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#84cc16" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip
                      formatter={(value) => [`${value}€`, "Ventes"]}
                      labelStyle={{ color: "#374151" }}
                      contentStyle={{
                        backgroundColor: "rgba(255, 255, 255, 0.95)",
                        border: "none",
                        borderRadius: "8px",
                        boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="ventes"
                      stroke="#84cc16"
                      strokeWidth={3}
                      fill="url(#salesGradient)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </TabsContent>

              <TabsContent value="orders" className="space-y-4">
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="commandes" fill="url(#ordersGradient)" radius={[4, 4, 0, 0]} />
                    <defs>
                      <linearGradient id="ordersGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#10B981" />
                        <stop offset="100%" stopColor="#059669" />
                      </linearGradient>
                    </defs>
                  </BarChart>
                </ResponsiveContainer>
              </TabsContent>

              <TabsContent value="categories" className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <ResponsiveContainer width="100%" height={300}>
                    <RechartsPieChart>
                      <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                  <div className="space-y-3">
                    <h4 className="font-semibold">Répartition par catégorie</h4>
                    {categoryData.map((category, index) => (
                      <div key={category.name} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: category.color }} />
                          <span className="text-sm">{category.name}</span>
                        </div>
                        <Badge variant="outline">{category.value} produits</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="performance" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Taux de conversion</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-green-600">12.5%</div>
                      <p className="text-xs text-gray-500">+2.1% vs mois dernier</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Temps de réponse moyen</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-lime-500">2.3min</div>
                      <p className="text-xs text-gray-500">-30s vs semaine dernière</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Satisfaction client</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-purple-600">4.8/5</div>
                      <p className="text-xs text-gray-500">Basé sur 127 avis</p>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </motion.div>

      {/* Activité récente avec design amélioré */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Commandes récentes */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <Card className="hover:shadow-lg transition-all duration-300">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center">
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Commandes Récentes
                </CardTitle>
                <CardDescription>Dernières commandes de la base Supabase</CardDescription>
              </div>
              <Link href="/dashboard/orders">
                <Button variant="outline" size="sm">
                  Voir tout
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <AnimatePresence>
                  {recentOrders.length > 0 ? (
                    recentOrders.map((order: any, index) => (
                      <motion.div
                        key={order.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 rounded-lg hover:shadow-md transition-all duration-300 cursor-pointer group"
                      >
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <p className="font-medium group-hover:text-lime-500 transition-colors">
                              {order.client_name}
                            </p>
                            <Badge
                              variant={
                                order.status === "delivered"
                                  ? "default"
                                  : order.status === "shipped"
                                    ? "secondary"
                                    : "outline"
                              }
                              className={
                                order.status === "delivered"
                                  ? "bg-green-100 text-green-800"
                                  : order.status === "shipped"
                                    ? "bg-gray-900 text-lime-400"
                                    : "bg-yellow-100 text-yellow-800"
                              }
                            >
                              {order.status === "delivered"
                                ? "Livrée"
                                : order.status === "shipped"
                                  ? "Expédiée"
                                  : "En attente"}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">{order.order_number}</p>
                          <div className="flex items-center justify-between">
                            <p className="text-lg font-bold text-green-600">{Number(order.total_amount).toFixed(2)}€</p>
                            <span className="text-xs text-gray-500 flex items-center">
                              <Clock className="h-3 w-3 mr-1" />
                              {new Date(order.created_at).toLocaleDateString("fr-FR")}
                            </span>
                          </div>
                        </div>
                      </motion.div>
                    ))
                  ) : (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-8">
                      <ShoppingCart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500 mb-2">Aucune commande dans Supabase</p>
                      <p className="text-sm text-gray-400">Créez votre première commande</p>
                      <Link href="/dashboard/orders">
                        <Button className="mt-4" size="sm">
                          Créer une commande
                        </Button>
                      </Link>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Messages récents */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.9 }}
        >
          <Card className="hover:shadow-lg transition-all duration-300">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center">
                  <MessageCircle className="h-5 w-5 mr-2" />
                  Messages Récents
                </CardTitle>
                <CardDescription>Dernières conversations de Supabase</CardDescription>
              </div>
              <Link href="/dashboard/messages">
                <Button variant="outline" size="sm">
                  Voir tout
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <AnimatePresence>
                  {recentMessages.length > 0 ? (
                    recentMessages.map((conversation: any, index) => (
                      <motion.div
                        key={conversation.id}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-purple-50 dark:from-gray-800 dark:to-purple-900/20 rounded-lg hover:shadow-md transition-all duration-300 cursor-pointer group"
                      >
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <p className="font-medium group-hover:text-lime-500 transition-colors">
                              {conversation.client_name || conversation.whatsapp_number}
                            </p>
                            <div className="flex items-center space-x-2">
                              <span className="text-xs text-gray-500">
                                {new Date(conversation.last_message_time).toLocaleTimeString("fr-FR", {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}
                              </span>
                              {conversation.unread_count > 0 && (
                                <motion.div
                                  animate={{ scale: [1, 1.2, 1] }}
                                  transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY }}
                                  className="w-2 h-2 bg-lime-500 rounded-full"
                                />
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 truncate">
                            {conversation.last_message || "Aucun message"}
                          </p>
                          {conversation.unread_count > 0 && (
                            <Badge className="mt-2 bg-gray-900 text-lime-400 text-xs">
                              {conversation.unread_count} non lu(s)
                            </Badge>
                          )}
                        </div>
                      </motion.div>
                    ))
                  ) : (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-8">
                      <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500 mb-2">Aucun message dans Supabase</p>
                      <p className="text-sm text-gray-400">Connectez WhatsApp pour recevoir des messages</p>
                      <Link href="/dashboard/messages">
                        <Button className="mt-4" size="sm">
                          Configurer WhatsApp
                        </Button>
                      </Link>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}
