"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Plus,
  Search,
  Filter,
  Eye,
  Truck,
  Package,
  CheckCircle,
  Clock,
  MoreHorizontal,
  Calendar,
  Trash2,
  Check,
  AlertTriangle,
  Download,
  FileText,
  Repeat,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { getCurrentUser } from "@/lib/supabase-client"
import {
  getOrders,
  getProducts,
  createOrder,
  updateOrderStatus,
  getOrderWithItems,
  deleteOrder,
  getUserProfile,
} from "@/lib/database"
import { useToast } from "@/hooks/use-toast"
import { formatMAD } from "@/lib/utils"
import {
  exportOrdersToPDF,
  exportOrdersToCSV,
  exportOrdersToExcel,
  generateInvoicePDF,
  generateShippingLabel,
  generateCatalogPDF,
} from "@/lib/export-utils"
import { repeatOrder } from "@/lib/database-enhanced"

export default function OrdersContent() {
  const [orders, setOrders] = useState([])
  const [products, setProducts] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedOrder, setSelectedOrder] = useState<any>(null)
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isLoadingDetails, setIsLoadingDetails] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [orderToDelete, setOrderToDelete] = useState<any>(null)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [newOrder, setNewOrder] = useState({
    client: "",
    phone: "",
    address: "",
    products: [{ productId: "", quantity: 1 }],
    notes: "",
  })
  const { toast } = useToast()
  const [userProfile, setUserProfile] = useState<any>(null)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      setIsLoading(true)
      const user = await getCurrentUser()
      if (!user) {
        toast({
          title: "Erreur d'authentification",
          description: "Vous devez être connecté",
          variant: "destructive",
        })
        return
      }

      const [ordersData, productsData, profileData] = await Promise.all([
        getOrders(user.id),
        getProducts(user.id),
        getUserProfile(user.id), // Ajouter cette ligne
      ])

      setOrders(ordersData)
      setProducts(productsData)
      setUserProfile(profileData) // Ajouter cette ligne
    } catch (error: any) {
      console.error("Erreur chargement commandes:", error)
      toast({
        title: "Erreur",
        description: "Impossible de charger les commandes",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const filteredOrders = orders.filter((order: any) => {
    const matchesSearch =
      order.client_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.order_number?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = selectedStatus === "all" || order.status === selectedStatus
    return matchesSearch && matchesStatus
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge
            variant="secondary"
            className="bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300"
          >
            <Clock className="h-3 w-3 mr-1" />
            En attente
          </Badge>
        )
      case "confirmed":
        return (
          <Badge variant="secondary" className="bg-gray-800 text-lime-400">
            <Check className="h-3 w-3 mr-1" />
            Confirmée
          </Badge>
        )
      case "shipped":
        return (
          <Badge variant="secondary" className="bg-purple-100 text-purple-800">
            <Truck className="h-3 w-3 mr-1" />
            Expédiée
          </Badge>
        )
      case "delivered":
        return (
          <Badge variant="default" className="bg-green-100 text-green-800">
            <CheckCircle className="h-3 w-3 mr-1" />
            Livrée
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const handleAddProduct = () => {
    setNewOrder({
      ...newOrder,
      products: [...newOrder.products, { productId: "", quantity: 1 }],
    })
  }

  const handleRemoveProduct = (index: number) => {
    const updatedProducts = newOrder.products.filter((_, i) => i !== index)
    setNewOrder({ ...newOrder, products: updatedProducts })
  }

  const updateProductInOrder = (index: number, field: string, value: any) => {
    const updatedProducts = [...newOrder.products]
    updatedProducts[index] = { ...updatedProducts[index], [field]: value }
    setNewOrder({ ...newOrder, products: updatedProducts })
  }

  const calculateTotal = () => {
    return newOrder.products.reduce((total, orderProduct) => {
      const product = products.find((p: any) => p.id === orderProduct.productId)
      return total + (product ? product.price * orderProduct.quantity : 0)
    }, 0)
  }

  const handleOpenAddDialog = () => {
    console.log("🚀 Ouverture du dialog de commande")
    setNewOrder({
      client: "",
      phone: "",
      address: "",
      products: [{ productId: "", quantity: 1 }],
      notes: "",
    })
    setIsAddDialogOpen(true)
  }

  const handleCreateOrder = async () => {
    if (isSubmitting) return

    try {
      setIsSubmitting(true)

      // Validation
      if (!newOrder.client.trim()) {
        toast({
          title: "Erreur de validation",
          description: "Le nom du client est requis",
          variant: "destructive",
        })
        return
      }

      const validProducts = newOrder.products.filter((p) => p.productId && p.quantity > 0)
      if (validProducts.length === 0) {
        toast({
          title: "Erreur",
          description: "Veuillez sélectionner au moins un produit",
          variant: "destructive",
        })
        return
      }

      // Vérifier le stock disponible
      for (const orderProduct of validProducts) {
        const product = products.find((p: any) => p.id === orderProduct.productId)
        if (!product) {
          toast({
            title: "Erreur",
            description: "Produit non trouvé",
            variant: "destructive",
          })
          return
        }
        if (product.quantity < orderProduct.quantity) {
          toast({
            title: "Stock insuffisant",
            description: `Stock disponible pour ${product.name}: ${product.quantity}`,
            variant: "destructive",
          })
          return
        }
      }

      const user = await getCurrentUser()
      if (!user) {
        toast({
          title: "Erreur d'authentification",
          description: "Vous devez être connecté",
          variant: "destructive",
        })
        return
      }

      const orderNumber = `ORD-${Date.now().toString().slice(-6)}`
      const total = calculateTotal()

      const orderData = {
        user_id: user.id,
        order_number: orderNumber,
        client_name: newOrder.client.trim(),
        client_phone: newOrder.phone.trim(),
        client_address: newOrder.address.trim(),
        total_amount: total,
        status: "pending", // Statut initial: En attente
        notes: newOrder.notes.trim(),
      }

      const orderItems = validProducts.map((orderProduct) => {
        const product = products.find((p: any) => p.id === orderProduct.productId)
        return {
          product_id: orderProduct.productId,
          quantity: orderProduct.quantity,
          price: product?.price || 0,
        }
      })

      await createOrder(orderData, orderItems)

      toast({
        title: "Commande créée",
        description: "La commande a été créée avec succès et le stock a été mis à jour",
      })

      setIsAddDialogOpen(false)
      setNewOrder({
        client: "",
        phone: "",
        address: "",
        products: [{ productId: "", quantity: 1 }],
        notes: "",
      })
      loadData()
    } catch (error: any) {
      console.error("Erreur création commande:", error)
      toast({
        title: "Erreur",
        description: "Impossible de créer la commande: " + (error.message || "Erreur inconnue"),
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleViewOrder = async (order: any) => {
    setIsLoadingDetails(true)
    try {
      const orderWithItems = await getOrderWithItems(order.id)
      console.log("🔍 Commande avec items chargée:", orderWithItems)
      setSelectedOrder(orderWithItems)
      setIsDetailDialogOpen(true)
    } catch (error: any) {
      console.error("Erreur chargement détails:", error)
      toast({
        title: "Erreur",
        description: "Impossible de charger les détails de la commande",
        variant: "destructive",
      })
      setSelectedOrder({
        ...order,
        items: [],
      })
      setIsDetailDialogOpen(true)
    } finally {
      setIsLoadingDetails(false)
    }
  }

  const handleUpdateStatus = async (orderId: string, newStatus: string) => {
    try {
      console.log(`🔄 Mise à jour statut commande ${orderId} vers ${newStatus}`)

      await updateOrderStatus(orderId, newStatus)

      toast({
        title: "Statut mis à jour",
        description: `Commande marquée comme ${getStatusLabel(newStatus)}`,
      })

      // Recharger les données pour voir les changements
      await loadData()
    } catch (error: any) {
      console.error("Erreur mise à jour statut:", error)

      // Message d'erreur plus spécifique
      let errorMessage = "Impossible de mettre à jour le statut"
      if (error.message?.includes("check constraint")) {
        errorMessage = "Statut non valide. Veuillez exécuter le script de mise à jour de la base de données."
      }

      toast({
        title: "Erreur",
        description: errorMessage + ": " + (error.message || "Erreur inconnue"),
        variant: "destructive",
      })
    }
  }

  const handleDeleteOrder = async () => {
    if (!orderToDelete || isDeleting) return

    try {
      setIsDeleting(true)

      await deleteOrder(orderToDelete.id)

      toast({
        title: "Commande supprimée",
        description: "La commande a été supprimée et le stock a été restauré",
      })

      setIsDeleteDialogOpen(false)
      setOrderToDelete(null)
      await loadData()
    } catch (error: any) {
      console.error("Erreur suppression commande:", error)
      toast({
        title: "Erreur",
        description: "Impossible de supprimer la commande: " + (error.message || "Erreur inconnue"),
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "pending":
        return "en attente"
      case "confirmed":
        return "confirmée"
      case "shipped":
        return "expédiée"
      case "delivered":
        return "livrée"
      default:
        return status
    }
  }

  // FONCTION POUR GÉNÉRER FACTURE AVEC ITEMS COMPLETS
  const handleGenerateInvoice = async (order: any) => {
    try {
      console.log("🧾 Génération facture pour commande:", order.id)

      // Récupérer la commande avec tous ses items
      const orderWithItems = await getOrderWithItems(order.id)
      console.log("📦 Commande complète récupérée:", orderWithItems)

      // Générer la facture avec les données complètes
      await generateInvoicePDF(orderWithItems, userProfile)

      toast({
        title: "Facture générée",
        description: "La facture PDF a été téléchargée avec succès",
      })
    } catch (error: any) {
      console.error("Erreur génération facture:", error)
      toast({
        title: "Erreur",
        description: "Impossible de générer la facture: " + error.message,
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-600"></div>
      </div>
    )
  }

  const profileData = {}

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Gestion des commandes</h1>
          <p className="text-gray-600 dark:text-gray-400 font-extralight">Gérez vos {orders.length} commandes</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => exportOrdersToPDF(filteredOrders)}
              className="flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              PDF
            </Button>
            <Button
              variant="outline"
              onClick={() => exportOrdersToCSV(filteredOrders)}
              className="flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              CSV
            </Button>
            <Button
              variant="outline"
              onClick={() => exportOrdersToExcel(filteredOrders)}
              className="flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              Excel
            </Button>
            <Button
              variant="outline"
              onClick={() => generateCatalogPDF(products, userProfile)}
              className="flex items-center gap-2"
            >
              <FileText className="h-4 w-4" />
              Catalogue
            </Button>
          </div>
          <Button onClick={handleOpenAddDialog} className="bg-lime-500 hover:bg-lime-600">
            <Plus className="h-4 w-4 mr-2" />
            Nouvelle commande
          </Button>
        </div>
      </div>

      {/* Message d'information pour la contrainte */}
      {orders.some((order: any) => !["pending", "confirmed", "shipped", "delivered"].includes(order.status)) && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-yellow-600" />
              <div>
                <p className="text-sm font-medium text-yellow-800">Mise à jour requise</p>
                <p className="text-sm text-yellow-700">
                  Certaines commandes ont des statuts non valides. Exécutez le script
                  "fix-order-status-constraint-v2.sql" pour corriger cela.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Dialog d'ajout de commande */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Créer une nouvelle commande</DialogTitle>
            <DialogDescription>Remplissez les informations de la commande ci-dessous.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="client">Nom du client *</Label>
                <Input
                  id="client"
                  value={newOrder.client}
                  onChange={(e) => setNewOrder({ ...newOrder, client: e.target.value })}
                  placeholder="Nom complet"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="phone">Téléphone</Label>
                <Input
                  id="phone"
                  value={newOrder.phone}
                  onChange={(e) => setNewOrder({ ...newOrder, phone: e.target.value })}
                  placeholder="+212 6 12 34 56 78"
                />
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="address">Adresse de livraison</Label>
              <Textarea
                id="address"
                value={newOrder.address}
                onChange={(e) => setNewOrder({ ...newOrder, address: e.target.value })}
                placeholder="Adresse complète de livraison"
              />
            </div>

            <div className="grid gap-2">
              <div className="flex items-center justify-between">
                <Label>Produits</Label>
                <Button type="button" variant="outline" size="sm" onClick={handleAddProduct}>
                  <Plus className="h-4 w-4 mr-1" />
                  Ajouter produit
                </Button>
              </div>

              {newOrder.products.map((orderProduct, index) => (
                <div key={index} className="flex gap-2 items-end p-3 border rounded-lg">
                  <div className="flex-1">
                    <Label className="text-sm">Produit</Label>
                    <Select
                      value={orderProduct.productId}
                      onValueChange={(value) => updateProductInOrder(index, "productId", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionner un produit" />
                      </SelectTrigger>
                      <SelectContent>
                        {products.map((product: any) => (
                          <SelectItem key={product.id} value={product.id}>
                            {product.name} - {formatMAD(product.price)} (Stock: {product.quantity})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="w-24">
                    <Label className="text-sm">Quantité</Label>
                    <Input
                      type="number"
                      min="1"
                      value={orderProduct.quantity}
                      onChange={(e) => updateProductInOrder(index, "quantity", Number.parseInt(e.target.value) || 1)}
                      placeholder="Qté"
                    />
                  </div>
                  <div className="w-20 text-right">
                    <Label className="text-sm">Prix</Label>
                    <p className="text-sm font-medium">
                      {(() => {
                        const product = products.find((p: any) => p.id === orderProduct.productId)
                        return product ? formatMAD(product.price * orderProduct.quantity) : "0 MAD"
                      })()}
                    </p>
                  </div>
                  {newOrder.products.length > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => handleRemoveProduct(index)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="notes">Notes (optionnel)</Label>
              <Textarea
                id="notes"
                value={newOrder.notes}
                onChange={(e) => setNewOrder({ ...newOrder, notes: e.target.value })}
                placeholder="Instructions spéciales, commentaires..."
              />
            </div>

            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <div className="flex justify-between items-center">
                <span className="font-medium">Total de la commande:</span>
                <span className="text-xl font-bold text-lime-500">{formatMAD(calculateTotal())}</span>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)} disabled={isSubmitting}>
              Annuler
            </Button>
            <Button onClick={handleCreateOrder} disabled={isSubmitting}>
              {isSubmitting ? "Création en cours..." : "Créer la commande"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog de confirmation de suppression */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-600" />
              Supprimer la commande
            </AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir supprimer la commande{" "}
              <strong>{orderToDelete?.order_number || `#${orderToDelete?.id?.slice(0, 8)}`}</strong> ?
              <br />
              <br />
              <div className="bg-gray-900 p-3 rounded-lg mt-2">
                <div className="text-sm text-lime-500 font-medium">📈 Le stock sera automatiquement restauré :</div>
                <div className="text-sm text-gray-700">
                  Les quantités des produits commandés seront rajoutées au stock disponible.
                </div>
              </div>
              <br />
              Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Annuler</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteOrder}
              disabled={isDeleting}
              className="bg-red-600 hover:bg-red-700"
            >
              {isDeleting ? "Suppression..." : "Supprimer"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Rechercher par client ou numéro..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="pending">En attente</SelectItem>
                <SelectItem value="confirmed">Confirmée</SelectItem>
                <SelectItem value="shipped">Expédiée</SelectItem>
                <SelectItem value="delivered">Livrée</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total</p>
                <p className="text-2xl font-bold">{orders.length}</p>
              </div>
              <Package className="h-8 w-8 text-lime-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">En attente</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {orders.filter((o: any) => o.status === "pending").length}
                </p>
              </div>
              <Clock className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Confirmées</p>
                <p className="text-2xl font-bold text-lime-500">
                  {orders.filter((o: any) => o.status === "confirmed").length}
                </p>
              </div>
              <Check className="h-8 w-8 text-lime-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Expédiées</p>
                <p className="text-2xl font-bold text-purple-600">
                  {orders.filter((o: any) => o.status === "shipped").length}
                </p>
              </div>
              <Truck className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Livrées</p>
                <p className="text-2xl font-bold text-green-600">
                  {orders.filter((o: any) => o.status === "delivered").length}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Orders List */}
      <Card>
        <CardHeader>
          <CardTitle>Liste des commandes</CardTitle>
          <CardDescription>
            {filteredOrders.length} commande{filteredOrders.length > 1 ? "s" : ""} trouvée
            {filteredOrders.length > 1 ? "s" : ""}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredOrders.length > 0 ? (
              filteredOrders.map((order: any) => (
                <div
                  key={order.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <div className="bg-gray-900 p-3 rounded-lg">
                      <Package className="h-6 w-6 text-lime-500" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <h3 className="font-medium">{order.order_number || `#${order.id.slice(0, 8)}`}</h3>
                        {getStatusBadge(order.status)}
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{order.client_name}</p>
                      <div className="flex items-center space-x-4 mt-1">
                        <span className="text-sm font-medium">{formatMAD(Number(order.total_amount))}</span>
                        <span className="text-xs text-gray-500 flex items-center">
                          <Calendar className="h-3 w-3 mr-1" />
                          {new Date(order.created_at).toLocaleDateString("fr-FR")}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleViewOrder(order)}
                      disabled={isLoadingDetails}
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      {isLoadingDetails ? "..." : "Détails"}
                    </Button>

                    <div className="relative">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 w-8 p-0 border-gray-300"
                        data-order-id={order.id}
                        onClick={(e) => {
                          e.preventDefault()
                          e.stopPropagation()
                          const menu = e.currentTarget.nextElementSibling as HTMLElement
                          if (menu) {
                            menu.style.display = menu.style.display === "block" ? "none" : "block"
                          }
                        }}
                      >
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>

                      <div
                        className="absolute right-0 top-10 w-[200px] bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-lg rounded-md py-1 z-50 hidden"
                        style={{ display: "none" }}
                      >
                        <div className="px-3 py-2 text-sm font-semibold border-b border-gray-200 dark:border-gray-700 text-gray-900 dark:text-gray-100">
                          Actions
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            handleGenerateInvoice(order) // UTILISER LA NOUVELLE FONCTION
                            // Fermeture sécurisée du menu
                            const button = document.querySelector(`[data-order-id="${order.id}"]`)
                            const menu = button?.nextElementSibling as HTMLElement
                            if (menu) menu.style.display = "none"
                          }}
                          className="w-full px-3 py-2 text-sm text-left hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center text-gray-900 dark:text-gray-100"
                        >
                          <FileText className="mr-2 h-4 w-4" />
                          Générer facture PDF
                        </button>

                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            generateShippingLabel(order)
                            // Fermeture sécurisée du menu
                            const button = document.querySelector(`[data-order-id="${order.id}"]`)
                            const menu = button?.nextElementSibling as HTMLElement
                            if (menu) menu.style.display = "none"
                          }}
                          className="w-full px-3 py-2 text-sm text-left hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center text-gray-900 dark:text-gray-100"
                        >
                          <Package className="mr-2 h-4 w-4" />
                          Étiquette colis
                        </button>

                        <button
                          onClick={async (e) => {
                            e.stopPropagation()
                            try {
                              await repeatOrder(order.id)
                              toast({
                                title: "Commande répétée",
                                description: "Une nouvelle commande identique a été créée",
                              })
                              loadData()
                            } catch (error: any) {
                              toast({
                                title: "Erreur",
                                description: error.message,
                                variant: "destructive",
                              })
                            }
                            // Fermeture sécurisée du menu
                            const button = document.querySelector(`[data-order-id="${order.id}"]`)
                            const menu = button?.nextElementSibling as HTMLElement
                            if (menu) menu.style.display = "none"
                          }}
                          className="w-full px-3 py-2 text-sm text-left hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center text-gray-900 dark:text-gray-100"
                        >
                          <Repeat className="mr-2 h-4 w-4" />
                          Répéter cette commande
                        </button>
                        {order.status !== "confirmed" && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation()
                              handleUpdateStatus(order.id, "confirmed")
                              // Fermeture sécurisée du menu
                              const button = document.querySelector(`[data-order-id="${order.id}"]`)
                              const menu = button?.nextElementSibling as HTMLElement
                              if (menu) menu.style.display = "none"
                            }}
                            className="w-full px-3 py-2 text-sm text-left hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center text-gray-900 dark:text-gray-100"
                          >
                            <Check className="mr-2 h-4 w-4" />
                            Marquer comme confirmée
                          </button>
                        )}
                        {order.status !== "shipped" && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation()
                              handleUpdateStatus(order.id, "shipped")
                              // Fermeture sécurisée du menu
                              const button = document.querySelector(`[data-order-id="${order.id}"]`)
                              const menu = button?.nextElementSibling as HTMLElement
                              if (menu) menu.style.display = "none"
                            }}
                            className="w-full px-3 py-2 text-sm text-left hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center text-gray-900 dark:text-gray-100"
                          >
                            <Truck className="mr-2 h-4 w-4" />
                            Marquer comme expédiée
                          </button>
                        )}
                        {order.status !== "delivered" && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation()
                              handleUpdateStatus(order.id, "delivered")
                              // Fermeture sécurisée du menu
                              const button = document.querySelector(`[data-order-id="${order.id}"]`)
                              const menu = button?.nextElementSibling as HTMLElement
                              if (menu) menu.style.display = "none"
                            }}
                            className="w-full px-3 py-2 text-sm text-left hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center text-gray-900 dark:text-gray-100"
                          >
                            <CheckCircle className="mr-2 h-4 w-4" />
                            Marquer comme livrée
                          </button>
                        )}
                        <div className="border-t my-1"></div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            setOrderToDelete(order)
                            setIsDeleteDialogOpen(true)
                            // Fermeture sécurisée du menu
                            const button = document.querySelector(`[data-order-id="${order.id}"]`)
                            const menu = button?.nextElementSibling as HTMLElement
                            if (menu) menu.style.display = "none"
                          }}
                          className="w-full px-3 py-2 text-sm text-left hover:bg-red-50 dark:hover:bg-red-900/20 text-red-600 dark:text-red-400 flex items-center"
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Supprimer la commande
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 text-lg mb-2">Aucune commande trouvée</p>
                <p className="text-sm text-gray-400 mb-6">
                  {orders.length === 0
                    ? "Commencez par créer votre première commande"
                    : "Aucune commande ne correspond à vos critères de recherche"}
                </p>
                <Button onClick={handleOpenAddDialog}>
                  <Plus className="h-4 w-4 mr-2" />
                  Créer une commande
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Order Detail Dialog */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>
              Détails de la commande {selectedOrder?.order_number || `#${selectedOrder?.id?.slice(0, 8)}`}
            </DialogTitle>
            <DialogDescription>
              Commande passée le {selectedOrder && new Date(selectedOrder.created_at).toLocaleDateString("fr-FR")}
            </DialogDescription>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium">Client</Label>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{selectedOrder.client_name}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Téléphone</Label>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {selectedOrder.client_phone || "Non renseigné"}
                  </p>
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium">Adresse de livraison</Label>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {selectedOrder.client_address || "Non renseignée"}
                </p>
              </div>

              {selectedOrder.items && selectedOrder.items.length > 0 && (
                <div>
                  <Label className="text-sm font-medium">Produits commandés</Label>
                  <div className="space-y-3 mt-2">
                    {selectedOrder.items.map((item: any, index: number) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg"
                      >
                        <div className="flex items-center space-x-3">
                          {/* Photo du produit */}
                          <div className="w-12 h-12 rounded-lg overflow-hidden bg-gray-200 dark:bg-gray-700 flex-shrink-0">
                            {item.product?.image ? (
                              <img
                                src={item.product.image || "/placeholder.svg"}
                                alt={item.product?.name || "Produit"}
                                className="w-full h-full object-cover"
                                onError={(e) => {
                                  e.currentTarget.style.display = "none"
                                  e.currentTarget.nextElementSibling.style.display = "flex"
                                }}
                              />
                            ) : null}
                            <div
                              className="w-full h-full flex items-center justify-center"
                              style={{ display: item.product?.image ? "none" : "flex" }}
                            >
                              <Package className="h-6 w-6 text-gray-400" />
                            </div>
                          </div>

                          <div>
                            <span className="text-sm font-medium">{item.product?.name || "Produit supprimé"}</span>
                            <p className="text-xs text-gray-500">Quantité: {item.quantity}</p>
                          </div>
                        </div>
                        <span className="text-sm font-medium">{formatMAD(Number(item.price) * item.quantity)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {selectedOrder.notes && (
                <div>
                  <Label className="text-sm font-medium">Notes</Label>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{selectedOrder.notes}</p>
                </div>
              )}

              <div className="flex justify-between items-center pt-4 border-t">
                <span className="font-medium">Total</span>
                <span className="text-xl font-bold text-lime-500">{formatMAD(Number(selectedOrder.total_amount))}</span>
              </div>

              <div className="flex items-center justify-center">{getStatusBadge(selectedOrder.status)}</div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
