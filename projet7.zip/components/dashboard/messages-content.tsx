"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Send,
  Search,
  Phone,
  MoreVertical,
  Paperclip,
  Smile,
  MessageCircle,
  Clock,
  Check,
  CheckCheck,
} from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { getCurrentUser } from "@/lib/supabase-client"
import { getConversations, getMessages, sendMessage } from "@/lib/database"
import { useToast } from "@/hooks/use-toast"

export default function MessagesContent() {
  const [conversations, setConversations] = useState([])
  const [selectedConversation, setSelectedConversation] = useState<any>(null)
  const [messages, setMessages] = useState([])
  const [newMessage, setNewMessage] = useState("")
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    loadConversations()
  }, [])

  useEffect(() => {
    if (selectedConversation) {
      loadMessages(selectedConversation.whatsapp_number)
    }
  }, [selectedConversation])

  const loadConversations = async () => {
    try {
      const user = await getCurrentUser()
      if (!user) return

      const conversationsData = await getConversations(user.id)
      setConversations(conversationsData)

      if (conversationsData.length > 0 && !selectedConversation) {
        setSelectedConversation(conversationsData[0])
      }
    } catch (error: any) {
      console.error("Erreur chargement conversations:", error)
      toast({
        title: "Erreur",
        description: "Impossible de charger les conversations",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const loadMessages = async (whatsappNumber: string) => {
    try {
      const user = await getCurrentUser()
      if (!user) return

      const messagesData = await getMessages(user.id, whatsappNumber)
      setMessages(messagesData)
    } catch (error: any) {
      console.error("Erreur chargement messages:", error)
    }
  }

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedConversation) return

    try {
      const user = await getCurrentUser()
      if (!user) return

      const messageData = {
        user_id: user.id,
        whatsapp_number: selectedConversation.whatsapp_number,
        sender: "me",
        content: newMessage,
        timestamp: new Date().toISOString(),
        status: "sent",
      }

      await sendMessage(messageData)
      setNewMessage("")
      loadMessages(selectedConversation.whatsapp_number)
      loadConversations() // Refresh conversations list
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: "Impossible d'envoyer le message",
        variant: "destructive",
      })
    }
  }

  const filteredConversations = conversations.filter(
    (conv: any) =>
      (conv.client_name && conv.client_name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      conv.whatsapp_number.includes(searchTerm),
  )

  const getMessageStatus = (status: string) => {
    switch (status) {
      case "sent":
        return <Check className="h-3 w-3 text-gray-400" />
      case "delivered":
        return <CheckCheck className="h-3 w-3 text-gray-400" />
      case "read":
        return <CheckCheck className="h-3 w-3 text-blue-500" />
      default:
        return <Clock className="h-3 w-3 text-gray-400" />
    }
  }

  const totalUnreadCount = conversations.reduce((sum: number, conv: any) => sum + (conv.unread_count || 0), 0)

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-lime-500"></div>
      </div>
    )
  }

  if (conversations.length === 0) {
    return (
      <div className="space-y-6 animate-fade-in-up">
        <div>
          <h1 className="text-2xl font-bold text-white">Messages WhatsApp</h1>
          <p className="text-gray-600 dark:text-gray-400">Gérez vos conversations clients</p>
        </div>
        <div className="h-[calc(100vh-8rem)] flex items-center justify-center">
          <div className="text-center">
            <MessageCircle className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-white mb-2">Aucune conversation</h3>
            <p className="text-gray-500 mb-6">Vos conversations WhatsApp apparaîtront ici</p>
            <p className="text-sm text-gray-400">
              Connectez votre compte WhatsApp Business pour commencer à recevoir des messages
            </p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div>
        <h1 className="text-2xl font-bold text-white">Messages WhatsApp</h1>
        <p className="text-gray-600 dark:text-gray-400">Gérez vos {conversations.length} conversations</p>
      </div>

      <div className="h-[calc(100vh-8rem)]">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full">
          {/* Conversations List */}
          <div className="lg:col-span-4 xl:col-span-3">
            <Card className="h-full flex flex-col">
              <CardHeader className="pb-3 flex-shrink-0">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center text-white">
                    <MessageCircle className="h-5 w-5 mr-2 text-lime-400" />
                    Messages
                  </CardTitle>
                  {totalUnreadCount > 0 && (
                    <Badge variant="secondary" className="bg-red-100 text-red-800">
                      {totalUnreadCount} non lus
                    </Badge>
                  )}
                </div>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Rechercher une conversation..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </CardHeader>
              <CardContent className="p-0 flex-1 overflow-hidden">
                <ScrollArea className="h-full">
                  <div className="space-y-1 p-3">
                    {filteredConversations.map((conversation: any) => (
                      <div
                        key={conversation.id}
                        className={`flex items-center space-x-3 p-3 rounded-lg cursor-pointer transition-colors ${
                          selectedConversation?.id === conversation.id
                            ? "bg-lime-500/20 border border-lime-500/30"
                            : "hover:bg-gray-50 dark:hover:bg-gray-800"
                        }`}
                        onClick={() => setSelectedConversation(conversation)}
                      >
                        <div className="relative flex-shrink-0">
                          <Avatar className="h-12 w-12">
                            <AvatarImage src="/placeholder.svg" />
                            <AvatarFallback className="bg-lime-500 text-black">
                              {conversation.client_name
                                ? conversation.client_name
                                    .split(" ")
                                    .map((n: string) => n[0])
                                    .join("")
                                : "?"}
                            </AvatarFallback>
                          </Avatar>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <p className="text-sm font-medium truncate text-white">
                              {conversation.client_name || conversation.whatsapp_number}
                            </p>
                            <div className="flex items-center space-x-2">
                              <span className="text-xs text-gray-500">
                                {new Date(conversation.last_message_time).toLocaleTimeString("fr-FR", {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}
                              </span>
                              {conversation.unread_count > 0 && (
                                <Badge className="bg-lime-500 text-black text-xs h-5 w-5 rounded-full p-0 flex items-center justify-center">
                                  {conversation.unread_count}
                                </Badge>
                              )}
                            </div>
                          </div>
                          <p className="text-xs text-gray-600 dark:text-gray-400 mb-1">
                            {conversation.whatsapp_number}
                          </p>
                          <p className="text-sm text-gray-600 dark:text-gray-400 truncate">
                            {conversation.last_message || "Aucun message"}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Chat Area */}
          <div className="lg:col-span-8 xl:col-span-9">
            {selectedConversation ? (
              <Card className="h-full flex flex-col">
                {/* Chat Header */}
                <CardHeader className="pb-3 border-b flex-shrink-0">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src="/placeholder.svg" />
                        <AvatarFallback className="bg-lime-500 text-black">
                          {selectedConversation.client_name
                            ? selectedConversation.client_name
                                .split(" ")
                                .map((n: string) => n[0])
                                .join("")
                            : "?"}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-medium text-lg text-white">
                          {selectedConversation.client_name || selectedConversation.whatsapp_number}
                        </h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {selectedConversation.whatsapp_number}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm">
                        <Phone className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                {/* Messages */}
                <CardContent className="flex-1 p-0 overflow-hidden">
                  <ScrollArea className="h-full p-4">
                    <div className="space-y-4">
                      {messages.length > 0 ? (
                        messages.map((message: any) => (
                          <div
                            key={message.id}
                            className={`flex ${message.sender === "me" ? "justify-end" : "justify-start"}`}
                          >
                            <div
                              className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
                                message.sender === "me"
                                  ? "bg-lime-500 text-black rounded-br-md"
                                  : "bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100 rounded-bl-md"
                              }`}
                            >
                              <p className="text-sm leading-relaxed">{message.content}</p>
                              <div
                                className={`flex items-center justify-end space-x-1 mt-2 ${
                                  message.sender === "me" ? "text-black/70" : "text-gray-500"
                                }`}
                              >
                                <span className="text-xs">
                                  {new Date(message.timestamp).toLocaleTimeString("fr-FR", {
                                    hour: "2-digit",
                                    minute: "2-digit",
                                  })}
                                </span>
                                {message.sender === "me" && getMessageStatus(message.status)}
                              </div>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-8">
                          <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                          <p className="text-gray-500">Aucun message dans cette conversation</p>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>

                {/* Message Input */}
                <div className="p-4 border-t flex-shrink-0">
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      <Paperclip className="h-4 w-4" />
                    </Button>
                    <div className="flex-1 relative">
                      <Input
                        placeholder="Tapez votre message..."
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === "Enter" && !e.shiftKey) {
                            e.preventDefault()
                            handleSendMessage()
                          }
                        }}
                        className="pr-10"
                      />
                      <Button variant="ghost" size="sm" className="absolute right-1 top-1/2 transform -translate-y-1/2">
                        <Smile className="h-4 w-4" />
                      </Button>
                    </div>
                    <Button
                      onClick={handleSendMessage}
                      disabled={!newMessage.trim()}
                      className="bg-lime-500 hover:bg-lime-600"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ) : (
              <Card className="h-full flex items-center justify-center">
                <div className="text-center">
                  <MessageCircle className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Sélectionnez une conversation pour commencer</p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
