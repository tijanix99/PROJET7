"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  CheckCircle2,
  Circle,
  User,
  ShoppingBag,
  MessageCircle,
  Bot,
  Settings,
  Rocket,
  ArrowRight,
  Star,
  Gift,
} from "lucide-react"
import { getCurrentUser } from "@/lib/supabase-client"
import { getOnboardingStatus, updateOnboardingStep } from "@/lib/database"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"

interface OnboardingStep {
  id: string
  title: string
  description: string
  icon: React.ReactNode
  completed: boolean
  link: string
  reward?: string
}

export default function OnboardingChecklist() {
  const [steps, setSteps] = useState<OnboardingStep[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showCelebration, setShowCelebration] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    loadOnboardingStatus()
  }, [])

  const loadOnboardingStatus = async () => {
    try {
      const user = await getCurrentUser()
      if (!user) return

      const status = await getOnboardingStatus(user.id)

      const onboardingSteps: OnboardingStep[] = [
        {
          id: "profile",
          title: "Compléter le profil",
          description: "Ajoutez vos informations personnelles et boutique",
          icon: <User className="h-5 w-5" />,
          completed: status.profile_completed || false,
          link: "/dashboard/settings",
          reward: "🎁 Badge Vendeur Vérifié",
        },
        {
          id: "products",
          title: "Ajouter 3 produits",
          description: "Créez votre premier catalogue de produits",
          icon: <ShoppingBag className="h-5 w-5" />,
          completed: status.products_added >= 3,
          link: "/dashboard/products",
          reward: "🏆 Débloquer Analytics Produits",
        },
        {
          id: "whatsapp",
          title: "Configurer WhatsApp",
          description: "Connectez votre numéro WhatsApp Business",
          icon: <MessageCircle className="h-5 w-5" />,
          completed: status.whatsapp_connected || false,
          link: "/dashboard/messages",
          reward: "💬 Messages Automatiques",
        },
        {
          id: "ai",
          title: "Configurer l'IA",
          description: "Entraînez votre assistant IA avec 5 réponses",
          icon: <Bot className="h-5 w-5" />,
          completed: status.ai_responses >= 5,
          link: "/dashboard/ai-assistant",
          reward: "🤖 Assistant IA Premium",
        },
        {
          id: "order",
          title: "Première commande",
          description: "Créez votre première commande test",
          icon: <Settings className="h-5 w-5" />,
          completed: status.first_order_created || false,
          link: "/dashboard/orders",
          reward: "📊 Débloquer Statistiques Avancées",
        },
      ]

      setSteps(onboardingSteps)

      // Vérifier si tout est complété pour la première fois
      const allCompleted = onboardingSteps.every((step) => step.completed)
      if (allCompleted && !status.onboarding_completed) {
        setShowCelebration(true)
        await updateOnboardingStep(user.id, { onboarding_completed: true })
      }
    } catch (error) {
      console.error("Erreur onboarding:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const completedSteps = steps.filter((step) => step.completed).length
  const progressPercentage = (completedSteps / steps.length) * 100

  const handleStepClick = async (step: OnboardingStep) => {
    if (!step.completed) {
      // Marquer comme en cours
      toast({
        title: "Étape en cours",
        description: `Vous travaillez sur : ${step.title}`,
      })
    }
  }

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full"
      >
        <Card className="backdrop-blur-md bg-white/70 dark:bg-gray-800/70 border-0 shadow-2xl">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center text-xl">
                  <Rocket className="h-6 w-6 mr-2 text-blue-600" />
                  Configuration de votre boutique
                </CardTitle>
                <CardDescription>Complétez ces étapes pour débloquer toutes les fonctionnalités PRO+</CardDescription>
              </div>
              <Badge
                variant={completedSteps === steps.length ? "default" : "secondary"}
                className={
                  completedSteps === steps.length
                    ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                    : "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
                }
              >
                {completedSteps}/{steps.length} complétées
              </Badge>
            </div>

            <div className="mt-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Progression</span>
                <span className="text-sm text-gray-600">{Math.round(progressPercentage)}%</span>
              </div>
              <Progress value={progressPercentage} className="h-3" />
            </div>
          </CardHeader>

          <CardContent className="space-y-4">
            {steps.map((step, index) => (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                className="group"
              >
                <Link href={step.link}>
                  <div
                    className={`flex items-center p-4 rounded-xl border-2 transition-all duration-300 cursor-pointer ${
                      step.completed
                        ? "border-green-200 bg-green-50 dark:bg-green-900/20 dark:border-green-800"
                        : "border-gray-200 dark:border-gray-700 hover:border-blue-300 dark:hover:border-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20"
                    }`}
                    onClick={() => handleStepClick(step)}
                  >
                    <div className="flex items-center space-x-4 flex-1">
                      <div
                        className={`p-2 rounded-lg ${
                          step.completed
                            ? "bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-400"
                            : "bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-400"
                        }`}
                      >
                        {step.icon}
                      </div>

                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <h3 className="font-medium">{step.title}</h3>
                          {step.completed ? (
                            <CheckCircle2 className="h-5 w-5 text-green-600" />
                          ) : (
                            <Circle className="h-5 w-5 text-gray-400" />
                          )}
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{step.description}</p>
                        {step.reward && (
                          <div className="flex items-center mt-1">
                            <Gift className="h-3 w-3 mr-1 text-purple-500" />
                            <span className="text-xs text-purple-600 dark:text-purple-400">{step.reward}</span>
                          </div>
                        )}
                      </div>

                      <ArrowRight className="h-5 w-5 text-gray-400 group-hover:text-blue-600 transition-colors" />
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}

            {completedSteps === steps.length && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5 }}
                className="text-center p-6 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-xl border border-green-200 dark:border-green-800"
              >
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-green-100 dark:bg-green-900 rounded-full">
                    <Star className="h-8 w-8 text-green-600 dark:text-green-400" />
                  </div>
                </div>
                <h3 className="text-lg font-bold text-green-800 dark:text-green-200 mb-2">
                  🎉 Félicitations ! Boutique configurée !
                </h3>
                <p className="text-sm text-green-700 dark:text-green-300 mb-4">
                  Vous avez débloqué toutes les fonctionnalités PRO+ d'InstaSell Pro
                </p>
                <Button className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700">
                  <Rocket className="h-4 w-4 mr-2" />
                  Commencer à vendre !
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Animation de célébration */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm"
            onClick={() => setShowCelebration(false)}
          >
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              exit={{ scale: 0, rotate: 180 }}
              transition={{ type: "spring", duration: 0.8 }}
              className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-2xl text-center max-w-md mx-4"
            >
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 0.5, repeat: 3 }}
                className="text-6xl mb-4"
              >
                🎉
              </motion.div>
              <h2 className="text-2xl font-bold mb-2">Bravo !</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                Votre boutique InstaSell Pro est maintenant entièrement configurée !
              </p>
              <Button
                onClick={() => setShowCelebration(false)}
                className="bg-gradient-to-r from-blue-600 to-purple-600"
              >
                Commencer à vendre ! 🚀
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
