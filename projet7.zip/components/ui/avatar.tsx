"use client"

import * as React from "react"
import * as AvatarPrimitive from "@radix-ui/react-avatar"
import * as DropdownMenuPrimitive from "@radix-ui/react-dropdown-menu"
import { cn } from "@/lib/utils"
import { User, Settings, LogOut } from "lucide-react"
import Link from "next/link"

const Avatar = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Root> & {
    showDropdown?: boolean
    onProfileClick?: () => void
    onSettingsClick?: () => void
    onLogoutClick?: () => void
  }
>(({ className, showDropdown = false, onProfileClick, onSettingsClick, onLogoutClick, ...props }, ref) => {
  if (showDropdown) {
    return (
      <DropdownMenuPrimitive.Root>
        <DropdownMenuPrimitive.Trigger asChild>
          <button className="relative h-10 w-10 rounded-full hover:ring-2 hover:ring-blue-500 transition-all focus:outline-none focus:ring-2 focus:ring-blue-500">
            <AvatarPrimitive.Root
              ref={ref}
              className={cn("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className)}
              {...props}
            />
          </button>
        </DropdownMenuPrimitive.Trigger>
        <DropdownMenuPrimitive.Portal>
          <DropdownMenuPrimitive.Content
            className="min-w-[220px] bg-gray-800 border border-gray-700 rounded-lg shadow-lg z-50 p-1"
            sideOffset={5}
            align="end"
          >
            <div className="p-3 border-b border-gray-700">
              <p className="text-sm font-medium text-white">Mon Compte</p>
              <p className="text-xs text-gray-400">Gérer votre profil</p>
            </div>

            <DropdownMenuPrimitive.Item asChild>
              <Link
                href="/dashboard/profile"
                className="flex items-center px-3 py-2 text-sm text-gray-300 hover:text-white hover:bg-gray-700 rounded-md transition-colors cursor-pointer outline-none"
                onClick={onProfileClick}
              >
                <User className="mr-3 h-4 w-4" />
                Profil
              </Link>
            </DropdownMenuPrimitive.Item>

            <DropdownMenuPrimitive.Item asChild>
              <Link
                href="/dashboard/settings"
                className="flex items-center px-3 py-2 text-sm text-gray-300 hover:text-white hover:bg-gray-700 rounded-md transition-colors cursor-pointer outline-none"
                onClick={onSettingsClick}
              >
                <Settings className="mr-3 h-4 w-4" />
                Paramètres
              </Link>
            </DropdownMenuPrimitive.Item>

            <div className="h-px bg-gray-700 my-1" />

            <DropdownMenuPrimitive.Item asChild>
              <Link
                href="/auth/login"
                className="flex items-center px-3 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-gray-700 rounded-md transition-colors cursor-pointer outline-none"
                onClick={onLogoutClick}
              >
                <LogOut className="mr-3 h-4 w-4" />
                Déconnexion
              </Link>
            </DropdownMenuPrimitive.Item>
          </DropdownMenuPrimitive.Content>
        </DropdownMenuPrimitive.Portal>
      </DropdownMenuPrimitive.Root>
    )
  }

  return (
    <AvatarPrimitive.Root
      ref={ref}
      className={cn("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className)}
      {...props}
    />
  )
})
Avatar.displayName = AvatarPrimitive.Root.displayName

const AvatarImage = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Image>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Image>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Image ref={ref} className={cn("aspect-square h-full w-full", className)} {...props} />
))
AvatarImage.displayName = AvatarPrimitive.Image.displayName

const AvatarFallback = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Fallback>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Fallback>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Fallback
    ref={ref}
    className={cn("flex h-full w-full items-center justify-center rounded-full bg-muted", className)}
    {...props}
  />
))
AvatarFallback.displayName = AvatarPrimitive.Fallback.displayName

export { Avatar, AvatarImage, AvatarFallback }
