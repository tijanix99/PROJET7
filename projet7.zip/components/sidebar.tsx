"use client"

import type React from "react"
import { cn } from "@/lib/utils"

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode
}

export function Sidebar({ children, className, ...props }: SidebarProps) {
  return (
    <div className={cn("flex h-full w-64 flex-col bg-gray-900 border-r border-gray-800", className)} {...props}>
      <div className="flex h-16 items-center border-b border-gray-800 px-6">
        <div className="flex items-center space-x-2">
          <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center">
            <span className="text-white font-bold text-sm">TJR</span>
          </div>
          <h2 className="text-xl font-bold text-white">TJR Dashboard</h2>
        </div>
      </div>
      <div className="flex-1 overflow-auto">{children}</div>
    </div>
  )
}
