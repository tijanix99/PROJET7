"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { User, Settings, LogOut } from "lucide-react"

export default function TestAvatarMenu() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="p-8 bg-gray-900 min-h-screen flex items-center justify-center">
      <div className="space-y-4">
        <h1 className="text-white text-xl">Test Avatar Menu</h1>

        {/* Test simple avec DropdownMenu */}
        <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
          <DropdownMenuTrigger asChild>
            <button
              className="relative h-10 w-10 rounded-full bg-blue-500 hover:bg-blue-600 transition-colors"
              onClick={() => {
                console.log("Avatar cliqué!")
                setIsOpen(!isOpen)
              }}
            >
              <Avatar className="h-10 w-10">
                <AvatarImage src="/placeholder-user.jpg" />
                <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">U</AvatarFallback>
              </Avatar>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56 bg-gray-800 border-gray-700 text-white" align="end" sideOffset={5}>
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col space-y-1">
                <p className="text-sm font-medium leading-none text-white">Test User</p>
                <p className="text-xs leading-none text-gray-400">test@example.com</p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator className="bg-gray-700" />
            <DropdownMenuItem
              className="text-gray-300 hover:text-white hover:bg-gray-700 cursor-pointer"
              onClick={() => alert("Profil cliqué!")}
            >
              <User className="mr-2 h-4 w-4" />
              <span>Profil</span>
            </DropdownMenuItem>
            <DropdownMenuItem
              className="text-gray-300 hover:text-white hover:bg-gray-700 cursor-pointer"
              onClick={() => alert("Paramètres cliqué!")}
            >
              <Settings className="mr-2 h-4 w-4" />
              <span>Paramètres</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-gray-700" />
            <DropdownMenuItem
              className="text-red-400 hover:text-red-300 hover:bg-gray-700 cursor-pointer"
              onClick={() => alert("Déconnexion cliquée!")}
            >
              <LogOut className="mr-2 h-4 w-4" />
              <span>Se déconnecter</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <p className="text-gray-400 text-sm">Cliquez sur l'avatar ci-dessus pour tester le menu</p>
      </div>
    </div>
  )
}
