"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { User, Settings, LogOut } from "lucide-react"

export default function SimpleAvatarMenu() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const handleAvatarClick = () => {
    console.log("Avatar cliqué!")
    setIsMenuOpen(!isMenuOpen)
  }

  const handleLogout = () => {
    alert("Déconnexion!")
    setIsMenuOpen(false)
  }

  const handleProfile = () => {
    alert("Profil!")
    setIsMenuOpen(false)
  }

  const handleSettings = () => {
    alert("Paramètres!")
    setIsMenuOpen(false)
  }

  return (
    <div className="relative">
      {/* Avatar cliquable */}
      <button
        onClick={handleAvatarClick}
        className="relative h-10 w-10 rounded-full hover:ring-2 hover:ring-blue-500 transition-all focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        <Avatar className="h-10 w-10">
          <AvatarImage src="/placeholder-user.jpg" />
          <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">U</AvatarFallback>
        </Avatar>
      </button>

      {/* Menu simple */}
      {isMenuOpen && (
        <div className="absolute right-0 mt-2 w-56 bg-gray-800 border border-gray-700 rounded-lg shadow-lg z-50">
          {/* Header */}
          <div className="p-4 border-b border-gray-700">
            <p className="text-sm font-medium text-white">Test User</p>
            <p className="text-xs text-gray-400">test@example.com</p>
          </div>

          {/* Menu Items */}
          <div className="py-2">
            <button
              onClick={handleProfile}
              className="w-full flex items-center px-4 py-2 text-sm text-gray-300 hover:text-white hover:bg-gray-700 transition-colors"
            >
              <User className="mr-3 h-4 w-4" />
              Profil
            </button>
            <button
              onClick={handleSettings}
              className="w-full flex items-center px-4 py-2 text-sm text-gray-300 hover:text-white hover:bg-gray-700 transition-colors"
            >
              <Settings className="mr-3 h-4 w-4" />
              Paramètres
            </button>
            <hr className="my-2 border-gray-700" />
            <button
              onClick={handleLogout}
              className="w-full flex items-center px-4 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-gray-700 transition-colors"
            >
              <LogOut className="mr-3 h-4 w-4" />
              Se déconnecter
            </button>
          </div>
        </div>
      )}

      {/* Overlay pour fermer le menu */}
      {isMenuOpen && <div className="fixed inset-0 z-40" onClick={() => setIsMenuOpen(false)} />}
    </div>
  )
}
