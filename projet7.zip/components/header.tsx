import type React from "react"

interface HeaderProps {
  children?: React.ReactNode
}

export function DashboardHeader({ children }: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 flex h-16 items-center justify-between border-b border-gray-800 bg-gray-900 px-4">
      <div className="flex items-center gap-2">
        <h1 className="text-xl font-semibold">Dashboard</h1>
      </div>
      <div className="flex items-center gap-2">{children}</div>
    </header>
  )
}

// Export as Header as well for compatibility
export const Header = DashboardHeader
