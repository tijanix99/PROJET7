export interface Product {
  id: string
  name: string
  description?: string
  price: number
  stock: number
  category?: string
  image_url?: string
  attributes?: Record<string, any>
  user_id: string
  created_at: string
  updated_at: string
}

export interface Order {
  id: string
  customer_name: string
  customer_phone: string
  customer_address: string
  customer_city: string
  total_amount: number
  status: "pending" | "confirmed" | "shipped" | "delivered" | "cancelled"
  notes?: string
  user_id: string
  created_at: string
  updated_at: string
  items?: OrderItem[]
}

export interface OrderItem {
  id: string
  order_id: string
  product_id: string
  product_name: string
  product_price: number
  quantity: number
  subtotal: number
  product?: Product
}

export interface User {
  id: string
  email: string
  full_name?: string
  business_name?: string
  phone?: string
  address?: string
  city?: string
  created_at: string
}

export interface UserSettings {
  id: string
  user_id: string
  business_name?: string
  business_description?: string
  business_phone?: string
  business_email?: string
  business_address?: string
  business_city?: string
  whatsapp_number?: string
  instagram_handle?: string
  logo_url?: string
  theme_color?: string
  currency?: string
  language?: string
  notifications_enabled?: boolean
  auto_confirm_orders?: boolean
  created_at: string
  updated_at: string
}
