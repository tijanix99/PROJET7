# Guide de Configuration Supabase

## 1. Variables d'environnement

Créez un fichier `.env.local` à la racine du projet :

\`\`\`env
NEXT_PUBLIC_SUPABASE_URL=https://jwxtcnjcnxwtuwqizhkq.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3eHRjbmpjbnh3dHV3cWl6aGtxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk5MTE0NDcsImV4cCI6MjA2NTQ4NzQ0N30.srb73bSz_U6j2ahMp3WnO1_VJp0sqsWt24L0KuzvhDY
SUPABASE_SERVICE_ROLE_KEY=VOTRE_CLE_SERVICE_ROLE_ICI
\`\`\`

## 2. Scripts à exécuter dans l'ordre

### Étape 1: Créer les tables
\`\`\`sql
-- Exécutez dans l'éditeur SQL de Supabase
-- scripts/create-tables-no-fk.sql
\`\`\`

### Étape 2: Configurer les permissions
\`\`\`sql
-- scripts/fix-all-permissions.sql
\`\`\`

### Étape 3: Créer le bucket de stockage
\`\`\`sql
-- scripts/create-storage-bucket-admin.sql
\`\`\`

### Étape 4: Tester la configuration
\`\`\`bash
npm run dev
# Puis testez l'inscription et la connexion
\`\`\`

## 3. Vérifications

- [ ] Variables d'environnement configurées
- [ ] Tables créées dans Supabase
- [ ] Permissions RLS configurées
- [ ] Bucket de stockage créé
- [ ] Test de connexion réussi

## 4. Dépannage

Si vous rencontrez des erreurs :

1. Vérifiez les logs dans la console Supabase
2. Exécutez le script de diagnostic
3. Vérifiez les permissions RLS
4. Contactez le support si nécessaire
